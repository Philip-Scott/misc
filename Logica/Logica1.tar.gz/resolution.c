
#include <glib.h>
#include <glib-object.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


#define PROYECTO_DE_LOGICA_TYPE_RESOLUTION (proyecto_de_logica_resolution_get_type ())
#define PROYECTO_DE_LOGICA_RESOLUTION(obj) (G_TYPE_CHECK_INSTANCE_CAST ((obj), PROYECTO_DE_LOGICA_TYPE_RESOLUTION, ProyectoDeLogicaResolution))
#define PROYECTO_DE_LOGICA_RESOLUTION_CLASS(klass) (G_TYPE_CHECK_CLASS_CAST ((klass), PROYECTO_DE_LOGICA_TYPE_RESOLUTION, ProyectoDeLogicaResolutionClass))
#define PROYECTO_DE_LOGICA_IS_RESOLUTION(obj) (G_TYPE_CHECK_INSTANCE_TYPE ((obj), PROYECTO_DE_LOGICA_TYPE_RESOLUTION))
#define PROYECTO_DE_LOGICA_IS_RESOLUTION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), PROYECTO_DE_LOGICA_TYPE_RESOLUTION))
#define PROYECTO_DE_LOGICA_RESOLUTION_GET_CLASS(obj) (G_TYPE_INSTANCE_GET_CLASS ((obj), PROYECTO_DE_LOGICA_TYPE_RESOLUTION, ProyectoDeLogicaResolutionClass))

typedef struct _ProyectoDeLogicaResolution ProyectoDeLogicaResolution;
typedef struct _ProyectoDeLogicaResolutionClass ProyectoDeLogicaResolutionClass;
typedef struct _ProyectoDeLogicaResolutionPrivate ProyectoDeLogicaResolutionPrivate;
#define __g_list_free__g_free0_0(var) ((var == NULL) ? NULL : (var = (_g_list_free__g_free0_ (var), NULL)))
#define _g_free0(var) (var = (g_free (var), NULL))
#define _g_regex_unref0(var) ((var == NULL) ? NULL : (var = (g_regex_unref (var), NULL)))
#define _g_error_free0(var) ((var == NULL) ? NULL : (var = (g_error_free (var), NULL)))

struct _ProyectoDeLogicaResolution {
	GObject parent_instance;
	ProyectoDeLogicaResolutionPrivate * priv;
	GList* fi;
};

struct _ProyectoDeLogicaResolutionClass {
	GObjectClass parent_class;
};


static gpointer proyecto_de_logica_resolution_parent_class = NULL;

GType proyecto_de_logica_resolution_get_type (void) G_GNUC_CONST;
enum  {
	PROYECTO_DE_LOGICA_RESOLUTION_DUMMY_PROPERTY
};
static void _g_free0_ (gpointer var);
static void _g_list_free__g_free0_ (GList* self);
ProyectoDeLogicaResolution* proyecto_de_logica_resolution_new (const gchar* fi_l, const gchar* fi_r);
ProyectoDeLogicaResolution* proyecto_de_logica_resolution_construct (GType object_type, const gchar* fi_l, const gchar* fi_r);
gint proyecto_de_logica_resolution_add_formula (ProyectoDeLogicaResolution* self, const gchar* fi_);
void proyecto_de_logica_resolution_solve (ProyectoDeLogicaResolution* self);
static void proyecto_de_logica_resolution_finalize (GObject* obj);


static void _g_free0_ (gpointer var) {
	var = (g_free (var), NULL);
}


static void _g_list_free__g_free0_ (GList* self) {
	g_list_foreach (self, (GFunc) _g_free0_, NULL);
	g_list_free (self);
}


ProyectoDeLogicaResolution* proyecto_de_logica_resolution_construct (GType object_type, const gchar* fi_l, const gchar* fi_r) {
	ProyectoDeLogicaResolution * self = NULL;
	GList* fi = NULL;
	g_return_val_if_fail (fi_l != NULL, NULL);
	g_return_val_if_fail (fi_r != NULL, NULL);
	self = (ProyectoDeLogicaResolution*) g_object_new (object_type, NULL);
	fi = NULL;
	__g_list_free__g_free0_0 (fi);
	return self;
}


ProyectoDeLogicaResolution* proyecto_de_logica_resolution_new (const gchar* fi_l, const gchar* fi_r) {
	return proyecto_de_logica_resolution_construct (PROYECTO_DE_LOGICA_TYPE_RESOLUTION, fi_l, fi_r);
}


static gboolean string_contains (const gchar* self, const gchar* needle) {
	gboolean result = FALSE;
	const gchar* _tmp0_ = NULL;
	gchar* _tmp1_ = NULL;
	g_return_val_if_fail (self != NULL, FALSE);
	g_return_val_if_fail (needle != NULL, FALSE);
	_tmp0_ = needle;
	_tmp1_ = strstr ((gchar*) self, (gchar*) _tmp0_);
	result = _tmp1_ != NULL;
	return result;
}


static gchar* string_replace (const gchar* self, const gchar* old, const gchar* replacement) {
	gchar* result = NULL;
	GError * _inner_error_ = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	g_return_val_if_fail (old != NULL, NULL);
	g_return_val_if_fail (replacement != NULL, NULL);
	{
		GRegex* regex = NULL;
		const gchar* _tmp0_ = NULL;
		gchar* _tmp1_ = NULL;
		gchar* _tmp2_ = NULL;
		GRegex* _tmp3_ = NULL;
		GRegex* _tmp4_ = NULL;
		gchar* _tmp5_ = NULL;
		GRegex* _tmp6_ = NULL;
		const gchar* _tmp7_ = NULL;
		gchar* _tmp8_ = NULL;
		gchar* _tmp9_ = NULL;
		_tmp0_ = old;
		_tmp1_ = g_regex_escape_string (_tmp0_, -1);
		_tmp2_ = _tmp1_;
		_tmp3_ = g_regex_new (_tmp2_, 0, 0, &_inner_error_);
		_tmp4_ = _tmp3_;
		_g_free0 (_tmp2_);
		regex = _tmp4_;
		if (G_UNLIKELY (_inner_error_ != NULL)) {
			if (_inner_error_->domain == G_REGEX_ERROR) {
				goto __catch1_g_regex_error;
			}
			g_critical ("file %s: line %d: unexpected error: %s (%s, %d)", __FILE__, __LINE__, _inner_error_->message, g_quark_to_string (_inner_error_->domain), _inner_error_->code);
			g_clear_error (&_inner_error_);
			return NULL;
		}
		_tmp6_ = regex;
		_tmp7_ = replacement;
		_tmp8_ = g_regex_replace_literal (_tmp6_, self, (gssize) (-1), 0, _tmp7_, 0, &_inner_error_);
		_tmp5_ = _tmp8_;
		if (G_UNLIKELY (_inner_error_ != NULL)) {
			_g_regex_unref0 (regex);
			if (_inner_error_->domain == G_REGEX_ERROR) {
				goto __catch1_g_regex_error;
			}
			_g_regex_unref0 (regex);
			g_critical ("file %s: line %d: unexpected error: %s (%s, %d)", __FILE__, __LINE__, _inner_error_->message, g_quark_to_string (_inner_error_->domain), _inner_error_->code);
			g_clear_error (&_inner_error_);
			return NULL;
		}
		_tmp9_ = _tmp5_;
		_tmp5_ = NULL;
		result = _tmp9_;
		_g_free0 (_tmp5_);
		_g_regex_unref0 (regex);
		return result;
	}
	goto __finally1;
	__catch1_g_regex_error:
	{
		GError* e = NULL;
		e = _inner_error_;
		_inner_error_ = NULL;
		g_assert_not_reached ();
		_g_error_free0 (e);
	}
	__finally1:
	if (G_UNLIKELY (_inner_error_ != NULL)) {
		g_critical ("file %s: line %d: uncaught error: %s (%s, %d)", __FILE__, __LINE__, _inner_error_->message, g_quark_to_string (_inner_error_->domain), _inner_error_->code);
		g_clear_error (&_inner_error_);
		return NULL;
	}
}


static const gchar* string_to_string (const gchar* self) {
	const gchar* result = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	result = self;
	return result;
}


gint proyecto_de_logica_resolution_add_formula (ProyectoDeLogicaResolution* self, const gchar* fi_) {
	gint result = 0;
	const gchar* _tmp0_ = NULL;
	gboolean _tmp1_ = FALSE;
	g_return_val_if_fail (self != NULL, 0);
	g_return_val_if_fail (fi_ != NULL, 0);
	_tmp0_ = fi_;
	_tmp1_ = string_contains (_tmp0_, "!!");
	if (_tmp1_) {
		const gchar* _tmp2_ = NULL;
		gchar* _tmp3_ = NULL;
		gchar* _tmp4_ = NULL;
		const gchar* _tmp5_ = NULL;
		gchar* _tmp6_ = NULL;
		_tmp2_ = fi_;
		_tmp3_ = string_replace (_tmp2_, "!!", "!");
		_tmp4_ = _tmp3_;
		_tmp5_ = string_to_string (_tmp4_);
		_tmp6_ = g_strdup (_tmp5_);
		self->fi = g_list_append (self->fi, _tmp6_);
		_g_free0 (_tmp4_);
	} else {
		const gchar* _tmp7_ = NULL;
		const gchar* _tmp8_ = NULL;
		gchar* _tmp9_ = NULL;
		_tmp7_ = fi_;
		_tmp8_ = string_to_string (_tmp7_);
		_tmp9_ = g_strdup (_tmp8_);
		self->fi = g_list_append (self->fi, _tmp9_);
	}
	result = 0;
	return result;
}


void proyecto_de_logica_resolution_solve (ProyectoDeLogicaResolution* self) {
	FILE* _tmp0_ = NULL;
	g_return_if_fail (self != NULL);
	_tmp0_ = stdout;
	fprintf (_tmp0_, "");
}


static void proyecto_de_logica_resolution_class_init (ProyectoDeLogicaResolutionClass * klass) {
	proyecto_de_logica_resolution_parent_class = g_type_class_peek_parent (klass);
	G_OBJECT_CLASS (klass)->finalize = proyecto_de_logica_resolution_finalize;
}


static void proyecto_de_logica_resolution_instance_init (ProyectoDeLogicaResolution * self) {
}


static void proyecto_de_logica_resolution_finalize (GObject* obj) {
	ProyectoDeLogicaResolution * self;
	self = G_TYPE_CHECK_INSTANCE_CAST (obj, PROYECTO_DE_LOGICA_TYPE_RESOLUTION, ProyectoDeLogicaResolution);
	__g_list_free__g_free0_0 (self->fi);
	G_OBJECT_CLASS (proyecto_de_logica_resolution_parent_class)->finalize (obj);
}


GType proyecto_de_logica_resolution_get_type (void) {
	static volatile gsize proyecto_de_logica_resolution_type_id__volatile = 0;
	if (g_once_init_enter (&proyecto_de_logica_resolution_type_id__volatile)) {
		static const GTypeInfo g_define_type_info = { sizeof (ProyectoDeLogicaResolutionClass), (GBaseInitFunc) NULL, (GBaseFinalizeFunc) NULL, (GClassInitFunc) proyecto_de_logica_resolution_class_init, (GClassFinalizeFunc) NULL, NULL, sizeof (ProyectoDeLogicaResolution), 0, (GInstanceInitFunc) proyecto_de_logica_resolution_instance_init, NULL };
		GType proyecto_de_logica_resolution_type_id;
		proyecto_de_logica_resolution_type_id = g_type_register_static (G_TYPE_OBJECT, "ProyectoDeLogicaResolution", &g_define_type_info, 0);
		g_once_init_leave (&proyecto_de_logica_resolution_type_id__volatile, proyecto_de_logica_resolution_type_id);
	}
	return proyecto_de_logica_resolution_type_id__volatile;
}



