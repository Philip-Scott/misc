#include <glib.h>
#include <glib-object.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


#define PROYECTO_DE_LOGICA_TYPE_LETTERS (proyecto_de_logica_letters_get_type ())
#define PROYECTO_DE_LOGICA_LETTERS(obj) (G_TYPE_CHECK_INSTANCE_CAST ((obj), PROYECTO_DE_LOGICA_TYPE_LETTERS, ProyectoDeLogicaLetters))
#define PROYECTO_DE_LOGICA_LETTERS_CLASS(klass) (G_TYPE_CHECK_CLASS_CAST ((klass), PROYECTO_DE_LOGICA_TYPE_LETTERS, ProyectoDeLogicaLettersClass))
#define PROYECTO_DE_LOGICA_IS_LETTERS(obj) (G_TYPE_CHECK_INSTANCE_TYPE ((obj), PROYECTO_DE_LOGICA_TYPE_LETTERS))
#define PROYECTO_DE_LOGICA_IS_LETTERS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), PROYECTO_DE_LOGICA_TYPE_LETTERS))
#define PROYECTO_DE_LOGICA_LETTERS_GET_CLASS(obj) (G_TYPE_INSTANCE_GET_CLASS ((obj), PROYECTO_DE_LOGICA_TYPE_LETTERS, ProyectoDeLogicaLettersClass))

typedef struct _ProyectoDeLogicaLetters ProyectoDeLogicaLetters;
typedef struct _ProyectoDeLogicaLettersClass ProyectoDeLogicaLettersClass;
typedef struct _ProyectoDeLogicaLettersPrivate ProyectoDeLogicaLettersPrivate;
#define _g_free0(var) (var = (g_free (var), NULL))
#define _g_regex_unref0(var) ((var == NULL) ? NULL : (var = (g_regex_unref (var), NULL)))
#define _g_error_free0(var) ((var == NULL) ? NULL : (var = (g_error_free (var), NULL)))

#define PROYECTO_DE_LOGICA_TYPE_SOLVER (proyecto_de_logica_solver_get_type ())
#define PROYECTO_DE_LOGICA_SOLVER(obj) (G_TYPE_CHECK_INSTANCE_CAST ((obj), PROYECTO_DE_LOGICA_TYPE_SOLVER, ProyectoDeLogicaSolver))
#define PROYECTO_DE_LOGICA_SOLVER_CLASS(klass) (G_TYPE_CHECK_CLASS_CAST ((klass), PROYECTO_DE_LOGICA_TYPE_SOLVER, ProyectoDeLogicaSolverClass))
#define PROYECTO_DE_LOGICA_IS_SOLVER(obj) (G_TYPE_CHECK_INSTANCE_TYPE ((obj), PROYECTO_DE_LOGICA_TYPE_SOLVER))
#define PROYECTO_DE_LOGICA_IS_SOLVER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), PROYECTO_DE_LOGICA_TYPE_SOLVER))
#define PROYECTO_DE_LOGICA_SOLVER_GET_CLASS(obj) (G_TYPE_INSTANCE_GET_CLASS ((obj), PROYECTO_DE_LOGICA_TYPE_SOLVER, ProyectoDeLogicaSolverClass))

typedef struct _ProyectoDeLogicaSolver ProyectoDeLogicaSolver;
typedef struct _ProyectoDeLogicaSolverClass ProyectoDeLogicaSolverClass;
typedef struct _ProyectoDeLogicaSolverPrivate ProyectoDeLogicaSolverPrivate;
#define _g_object_unref0(var) ((var == NULL) ? NULL : (var = (g_object_unref (var), NULL)))
typedef struct _Block2Data Block2Data;

#define PROYECTO_DE_LOGICA_TYPE_RESOLUTION (proyecto_de_logica_resolution_get_type ())
#define PROYECTO_DE_LOGICA_RESOLUTION(obj) (G_TYPE_CHECK_INSTANCE_CAST ((obj), PROYECTO_DE_LOGICA_TYPE_RESOLUTION, ProyectoDeLogicaResolution))
#define PROYECTO_DE_LOGICA_RESOLUTION_CLASS(klass) (G_TYPE_CHECK_CLASS_CAST ((klass), PROYECTO_DE_LOGICA_TYPE_RESOLUTION, ProyectoDeLogicaResolutionClass))
#define PROYECTO_DE_LOGICA_IS_RESOLUTION(obj) (G_TYPE_CHECK_INSTANCE_TYPE ((obj), PROYECTO_DE_LOGICA_TYPE_RESOLUTION))
#define PROYECTO_DE_LOGICA_IS_RESOLUTION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), PROYECTO_DE_LOGICA_TYPE_RESOLUTION))
#define PROYECTO_DE_LOGICA_RESOLUTION_GET_CLASS(obj) (G_TYPE_INSTANCE_GET_CLASS ((obj), PROYECTO_DE_LOGICA_TYPE_RESOLUTION, ProyectoDeLogicaResolutionClass))

typedef struct _ProyectoDeLogicaResolution ProyectoDeLogicaResolution;
typedef struct _ProyectoDeLogicaResolutionClass ProyectoDeLogicaResolutionClass;

struct _ProyectoDeLogicaLetters {
	GtkToggleButton parent_instance;
	ProyectoDeLogicaLettersPrivate * priv;
};

struct _ProyectoDeLogicaLettersClass {
	GtkToggleButtonClass parent_class;
};

struct _ProyectoDeLogicaLettersPrivate {
	gboolean init;
};

struct _ProyectoDeLogicaSolver {
	GtkVBox parent_instance;
	ProyectoDeLogicaSolverPrivate * priv;
};

struct _ProyectoDeLogicaSolverClass {
	GtkVBoxClass parent_class;
};

struct _ProyectoDeLogicaSolverPrivate {
	GtkToolButton* refresh_button;
};

struct _Block2Data {
	int _ref_count_;
	ProyectoDeLogicaSolver* self;
	GtkToolButton* step_solve_button;
	GtkToolButton* solve_button;
	GtkToolButton* return_button;
};


static gpointer proyecto_de_logica_letters_parent_class = NULL;
extern GtkLabel* proyecto_de_logica_formula_label;
extern GtkLabel* proyecto_de_logica_override_label;
extern gchar* proyecto_de_logica_originalfi;
extern ProyectoDeLogicaSolver* proyecto_de_logica_solver_box;
extern gchar* proyecto_de_logica_originaloverride;
static gpointer proyecto_de_logica_solver_parent_class = NULL;
extern GtkSwitch* proyecto_de_logica_formula_toggle;
extern GtkHeaderBar* proyecto_de_logica_headerbar;
extern GtkWindow* proyecto_de_logica_app;
extern GtkBox* proyecto_de_logica_mainbox;
extern ProyectoDeLogicaLetters* proyecto_de_logica_A;
extern ProyectoDeLogicaLetters* proyecto_de_logica_B;
extern ProyectoDeLogicaLetters* proyecto_de_logica_C;
extern ProyectoDeLogicaLetters* proyecto_de_logica_D;
extern ProyectoDeLogicaLetters* proyecto_de_logica_E;
extern ProyectoDeLogicaLetters* proyecto_de_logica_F;
extern ProyectoDeLogicaLetters* proyecto_de_logica_G;
extern ProyectoDeLogicaLetters* proyecto_de_logica_H;
extern ProyectoDeLogicaLetters* proyecto_de_logica_I;
extern ProyectoDeLogicaLetters* proyecto_de_logica_J;
extern ProyectoDeLogicaLetters* proyecto_de_logica_K;
extern ProyectoDeLogicaLetters* proyecto_de_logica_L;
extern ProyectoDeLogicaLetters* proyecto_de_logica_M;
extern ProyectoDeLogicaLetters* proyecto_de_logica_N;
extern ProyectoDeLogicaLetters* proyecto_de_logica_O;
extern ProyectoDeLogicaLetters* proyecto_de_logica_P;
extern ProyectoDeLogicaLetters* proyecto_de_logica_Q;
extern ProyectoDeLogicaLetters* proyecto_de_logica_R;
extern ProyectoDeLogicaLetters* proyecto_de_logica_S;
extern ProyectoDeLogicaLetters* proyecto_de_logica_T;
extern ProyectoDeLogicaLetters* proyecto_de_logica_U;
extern ProyectoDeLogicaLetters* proyecto_de_logica_V;
extern ProyectoDeLogicaLetters* proyecto_de_logica_W;
extern ProyectoDeLogicaLetters* proyecto_de_logica_X;
extern ProyectoDeLogicaLetters* proyecto_de_logica_Y;
extern ProyectoDeLogicaLetters* proyecto_de_logica_Z;

GType proyecto_de_logica_letters_get_type (void) G_GNUC_CONST;
#define PROYECTO_DE_LOGICA_LETTERS_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), PROYECTO_DE_LOGICA_TYPE_LETTERS, ProyectoDeLogicaLettersPrivate))
enum  {
	PROYECTO_DE_LOGICA_LETTERS_DUMMY_PROPERTY
};
gint proyecto_de_logica_letters_update (ProyectoDeLogicaLetters* self);
gint proyecto_de_logica_letters_reset (ProyectoDeLogicaLetters* self);
gint proyecto_de_logica_letters_letter_sensitive (ProyectoDeLogicaLetters* self, gboolean state);
gint proyecto_de_logica_letters_state (ProyectoDeLogicaLetters* self);
gchar* proyecto_de_logica_letters_val (ProyectoDeLogicaLetters* self);
gint proyecto_de_logica_letters_toggle (ProyectoDeLogicaLetters* self);
ProyectoDeLogicaLetters* proyecto_de_logica_letters_new (const gchar* letter);
ProyectoDeLogicaLetters* proyecto_de_logica_letters_construct (GType object_type, const gchar* letter);
GType proyecto_de_logica_solver_get_type (void) G_GNUC_CONST;
static void __lambda5_ (ProyectoDeLogicaLetters* self);
static void ___lambda5__gtk_toggle_button_toggled (GtkToggleButton* _sender, gpointer self);
static void proyecto_de_logica_letters_finalize (GObject* obj);
#define PROYECTO_DE_LOGICA_SOLVER_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), PROYECTO_DE_LOGICA_TYPE_SOLVER, ProyectoDeLogicaSolverPrivate))
enum  {
	PROYECTO_DE_LOGICA_SOLVER_DUMMY_PROPERTY
};
gchar* proyecto_de_logica_solver_advanced_calculate (ProyectoDeLogicaSolver* self, const gchar* fi);
gchar* proyecto_de_logica_solver_Calculate (ProyectoDeLogicaSolver* self, const gchar* fi);
ProyectoDeLogicaSolver* proyecto_de_logica_solver_new (void);
ProyectoDeLogicaSolver* proyecto_de_logica_solver_construct (GType object_type);
static Block2Data* block2_data_ref (Block2Data* _data2_);
static void block2_data_unref (void * _userdata_);
static void __lambda4_ (Block2Data* _data2_);
gint proyecto_de_logica_solver_reset_letters (ProyectoDeLogicaSolver* self);
static void ___lambda4__gtk_tool_button_clicked (GtkToolButton* _sender, gpointer self);
static void __lambda6_ (Block2Data* _data2_);
GType proyecto_de_logica_resolution_get_type (void) G_GNUC_CONST;
ProyectoDeLogicaResolution* proyecto_de_logica_resolution_new (const gchar* fi_l, const gchar* fi_r);
ProyectoDeLogicaResolution* proyecto_de_logica_resolution_construct (GType object_type, const gchar* fi_l, const gchar* fi_r);
gint proyecto_de_logica_solver_letters_sensitive (ProyectoDeLogicaSolver* self, gboolean state);
gint proyecto_de_logica_resolution_add_formula (ProyectoDeLogicaResolution* self, const gchar* fi_);
gchar* proyecto_de_logica_solver_row_FNC (ProyectoDeLogicaSolver* self);
gint proyecto_de_logica_solver_auto_solver (ProyectoDeLogicaSolver* self);
gint proyecto_de_logica_solver_letter_states (ProyectoDeLogicaSolver* self);
void proyecto_de_logica_resolution_solve (ProyectoDeLogicaResolution* self);
static void ___lambda6__gtk_tool_button_clicked (GtkToolButton* _sender, gpointer self);
static void __lambda7_ (Block2Data* _data2_);
static void ___lambda7__gtk_tool_button_clicked (GtkToolButton* _sender, gpointer self);
static void __lambda8_ (Block2Data* _data2_);
static void ___lambda8__gtk_tool_button_clicked (GtkToolButton* _sender, gpointer self);
void proyecto_de_logica_solver_populate (ProyectoDeLogicaSolver* self, const gchar* formula_, const gchar* formula_override);
static void __lambda9_ (ProyectoDeLogicaSolver* self);
static void ___lambda9__proyecto_de_logica_solver_update (ProyectoDeLogicaSolver* _sender, gpointer self);
static void proyecto_de_logica_solver_finalize (GObject* obj);


static gchar* string_replace (const gchar* self, const gchar* old, const gchar* replacement) {
	gchar* result = NULL;
	GError * _inner_error_ = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	g_return_val_if_fail (old != NULL, NULL);
	g_return_val_if_fail (replacement != NULL, NULL);
	{
		GRegex* regex = NULL;
		const gchar* _tmp0_ = NULL;
		gchar* _tmp1_ = NULL;
		gchar* _tmp2_ = NULL;
		GRegex* _tmp3_ = NULL;
		GRegex* _tmp4_ = NULL;
		gchar* _tmp5_ = NULL;
		GRegex* _tmp6_ = NULL;
		const gchar* _tmp7_ = NULL;
		gchar* _tmp8_ = NULL;
		gchar* _tmp9_ = NULL;
		_tmp0_ = old;
		_tmp1_ = g_regex_escape_string (_tmp0_, -1);
		_tmp2_ = _tmp1_;
		_tmp3_ = g_regex_new (_tmp2_, 0, 0, &_inner_error_);
		_tmp4_ = _tmp3_;
		_g_free0 (_tmp2_);
		regex = _tmp4_;
		if (G_UNLIKELY (_inner_error_ != NULL)) {
			if (_inner_error_->domain == G_REGEX_ERROR) {
				goto __catch2_g_regex_error;
			}
			g_critical ("file %s: line %d: unexpected error: %s (%s, %d)", __FILE__, __LINE__, _inner_error_->message, g_quark_to_string (_inner_error_->domain), _inner_error_->code);
			g_clear_error (&_inner_error_);
			return NULL;
		}
		_tmp6_ = regex;
		_tmp7_ = replacement;
		_tmp8_ = g_regex_replace_literal (_tmp6_, self, (gssize) (-1), 0, _tmp7_, 0, &_inner_error_);
		_tmp5_ = _tmp8_;
		if (G_UNLIKELY (_inner_error_ != NULL)) {
			_g_regex_unref0 (regex);
			if (_inner_error_->domain == G_REGEX_ERROR) {
				goto __catch2_g_regex_error;
			}
			_g_regex_unref0 (regex);
			g_critical ("file %s: line %d: unexpected error: %s (%s, %d)", __FILE__, __LINE__, _inner_error_->message, g_quark_to_string (_inner_error_->domain), _inner_error_->code);
			g_clear_error (&_inner_error_);
			return NULL;
		}
		_tmp9_ = _tmp5_;
		_tmp5_ = NULL;
		result = _tmp9_;
		_g_free0 (_tmp5_);
		_g_regex_unref0 (regex);
		return result;
	}
	goto __finally2;
	__catch2_g_regex_error:
	{
		GError* e = NULL;
		e = _inner_error_;
		_inner_error_ = NULL;
		g_assert_not_reached ();
		_g_error_free0 (e);
	}
	__finally2:
	if (G_UNLIKELY (_inner_error_ != NULL)) {
		g_critical ("file %s: line %d: uncaught error: %s (%s, %d)", __FILE__, __LINE__, _inner_error_->message, g_quark_to_string (_inner_error_->domain), _inner_error_->code);
		g_clear_error (&_inner_error_);
		return NULL;
	}
}


gint proyecto_de_logica_letters_update (ProyectoDeLogicaLetters* self) {
	gint result = 0;
	gboolean _tmp0_ = FALSE;
	g_return_val_if_fail (self != NULL, 0);
	_tmp0_ = self->priv->init;
	if (_tmp0_) {
		gboolean _tmp1_ = FALSE;
		gboolean _tmp2_ = FALSE;
		GtkLabel* _tmp19_ = NULL;
		const gchar* _tmp20_ = NULL;
		const gchar* _tmp21_ = NULL;
		_tmp1_ = gtk_toggle_button_get_active ((GtkToggleButton*) self);
		_tmp2_ = _tmp1_;
		if (_tmp2_) {
			GtkLabel* _tmp3_ = NULL;
			GtkLabel* _tmp4_ = NULL;
			const gchar* _tmp5_ = NULL;
			const gchar* _tmp6_ = NULL;
			const gchar* _tmp7_ = NULL;
			const gchar* _tmp8_ = NULL;
			gchar* _tmp9_ = NULL;
			gchar* _tmp10_ = NULL;
			_tmp3_ = proyecto_de_logica_formula_label;
			_tmp4_ = proyecto_de_logica_formula_label;
			_tmp5_ = gtk_label_get_label (_tmp4_);
			_tmp6_ = _tmp5_;
			_tmp7_ = gtk_button_get_label ((GtkButton*) self);
			_tmp8_ = _tmp7_;
			_tmp9_ = string_replace (_tmp6_, _tmp8_, "1");
			_tmp10_ = _tmp9_;
			gtk_label_set_label (_tmp3_, _tmp10_);
			_g_free0 (_tmp10_);
		} else {
			GtkLabel* _tmp11_ = NULL;
			GtkLabel* _tmp12_ = NULL;
			const gchar* _tmp13_ = NULL;
			const gchar* _tmp14_ = NULL;
			const gchar* _tmp15_ = NULL;
			const gchar* _tmp16_ = NULL;
			gchar* _tmp17_ = NULL;
			gchar* _tmp18_ = NULL;
			_tmp11_ = proyecto_de_logica_formula_label;
			_tmp12_ = proyecto_de_logica_formula_label;
			_tmp13_ = gtk_label_get_label (_tmp12_);
			_tmp14_ = _tmp13_;
			_tmp15_ = gtk_button_get_label ((GtkButton*) self);
			_tmp16_ = _tmp15_;
			_tmp17_ = string_replace (_tmp14_, _tmp16_, "0");
			_tmp18_ = _tmp17_;
			gtk_label_set_label (_tmp11_, _tmp18_);
			_g_free0 (_tmp18_);
		}
		_tmp19_ = proyecto_de_logica_override_label;
		_tmp20_ = gtk_label_get_label (_tmp19_);
		_tmp21_ = _tmp20_;
		if (g_strcmp0 (_tmp21_, "") != 0) {
			gboolean _tmp22_ = FALSE;
			gboolean _tmp23_ = FALSE;
			_tmp22_ = gtk_toggle_button_get_active ((GtkToggleButton*) self);
			_tmp23_ = _tmp22_;
			if (_tmp23_) {
				GtkLabel* _tmp24_ = NULL;
				GtkLabel* _tmp25_ = NULL;
				const gchar* _tmp26_ = NULL;
				const gchar* _tmp27_ = NULL;
				const gchar* _tmp28_ = NULL;
				const gchar* _tmp29_ = NULL;
				gchar* _tmp30_ = NULL;
				gchar* _tmp31_ = NULL;
				_tmp24_ = proyecto_de_logica_override_label;
				_tmp25_ = proyecto_de_logica_override_label;
				_tmp26_ = gtk_label_get_label (_tmp25_);
				_tmp27_ = _tmp26_;
				_tmp28_ = gtk_button_get_label ((GtkButton*) self);
				_tmp29_ = _tmp28_;
				_tmp30_ = string_replace (_tmp27_, _tmp29_, "1");
				_tmp31_ = _tmp30_;
				gtk_label_set_label (_tmp24_, _tmp31_);
				_g_free0 (_tmp31_);
			} else {
				GtkLabel* _tmp32_ = NULL;
				GtkLabel* _tmp33_ = NULL;
				const gchar* _tmp34_ = NULL;
				const gchar* _tmp35_ = NULL;
				const gchar* _tmp36_ = NULL;
				const gchar* _tmp37_ = NULL;
				gchar* _tmp38_ = NULL;
				gchar* _tmp39_ = NULL;
				_tmp32_ = proyecto_de_logica_override_label;
				_tmp33_ = proyecto_de_logica_override_label;
				_tmp34_ = gtk_label_get_label (_tmp33_);
				_tmp35_ = _tmp34_;
				_tmp36_ = gtk_button_get_label ((GtkButton*) self);
				_tmp37_ = _tmp36_;
				_tmp38_ = string_replace (_tmp35_, _tmp37_, "0");
				_tmp39_ = _tmp38_;
				gtk_label_set_label (_tmp32_, _tmp39_);
				_g_free0 (_tmp39_);
			}
		}
	}
	result = 1;
	return result;
}


gint proyecto_de_logica_letters_reset (ProyectoDeLogicaLetters* self) {
	gint result = 0;
	gboolean _tmp0_ = FALSE;
	g_return_val_if_fail (self != NULL, 0);
	_tmp0_ = self->priv->init;
	if (_tmp0_) {
		gtk_toggle_button_set_active ((GtkToggleButton*) self, FALSE);
		gtk_widget_set_sensitive ((GtkWidget*) self, TRUE);
	}
	result = 0;
	return result;
}


gint proyecto_de_logica_letters_letter_sensitive (ProyectoDeLogicaLetters* self, gboolean state) {
	gint result = 0;
	gboolean _tmp0_ = FALSE;
	g_return_val_if_fail (self != NULL, 0);
	_tmp0_ = self->priv->init;
	if (_tmp0_) {
		gboolean _tmp1_ = FALSE;
		gboolean _tmp2_ = FALSE;
		_tmp1_ = state;
		gtk_toggle_button_set_active ((GtkToggleButton*) self, _tmp1_);
		_tmp2_ = state;
		gtk_widget_set_sensitive ((GtkWidget*) self, _tmp2_);
	}
	result = 0;
	return result;
}


gint proyecto_de_logica_letters_state (ProyectoDeLogicaLetters* self) {
	gint result = 0;
	gboolean _tmp0_ = FALSE;
	g_return_val_if_fail (self != NULL, 0);
	_tmp0_ = self->priv->init;
	if (_tmp0_) {
		gboolean _tmp1_ = FALSE;
		gboolean _tmp2_ = FALSE;
		_tmp1_ = gtk_toggle_button_get_active ((GtkToggleButton*) self);
		_tmp2_ = _tmp1_;
		if (_tmp2_) {
			FILE* _tmp3_ = NULL;
			_tmp3_ = stderr;
			fprintf (_tmp3_, " V ");
			result = 1;
			return result;
		} else {
			FILE* _tmp4_ = NULL;
			_tmp4_ = stderr;
			fprintf (_tmp4_, " F ");
			result = 0;
			return result;
		}
	}
	result = -1;
	return result;
}


static const gchar* string_to_string (const gchar* self) {
	const gchar* result = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	result = self;
	return result;
}


gchar* proyecto_de_logica_letters_val (ProyectoDeLogicaLetters* self) {
	gchar* result = NULL;
	gboolean _tmp0_ = FALSE;
	gchar* _tmp11_ = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	_tmp0_ = self->priv->init;
	if (_tmp0_) {
		gboolean _tmp1_ = FALSE;
		gboolean _tmp2_ = FALSE;
		_tmp1_ = gtk_toggle_button_get_active ((GtkToggleButton*) self);
		_tmp2_ = _tmp1_;
		if (_tmp2_) {
			const gchar* _tmp3_ = NULL;
			const gchar* _tmp4_ = NULL;
			const gchar* _tmp5_ = NULL;
			gchar* _tmp6_ = NULL;
			_tmp3_ = gtk_button_get_label ((GtkButton*) self);
			_tmp4_ = _tmp3_;
			_tmp5_ = string_to_string (_tmp4_);
			_tmp6_ = g_strconcat (" ", _tmp5_, NULL);
			result = _tmp6_;
			return result;
		} else {
			const gchar* _tmp7_ = NULL;
			const gchar* _tmp8_ = NULL;
			const gchar* _tmp9_ = NULL;
			gchar* _tmp10_ = NULL;
			_tmp7_ = gtk_button_get_label ((GtkButton*) self);
			_tmp8_ = _tmp7_;
			_tmp9_ = string_to_string (_tmp8_);
			_tmp10_ = g_strconcat (" !", _tmp9_, NULL);
			result = _tmp10_;
			return result;
		}
	}
	_tmp11_ = g_strdup ("");
	result = _tmp11_;
	return result;
}


gint proyecto_de_logica_letters_toggle (ProyectoDeLogicaLetters* self) {
	gint result = 0;
	gboolean _tmp0_ = FALSE;
	g_return_val_if_fail (self != NULL, 0);
	_tmp0_ = self->priv->init;
	if (_tmp0_) {
		gboolean _tmp1_ = FALSE;
		gboolean _tmp2_ = FALSE;
		gboolean _tmp3_ = FALSE;
		gboolean _tmp4_ = FALSE;
		_tmp1_ = gtk_toggle_button_get_active ((GtkToggleButton*) self);
		_tmp2_ = _tmp1_;
		gtk_toggle_button_set_active ((GtkToggleButton*) self, !_tmp2_);
		_tmp3_ = gtk_toggle_button_get_active ((GtkToggleButton*) self);
		_tmp4_ = _tmp3_;
		if (_tmp4_) {
			result = 1;
			return result;
		} else {
			result = 0;
			return result;
		}
	} else {
		result = -1;
		return result;
	}
}


static gboolean string_contains (const gchar* self, const gchar* needle) {
	gboolean result = FALSE;
	const gchar* _tmp0_ = NULL;
	gchar* _tmp1_ = NULL;
	g_return_val_if_fail (self != NULL, FALSE);
	g_return_val_if_fail (needle != NULL, FALSE);
	_tmp0_ = needle;
	_tmp1_ = strstr ((gchar*) self, (gchar*) _tmp0_);
	result = _tmp1_ != NULL;
	return result;
}


static void __lambda5_ (ProyectoDeLogicaLetters* self) {
	GtkLabel* _tmp0_ = NULL;
	const gchar* _tmp1_ = NULL;
	GtkLabel* _tmp2_ = NULL;
	const gchar* _tmp3_ = NULL;
	ProyectoDeLogicaSolver* _tmp4_ = NULL;
	_tmp0_ = proyecto_de_logica_formula_label;
	_tmp1_ = proyecto_de_logica_originalfi;
	gtk_label_set_label (_tmp0_, _tmp1_);
	_tmp2_ = proyecto_de_logica_override_label;
	_tmp3_ = proyecto_de_logica_originaloverride;
	gtk_label_set_label (_tmp2_, _tmp3_);
	_tmp4_ = proyecto_de_logica_solver_box;
	g_signal_emit_by_name (_tmp4_, "update");
}


static void ___lambda5__gtk_toggle_button_toggled (GtkToggleButton* _sender, gpointer self) {
	__lambda5_ ((ProyectoDeLogicaLetters*) self);
}


ProyectoDeLogicaLetters* proyecto_de_logica_letters_construct (GType object_type, const gchar* letter) {
	ProyectoDeLogicaLetters * self = NULL;
	const gchar* _tmp0_ = NULL;
	const gchar* _tmp1_ = NULL;
	const gchar* _tmp2_ = NULL;
	const gchar* _tmp3_ = NULL;
	gboolean _tmp4_ = FALSE;
	g_return_val_if_fail (letter != NULL, NULL);
	self = (ProyectoDeLogicaLetters*) g_object_new (object_type, NULL);
	g_object_set ((GtkWidget*) self, "can-focus", FALSE, NULL);
	_tmp0_ = letter;
	_tmp1_ = string_to_string (_tmp0_);
	gtk_button_set_label ((GtkButton*) self, _tmp1_);
	_tmp2_ = proyecto_de_logica_originalfi;
	_tmp3_ = letter;
	_tmp4_ = string_contains (_tmp2_, _tmp3_);
	if (_tmp4_) {
		ProyectoDeLogicaSolver* _tmp5_ = NULL;
		GtkStyleContext* _tmp6_ = NULL;
		_tmp5_ = proyecto_de_logica_solver_box;
		gtk_container_add ((GtkContainer*) _tmp5_, (GtkWidget*) self);
		self->priv->init = TRUE;
		_tmp6_ = gtk_widget_get_style_context ((GtkWidget*) self);
		gtk_style_context_add_class (_tmp6_, "h3");
	}
	g_signal_connect_object ((GtkToggleButton*) self, "toggled", (GCallback) ___lambda5__gtk_toggle_button_toggled, self, 0);
	return self;
}


ProyectoDeLogicaLetters* proyecto_de_logica_letters_new (const gchar* letter) {
	return proyecto_de_logica_letters_construct (PROYECTO_DE_LOGICA_TYPE_LETTERS, letter);
}


static void proyecto_de_logica_letters_class_init (ProyectoDeLogicaLettersClass * klass) {
	proyecto_de_logica_letters_parent_class = g_type_class_peek_parent (klass);
	g_type_class_add_private (klass, sizeof (ProyectoDeLogicaLettersPrivate));
	G_OBJECT_CLASS (klass)->finalize = proyecto_de_logica_letters_finalize;
}


static void proyecto_de_logica_letters_instance_init (ProyectoDeLogicaLetters * self) {
	self->priv = PROYECTO_DE_LOGICA_LETTERS_GET_PRIVATE (self);
	self->priv->init = FALSE;
}


static void proyecto_de_logica_letters_finalize (GObject* obj) {
	ProyectoDeLogicaLetters * self;
	self = G_TYPE_CHECK_INSTANCE_CAST (obj, PROYECTO_DE_LOGICA_TYPE_LETTERS, ProyectoDeLogicaLetters);
	G_OBJECT_CLASS (proyecto_de_logica_letters_parent_class)->finalize (obj);
}


GType proyecto_de_logica_letters_get_type (void) {
	static volatile gsize proyecto_de_logica_letters_type_id__volatile = 0;
	if (g_once_init_enter (&proyecto_de_logica_letters_type_id__volatile)) {
		static const GTypeInfo g_define_type_info = { sizeof (ProyectoDeLogicaLettersClass), (GBaseInitFunc) NULL, (GBaseFinalizeFunc) NULL, (GClassInitFunc) proyecto_de_logica_letters_class_init, (GClassFinalizeFunc) NULL, NULL, sizeof (ProyectoDeLogicaLetters), 0, (GInstanceInitFunc) proyecto_de_logica_letters_instance_init, NULL };
		GType proyecto_de_logica_letters_type_id;
		proyecto_de_logica_letters_type_id = g_type_register_static (gtk_toggle_button_get_type (), "ProyectoDeLogicaLetters", &g_define_type_info, 0);
		g_once_init_leave (&proyecto_de_logica_letters_type_id__volatile, proyecto_de_logica_letters_type_id);
	}
	return proyecto_de_logica_letters_type_id__volatile;
}


gchar* proyecto_de_logica_solver_advanced_calculate (ProyectoDeLogicaSolver* self, const gchar* fi) {
	gchar* result = NULL;
	gchar* nfi = NULL;
	const gchar* _tmp0_ = NULL;
	gchar* _tmp1_ = NULL;
	const gchar* _tmp2_ = NULL;
	gboolean _tmp3_ = FALSE;
	const gchar* _tmp28_ = NULL;
	const gchar* _tmp29_ = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	g_return_val_if_fail (fi != NULL, NULL);
	_tmp0_ = fi;
	_tmp1_ = g_strdup (_tmp0_);
	nfi = _tmp1_;
	_tmp2_ = fi;
	_tmp3_ = string_contains (_tmp2_, "1,1");
	if (_tmp3_) {
		const gchar* _tmp4_ = NULL;
		gchar* _tmp5_ = NULL;
		_tmp4_ = fi;
		_tmp5_ = string_replace (_tmp4_, "1,1", "1");
		_g_free0 (nfi);
		nfi = _tmp5_;
	} else {
		const gchar* _tmp6_ = NULL;
		gboolean _tmp7_ = FALSE;
		_tmp6_ = fi;
		_tmp7_ = string_contains (_tmp6_, "1,0");
		if (_tmp7_) {
			const gchar* _tmp8_ = NULL;
			gchar* _tmp9_ = NULL;
			_tmp8_ = fi;
			_tmp9_ = string_replace (_tmp8_, "1,0", "0");
			_g_free0 (nfi);
			nfi = _tmp9_;
		} else {
			const gchar* _tmp10_ = NULL;
			gboolean _tmp11_ = FALSE;
			_tmp10_ = fi;
			_tmp11_ = string_contains (_tmp10_, "0,1");
			if (_tmp11_) {
				const gchar* _tmp12_ = NULL;
				gchar* _tmp13_ = NULL;
				_tmp12_ = fi;
				_tmp13_ = string_replace (_tmp12_, "0,1", "0");
				_g_free0 (nfi);
				nfi = _tmp13_;
			} else {
				const gchar* _tmp14_ = NULL;
				gboolean _tmp15_ = FALSE;
				_tmp14_ = fi;
				_tmp15_ = string_contains (_tmp14_, "0,0");
				if (_tmp15_) {
					const gchar* _tmp16_ = NULL;
					gchar* _tmp17_ = NULL;
					_tmp16_ = fi;
					_tmp17_ = string_replace (_tmp16_, "0,0", "0");
					_g_free0 (nfi);
					nfi = _tmp17_;
				} else {
					const gchar* _tmp18_ = NULL;
					gboolean _tmp19_ = FALSE;
					_tmp18_ = fi;
					_tmp19_ = string_contains (_tmp18_, "!(0)");
					if (_tmp19_) {
						const gchar* _tmp20_ = NULL;
						gchar* _tmp21_ = NULL;
						_tmp20_ = fi;
						_tmp21_ = string_replace (_tmp20_, "!(0)", "1");
						_g_free0 (nfi);
						nfi = _tmp21_;
					} else {
						const gchar* _tmp22_ = NULL;
						gboolean _tmp23_ = FALSE;
						_tmp22_ = fi;
						_tmp23_ = string_contains (_tmp22_, "!(1)");
						if (_tmp23_) {
							const gchar* _tmp24_ = NULL;
							gchar* _tmp25_ = NULL;
							_tmp24_ = fi;
							_tmp25_ = string_replace (_tmp24_, "!(1)", "0");
							_g_free0 (nfi);
							nfi = _tmp25_;
						} else {
							const gchar* _tmp26_ = NULL;
							gchar* _tmp27_ = NULL;
							_tmp26_ = fi;
							_tmp27_ = g_strdup (_tmp26_);
							_g_free0 (nfi);
							nfi = _tmp27_;
						}
					}
				}
			}
		}
	}
	_tmp28_ = nfi;
	_tmp29_ = fi;
	if (g_strcmp0 (_tmp28_, _tmp29_) == 0) {
		const gchar* _tmp30_ = NULL;
		gchar* _tmp31_ = NULL;
		_tmp30_ = fi;
		_tmp31_ = g_strdup (_tmp30_);
		result = _tmp31_;
		_g_free0 (nfi);
		return result;
	} else {
		const gchar* _tmp32_ = NULL;
		gchar* _tmp33_ = NULL;
		_tmp32_ = nfi;
		_tmp33_ = proyecto_de_logica_solver_advanced_calculate (self, _tmp32_);
		result = _tmp33_;
		_g_free0 (nfi);
		return result;
	}
	_g_free0 (nfi);
}


gchar* proyecto_de_logica_solver_Calculate (ProyectoDeLogicaSolver* self, const gchar* fi) {
	gchar* result = NULL;
	gchar* nfi = NULL;
	const gchar* _tmp0_ = NULL;
	gchar* _tmp1_ = NULL;
	const gchar* _tmp2_ = NULL;
	gboolean _tmp3_ = FALSE;
	const gchar* _tmp152_ = NULL;
	const gchar* _tmp153_ = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	g_return_val_if_fail (fi != NULL, NULL);
	_tmp0_ = fi;
	_tmp1_ = g_strdup (_tmp0_);
	nfi = _tmp1_;
	_tmp2_ = fi;
	_tmp3_ = string_contains (_tmp2_, "(1&1)");
	if (_tmp3_) {
		const gchar* _tmp4_ = NULL;
		gchar* _tmp5_ = NULL;
		_tmp4_ = fi;
		_tmp5_ = string_replace (_tmp4_, "(1&1)", "1");
		_g_free0 (nfi);
		nfi = _tmp5_;
	} else {
		const gchar* _tmp6_ = NULL;
		gboolean _tmp7_ = FALSE;
		_tmp6_ = fi;
		_tmp7_ = string_contains (_tmp6_, "(1&0)");
		if (_tmp7_) {
			const gchar* _tmp8_ = NULL;
			gchar* _tmp9_ = NULL;
			_tmp8_ = fi;
			_tmp9_ = string_replace (_tmp8_, "(1&0)", "0");
			_g_free0 (nfi);
			nfi = _tmp9_;
		} else {
			const gchar* _tmp10_ = NULL;
			gboolean _tmp11_ = FALSE;
			_tmp10_ = fi;
			_tmp11_ = string_contains (_tmp10_, "(0&1)");
			if (_tmp11_) {
				const gchar* _tmp12_ = NULL;
				gchar* _tmp13_ = NULL;
				_tmp12_ = fi;
				_tmp13_ = string_replace (_tmp12_, "(0&1)", "0");
				_g_free0 (nfi);
				nfi = _tmp13_;
			} else {
				const gchar* _tmp14_ = NULL;
				gboolean _tmp15_ = FALSE;
				_tmp14_ = fi;
				_tmp15_ = string_contains (_tmp14_, "(0&0)");
				if (_tmp15_) {
					const gchar* _tmp16_ = NULL;
					gchar* _tmp17_ = NULL;
					_tmp16_ = fi;
					_tmp17_ = string_replace (_tmp16_, "(0&0)", "0");
					_g_free0 (nfi);
					nfi = _tmp17_;
				} else {
					const gchar* _tmp18_ = NULL;
					gboolean _tmp19_ = FALSE;
					_tmp18_ = fi;
					_tmp19_ = string_contains (_tmp18_, "(1|1)");
					if (_tmp19_) {
						const gchar* _tmp20_ = NULL;
						gchar* _tmp21_ = NULL;
						_tmp20_ = fi;
						_tmp21_ = string_replace (_tmp20_, "(1|1)", "1");
						_g_free0 (nfi);
						nfi = _tmp21_;
					} else {
						const gchar* _tmp22_ = NULL;
						gboolean _tmp23_ = FALSE;
						_tmp22_ = fi;
						_tmp23_ = string_contains (_tmp22_, "(1|0)");
						if (_tmp23_) {
							const gchar* _tmp24_ = NULL;
							gchar* _tmp25_ = NULL;
							_tmp24_ = fi;
							_tmp25_ = string_replace (_tmp24_, "(1|0)", "1");
							_g_free0 (nfi);
							nfi = _tmp25_;
						} else {
							const gchar* _tmp26_ = NULL;
							gboolean _tmp27_ = FALSE;
							_tmp26_ = fi;
							_tmp27_ = string_contains (_tmp26_, "(0|1)");
							if (_tmp27_) {
								const gchar* _tmp28_ = NULL;
								gchar* _tmp29_ = NULL;
								_tmp28_ = fi;
								_tmp29_ = string_replace (_tmp28_, "(0|1)", "1");
								_g_free0 (nfi);
								nfi = _tmp29_;
							} else {
								const gchar* _tmp30_ = NULL;
								gboolean _tmp31_ = FALSE;
								_tmp30_ = fi;
								_tmp31_ = string_contains (_tmp30_, "(0|0)");
								if (_tmp31_) {
									const gchar* _tmp32_ = NULL;
									gchar* _tmp33_ = NULL;
									_tmp32_ = fi;
									_tmp33_ = string_replace (_tmp32_, "(0|0)", "0");
									_g_free0 (nfi);
									nfi = _tmp33_;
								} else {
									const gchar* _tmp34_ = NULL;
									gboolean _tmp35_ = FALSE;
									_tmp34_ = fi;
									_tmp35_ = string_contains (_tmp34_, "(1⇒1)");
									if (_tmp35_) {
										const gchar* _tmp36_ = NULL;
										gchar* _tmp37_ = NULL;
										_tmp36_ = fi;
										_tmp37_ = string_replace (_tmp36_, "(1⇒1)", "1");
										_g_free0 (nfi);
										nfi = _tmp37_;
									} else {
										const gchar* _tmp38_ = NULL;
										gboolean _tmp39_ = FALSE;
										_tmp38_ = fi;
										_tmp39_ = string_contains (_tmp38_, "(1⇒0)");
										if (_tmp39_) {
											const gchar* _tmp40_ = NULL;
											gchar* _tmp41_ = NULL;
											_tmp40_ = fi;
											_tmp41_ = string_replace (_tmp40_, "(1⇒0)", "0");
											_g_free0 (nfi);
											nfi = _tmp41_;
										} else {
											const gchar* _tmp42_ = NULL;
											gboolean _tmp43_ = FALSE;
											_tmp42_ = fi;
											_tmp43_ = string_contains (_tmp42_, "(0⇒1)");
											if (_tmp43_) {
												const gchar* _tmp44_ = NULL;
												gchar* _tmp45_ = NULL;
												_tmp44_ = fi;
												_tmp45_ = string_replace (_tmp44_, "(0⇒1)", "1");
												_g_free0 (nfi);
												nfi = _tmp45_;
											} else {
												const gchar* _tmp46_ = NULL;
												gboolean _tmp47_ = FALSE;
												_tmp46_ = fi;
												_tmp47_ = string_contains (_tmp46_, "(0⇒0)");
												if (_tmp47_) {
													const gchar* _tmp48_ = NULL;
													gchar* _tmp49_ = NULL;
													_tmp48_ = fi;
													_tmp49_ = string_replace (_tmp48_, "(0⇒0)", "1");
													_g_free0 (nfi);
													nfi = _tmp49_;
												} else {
													const gchar* _tmp50_ = NULL;
													gboolean _tmp51_ = FALSE;
													_tmp50_ = fi;
													_tmp51_ = string_contains (_tmp50_, "(1⇔1)");
													if (_tmp51_) {
														const gchar* _tmp52_ = NULL;
														gchar* _tmp53_ = NULL;
														_tmp52_ = fi;
														_tmp53_ = string_replace (_tmp52_, "(1⇔1)", "1");
														_g_free0 (nfi);
														nfi = _tmp53_;
													} else {
														const gchar* _tmp54_ = NULL;
														gboolean _tmp55_ = FALSE;
														_tmp54_ = fi;
														_tmp55_ = string_contains (_tmp54_, "(1⇔0)");
														if (_tmp55_) {
															const gchar* _tmp56_ = NULL;
															gchar* _tmp57_ = NULL;
															_tmp56_ = fi;
															_tmp57_ = string_replace (_tmp56_, "(1⇔0)", "0");
															_g_free0 (nfi);
															nfi = _tmp57_;
														} else {
															const gchar* _tmp58_ = NULL;
															gboolean _tmp59_ = FALSE;
															_tmp58_ = fi;
															_tmp59_ = string_contains (_tmp58_, "(0⇔1)");
															if (_tmp59_) {
																const gchar* _tmp60_ = NULL;
																gchar* _tmp61_ = NULL;
																_tmp60_ = fi;
																_tmp61_ = string_replace (_tmp60_, "(0⇔1)", "0");
																_g_free0 (nfi);
																nfi = _tmp61_;
															} else {
																const gchar* _tmp62_ = NULL;
																gboolean _tmp63_ = FALSE;
																_tmp62_ = fi;
																_tmp63_ = string_contains (_tmp62_, "(0⇔0)");
																if (_tmp63_) {
																	const gchar* _tmp64_ = NULL;
																	gchar* _tmp65_ = NULL;
																	_tmp64_ = fi;
																	_tmp65_ = string_replace (_tmp64_, "(0⇔0)", "1");
																	_g_free0 (nfi);
																	nfi = _tmp65_;
																} else {
																	const gchar* _tmp66_ = NULL;
																	gboolean _tmp67_ = FALSE;
																	_tmp66_ = fi;
																	_tmp67_ = string_contains (_tmp66_, "!0");
																	if (_tmp67_) {
																		const gchar* _tmp68_ = NULL;
																		gchar* _tmp69_ = NULL;
																		_tmp68_ = fi;
																		_tmp69_ = string_replace (_tmp68_, "!0", "1");
																		_g_free0 (nfi);
																		nfi = _tmp69_;
																	} else {
																		const gchar* _tmp70_ = NULL;
																		gboolean _tmp71_ = FALSE;
																		_tmp70_ = fi;
																		_tmp71_ = string_contains (_tmp70_, "!1");
																		if (_tmp71_) {
																			const gchar* _tmp72_ = NULL;
																			gchar* _tmp73_ = NULL;
																			_tmp72_ = fi;
																			_tmp73_ = string_replace (_tmp72_, "!1", "0");
																			_g_free0 (nfi);
																			nfi = _tmp73_;
																		} else {
																			const gchar* _tmp74_ = NULL;
																			gboolean _tmp75_ = FALSE;
																			_tmp74_ = fi;
																			_tmp75_ = string_contains (_tmp74_, "!(0)");
																			if (_tmp75_) {
																				const gchar* _tmp76_ = NULL;
																				gchar* _tmp77_ = NULL;
																				_tmp76_ = fi;
																				_tmp77_ = string_replace (_tmp76_, "!(0)", "1");
																				_g_free0 (nfi);
																				nfi = _tmp77_;
																			} else {
																				const gchar* _tmp78_ = NULL;
																				gboolean _tmp79_ = FALSE;
																				_tmp78_ = fi;
																				_tmp79_ = string_contains (_tmp78_, "!(1)");
																				if (_tmp79_) {
																					const gchar* _tmp80_ = NULL;
																					gchar* _tmp81_ = NULL;
																					_tmp80_ = fi;
																					_tmp81_ = string_replace (_tmp80_, "!(1)", "0");
																					_g_free0 (nfi);
																					nfi = _tmp81_;
																				} else {
																					const gchar* _tmp82_ = NULL;
																					gboolean _tmp83_ = FALSE;
																					_tmp82_ = fi;
																					_tmp83_ = string_contains (_tmp82_, "(1⇑1)");
																					if (_tmp83_) {
																						const gchar* _tmp84_ = NULL;
																						gchar* _tmp85_ = NULL;
																						_tmp84_ = fi;
																						_tmp85_ = string_replace (_tmp84_, "(1⇑1)", "0");
																						_g_free0 (nfi);
																						nfi = _tmp85_;
																					} else {
																						const gchar* _tmp86_ = NULL;
																						gboolean _tmp87_ = FALSE;
																						_tmp86_ = fi;
																						_tmp87_ = string_contains (_tmp86_, "(1⇑0)");
																						if (_tmp87_) {
																							const gchar* _tmp88_ = NULL;
																							gchar* _tmp89_ = NULL;
																							_tmp88_ = fi;
																							_tmp89_ = string_replace (_tmp88_, "(1⇑0)", "1");
																							_g_free0 (nfi);
																							nfi = _tmp89_;
																						} else {
																							const gchar* _tmp90_ = NULL;
																							gboolean _tmp91_ = FALSE;
																							_tmp90_ = fi;
																							_tmp91_ = string_contains (_tmp90_, "(0⇑1)");
																							if (_tmp91_) {
																								const gchar* _tmp92_ = NULL;
																								gchar* _tmp93_ = NULL;
																								_tmp92_ = fi;
																								_tmp93_ = string_replace (_tmp92_, "(0⇑1)", "1");
																								_g_free0 (nfi);
																								nfi = _tmp93_;
																							} else {
																								const gchar* _tmp94_ = NULL;
																								gboolean _tmp95_ = FALSE;
																								_tmp94_ = fi;
																								_tmp95_ = string_contains (_tmp94_, "(0⇑0)");
																								if (_tmp95_) {
																									const gchar* _tmp96_ = NULL;
																									gchar* _tmp97_ = NULL;
																									_tmp96_ = fi;
																									_tmp97_ = string_replace (_tmp96_, "(0⇑0)", "1");
																									_g_free0 (nfi);
																									nfi = _tmp97_;
																								} else {
																									const gchar* _tmp98_ = NULL;
																									gboolean _tmp99_ = FALSE;
																									_tmp98_ = fi;
																									_tmp99_ = string_contains (_tmp98_, "(1⇓1)");
																									if (_tmp99_) {
																										const gchar* _tmp100_ = NULL;
																										gchar* _tmp101_ = NULL;
																										_tmp100_ = fi;
																										_tmp101_ = string_replace (_tmp100_, "(1⇓1)", "0");
																										_g_free0 (nfi);
																										nfi = _tmp101_;
																									} else {
																										const gchar* _tmp102_ = NULL;
																										gboolean _tmp103_ = FALSE;
																										_tmp102_ = fi;
																										_tmp103_ = string_contains (_tmp102_, "(1⇓0)");
																										if (_tmp103_) {
																											const gchar* _tmp104_ = NULL;
																											gchar* _tmp105_ = NULL;
																											_tmp104_ = fi;
																											_tmp105_ = string_replace (_tmp104_, "(1⇓0)", "0");
																											_g_free0 (nfi);
																											nfi = _tmp105_;
																										} else {
																											const gchar* _tmp106_ = NULL;
																											gboolean _tmp107_ = FALSE;
																											_tmp106_ = fi;
																											_tmp107_ = string_contains (_tmp106_, "(0⇓1)");
																											if (_tmp107_) {
																												const gchar* _tmp108_ = NULL;
																												gchar* _tmp109_ = NULL;
																												_tmp108_ = fi;
																												_tmp109_ = string_replace (_tmp108_, "(0⇓1)", "0");
																												_g_free0 (nfi);
																												nfi = _tmp109_;
																											} else {
																												const gchar* _tmp110_ = NULL;
																												gboolean _tmp111_ = FALSE;
																												_tmp110_ = fi;
																												_tmp111_ = string_contains (_tmp110_, "(0⇓0)");
																												if (_tmp111_) {
																													const gchar* _tmp112_ = NULL;
																													gchar* _tmp113_ = NULL;
																													_tmp112_ = fi;
																													_tmp113_ = string_replace (_tmp112_, "(0⇓0)", "1");
																													_g_free0 (nfi);
																													nfi = _tmp113_;
																												} else {
																													const gchar* _tmp114_ = NULL;
																													gboolean _tmp115_ = FALSE;
																													_tmp114_ = fi;
																													_tmp115_ = string_contains (_tmp114_, "(0)");
																													if (_tmp115_) {
																														const gchar* _tmp116_ = NULL;
																														gchar* _tmp117_ = NULL;
																														_tmp116_ = fi;
																														_tmp117_ = string_replace (_tmp116_, "(0)", "0");
																														_g_free0 (nfi);
																														nfi = _tmp117_;
																													} else {
																														const gchar* _tmp118_ = NULL;
																														gboolean _tmp119_ = FALSE;
																														_tmp118_ = fi;
																														_tmp119_ = string_contains (_tmp118_, "(1)");
																														if (_tmp119_) {
																															const gchar* _tmp120_ = NULL;
																															gchar* _tmp121_ = NULL;
																															_tmp120_ = fi;
																															_tmp121_ = string_replace (_tmp120_, "(1)", "1");
																															_g_free0 (nfi);
																															nfi = _tmp121_;
																														} else {
																															const gchar* _tmp122_ = NULL;
																															gboolean _tmp123_ = FALSE;
																															_tmp122_ = fi;
																															_tmp123_ = string_contains (_tmp122_, "{");
																															if (_tmp123_) {
																																const gchar* _tmp124_ = NULL;
																																gchar* _tmp125_ = NULL;
																																_tmp124_ = fi;
																																_tmp125_ = string_replace (_tmp124_, "{", "(");
																																_g_free0 (nfi);
																																nfi = _tmp125_;
																															} else {
																																const gchar* _tmp126_ = NULL;
																																gboolean _tmp127_ = FALSE;
																																_tmp126_ = fi;
																																_tmp127_ = string_contains (_tmp126_, "}");
																																if (_tmp127_) {
																																	const gchar* _tmp128_ = NULL;
																																	gchar* _tmp129_ = NULL;
																																	_tmp128_ = fi;
																																	_tmp129_ = string_replace (_tmp128_, "}", ")");
																																	_g_free0 (nfi);
																																	nfi = _tmp129_;
																																} else {
																																	const gchar* _tmp130_ = NULL;
																																	gboolean _tmp131_ = FALSE;
																																	_tmp130_ = fi;
																																	_tmp131_ = string_contains (_tmp130_, "[");
																																	if (_tmp131_) {
																																		const gchar* _tmp132_ = NULL;
																																		gchar* _tmp133_ = NULL;
																																		_tmp132_ = fi;
																																		_tmp133_ = string_replace (_tmp132_, "[", "(");
																																		_g_free0 (nfi);
																																		nfi = _tmp133_;
																																	} else {
																																		const gchar* _tmp134_ = NULL;
																																		gboolean _tmp135_ = FALSE;
																																		_tmp134_ = fi;
																																		_tmp135_ = string_contains (_tmp134_, "]");
																																		if (_tmp135_) {
																																			const gchar* _tmp136_ = NULL;
																																			gchar* _tmp137_ = NULL;
																																			_tmp136_ = fi;
																																			_tmp137_ = string_replace (_tmp136_, "]", ")");
																																			_g_free0 (nfi);
																																			nfi = _tmp137_;
																																		} else {
																																			const gchar* _tmp138_ = NULL;
																																			gboolean _tmp139_ = FALSE;
																																			_tmp138_ = fi;
																																			_tmp139_ = string_contains (_tmp138_, " ");
																																			if (_tmp139_) {
																																				const gchar* _tmp140_ = NULL;
																																				gchar* _tmp141_ = NULL;
																																				_tmp140_ = fi;
																																				_tmp141_ = string_replace (_tmp140_, " ", "");
																																				_g_free0 (nfi);
																																				nfi = _tmp141_;
																																			} else {
																																				const gchar* _tmp142_ = NULL;
																																				gboolean _tmp143_ = FALSE;
																																				_tmp142_ = fi;
																																				_tmp143_ = string_contains (_tmp142_, ",!(◻)");
																																				if (_tmp143_) {
																																					const gchar* _tmp144_ = NULL;
																																					gchar* _tmp145_ = NULL;
																																					_tmp144_ = fi;
																																					_tmp145_ = string_replace (_tmp144_, ",!(◻)", "");
																																					_g_free0 (nfi);
																																					nfi = _tmp145_;
																																				} else {
																																					const gchar* _tmp146_ = NULL;
																																					gboolean _tmp147_ = FALSE;
																																					_tmp146_ = fi;
																																					_tmp147_ = string_contains (_tmp146_, "◻,");
																																					if (_tmp147_) {
																																						const gchar* _tmp148_ = NULL;
																																						gchar* _tmp149_ = NULL;
																																						_tmp148_ = fi;
																																						_tmp149_ = string_replace (_tmp148_, "◻,", "");
																																						_g_free0 (nfi);
																																						nfi = _tmp149_;
																																					} else {
																																						const gchar* _tmp150_ = NULL;
																																						gchar* _tmp151_ = NULL;
																																						_tmp150_ = fi;
																																						_tmp151_ = g_strdup (_tmp150_);
																																						_g_free0 (nfi);
																																						nfi = _tmp151_;
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	_tmp152_ = nfi;
	_tmp153_ = fi;
	if (g_strcmp0 (_tmp152_, _tmp153_) == 0) {
		GtkSwitch* _tmp154_ = NULL;
		gboolean _tmp155_ = FALSE;
		gboolean _tmp156_ = FALSE;
		_tmp154_ = proyecto_de_logica_formula_toggle;
		_tmp155_ = gtk_switch_get_state (_tmp154_);
		_tmp156_ = _tmp155_;
		if (_tmp156_ == FALSE) {
			const gchar* _tmp157_ = NULL;
			gchar* _tmp158_ = NULL;
			_tmp157_ = fi;
			_tmp158_ = g_strdup (_tmp157_);
			result = _tmp158_;
			_g_free0 (nfi);
			return result;
		} else {
			const gchar* _tmp159_ = NULL;
			gchar* _tmp160_ = NULL;
			_tmp159_ = nfi;
			_tmp160_ = proyecto_de_logica_solver_advanced_calculate (self, _tmp159_);
			result = _tmp160_;
			_g_free0 (nfi);
			return result;
		}
	} else {
		const gchar* _tmp161_ = NULL;
		gchar* _tmp162_ = NULL;
		_tmp161_ = nfi;
		_tmp162_ = proyecto_de_logica_solver_Calculate (self, _tmp161_);
		result = _tmp162_;
		_g_free0 (nfi);
		return result;
	}
	_g_free0 (nfi);
}


static Block2Data* block2_data_ref (Block2Data* _data2_) {
	g_atomic_int_inc (&_data2_->_ref_count_);
	return _data2_;
}


static void block2_data_unref (void * _userdata_) {
	Block2Data* _data2_;
	_data2_ = (Block2Data*) _userdata_;
	if (g_atomic_int_dec_and_test (&_data2_->_ref_count_)) {
		ProyectoDeLogicaSolver* self;
		self = _data2_->self;
		_g_object_unref0 (_data2_->return_button);
		_g_object_unref0 (_data2_->solve_button);
		_g_object_unref0 (_data2_->step_solve_button);
		_g_object_unref0 (self);
		g_slice_free (Block2Data, _data2_);
	}
}


static void __lambda4_ (Block2Data* _data2_) {
	ProyectoDeLogicaSolver* self;
	GtkLabel* _tmp0_ = NULL;
	const gchar* _tmp1_ = NULL;
	GtkLabel* _tmp2_ = NULL;
	const gchar* _tmp3_ = NULL;
	GtkHeaderBar* _tmp4_ = NULL;
	GtkToolButton* _tmp5_ = NULL;
	self = _data2_->self;
	_tmp0_ = proyecto_de_logica_formula_label;
	_tmp1_ = proyecto_de_logica_originalfi;
	gtk_label_set_label (_tmp0_, _tmp1_);
	_tmp2_ = proyecto_de_logica_override_label;
	_tmp3_ = proyecto_de_logica_originaloverride;
	gtk_label_set_label (_tmp2_, _tmp3_);
	_tmp4_ = proyecto_de_logica_headerbar;
	gtk_header_bar_set_subtitle (_tmp4_, "By: Felipe y Fer");
	_tmp5_ = self->priv->refresh_button;
	gtk_widget_set_sensitive ((GtkWidget*) _tmp5_, FALSE);
	gtk_widget_set_sensitive ((GtkWidget*) _data2_->solve_button, TRUE);
	gtk_widget_set_sensitive ((GtkWidget*) _data2_->step_solve_button, TRUE);
	proyecto_de_logica_solver_reset_letters (self);
}


static void ___lambda4__gtk_tool_button_clicked (GtkToolButton* _sender, gpointer self) {
	__lambda4_ (self);
}


static void __lambda6_ (Block2Data* _data2_) {
	ProyectoDeLogicaSolver* self;
	ProyectoDeLogicaResolution* resolution = NULL;
	ProyectoDeLogicaResolution* _tmp0_ = NULL;
	ProyectoDeLogicaResolution* _tmp1_ = NULL;
	gchar* _tmp2_ = NULL;
	gchar* _tmp3_ = NULL;
	FILE* _tmp27_ = NULL;
	GtkHeaderBar* _tmp28_ = NULL;
	const gchar* _tmp29_ = NULL;
	const gchar* _tmp30_ = NULL;
	const gchar* _tmp31_ = NULL;
	gchar* _tmp32_ = NULL;
	gchar* _tmp33_ = NULL;
	FILE* _tmp34_ = NULL;
	ProyectoDeLogicaResolution* _tmp35_ = NULL;
	gboolean _tmp36_ = FALSE;
	GtkSwitch* _tmp37_ = NULL;
	gboolean _tmp38_ = FALSE;
	gboolean _tmp39_ = FALSE;
	GtkSwitch* _tmp48_ = NULL;
	gboolean _tmp49_ = FALSE;
	gboolean _tmp50_ = FALSE;
	GtkLabel* _tmp52_ = NULL;
	const gchar* _tmp53_ = NULL;
	GtkLabel* _tmp54_ = NULL;
	const gchar* _tmp55_ = NULL;
	self = _data2_->self;
	_tmp0_ = proyecto_de_logica_resolution_new ("", "(G|F)");
	resolution = _tmp0_;
	proyecto_de_logica_solver_reset_letters (self);
	gtk_widget_set_sensitive ((GtkWidget*) _data2_->solve_button, FALSE);
	proyecto_de_logica_solver_letters_sensitive (self, FALSE);
	_tmp1_ = resolution;
	_tmp2_ = proyecto_de_logica_solver_row_FNC (self);
	_tmp3_ = _tmp2_;
	proyecto_de_logica_resolution_add_formula (_tmp1_, _tmp3_);
	_g_free0 (_tmp3_);
	while (TRUE) {
		gint _tmp4_ = 0;
		FILE* _tmp5_ = NULL;
		GtkHeaderBar* _tmp6_ = NULL;
		const gchar* _tmp7_ = NULL;
		const gchar* _tmp8_ = NULL;
		const gchar* _tmp9_ = NULL;
		gchar* _tmp10_ = NULL;
		gchar* _tmp11_ = NULL;
		ProyectoDeLogicaResolution* _tmp12_ = NULL;
		gchar* _tmp13_ = NULL;
		gchar* _tmp14_ = NULL;
		gboolean _tmp15_ = FALSE;
		GtkSwitch* _tmp16_ = NULL;
		gboolean _tmp17_ = FALSE;
		gboolean _tmp18_ = FALSE;
		_tmp4_ = proyecto_de_logica_solver_auto_solver (self);
		if (!(_tmp4_ != 1)) {
			break;
		}
		proyecto_de_logica_solver_letter_states (self);
		_tmp5_ = stderr;
		_tmp6_ = proyecto_de_logica_headerbar;
		_tmp7_ = gtk_header_bar_get_subtitle (_tmp6_);
		_tmp8_ = _tmp7_;
		_tmp9_ = string_to_string (_tmp8_);
		_tmp10_ = g_strconcat (" :: ", _tmp9_, "\n", NULL);
		_tmp11_ = _tmp10_;
		fprintf (_tmp5_, "%s", _tmp11_);
		_g_free0 (_tmp11_);
		_tmp12_ = resolution;
		_tmp13_ = proyecto_de_logica_solver_row_FNC (self);
		_tmp14_ = _tmp13_;
		proyecto_de_logica_resolution_add_formula (_tmp12_, _tmp14_);
		_g_free0 (_tmp14_);
		_tmp16_ = proyecto_de_logica_formula_toggle;
		_tmp17_ = gtk_switch_get_state (_tmp16_);
		_tmp18_ = _tmp17_;
		if (_tmp18_ == TRUE) {
			GtkHeaderBar* _tmp19_ = NULL;
			const gchar* _tmp20_ = NULL;
			const gchar* _tmp21_ = NULL;
			_tmp19_ = proyecto_de_logica_headerbar;
			_tmp20_ = gtk_header_bar_get_subtitle (_tmp19_);
			_tmp21_ = _tmp20_;
			_tmp15_ = g_strcmp0 (_tmp21_, "1") == 0;
		} else {
			_tmp15_ = FALSE;
		}
		if (_tmp15_) {
			GtkLabel* _tmp22_ = NULL;
			const gchar* _tmp23_ = NULL;
			GtkLabel* _tmp24_ = NULL;
			const gchar* _tmp25_ = NULL;
			GtkHeaderBar* _tmp26_ = NULL;
			proyecto_de_logica_solver_reset_letters (self);
			_tmp22_ = proyecto_de_logica_formula_label;
			_tmp23_ = proyecto_de_logica_originalfi;
			gtk_label_set_label (_tmp22_, _tmp23_);
			_tmp24_ = proyecto_de_logica_override_label;
			_tmp25_ = proyecto_de_logica_originaloverride;
			gtk_label_set_label (_tmp24_, _tmp25_);
			_tmp26_ = proyecto_de_logica_headerbar;
			gtk_header_bar_set_subtitle (_tmp26_, "Invalid Formula");
			_g_object_unref0 (resolution);
			return;
		}
	}
	proyecto_de_logica_solver_letter_states (self);
	_tmp27_ = stderr;
	_tmp28_ = proyecto_de_logica_headerbar;
	_tmp29_ = gtk_header_bar_get_subtitle (_tmp28_);
	_tmp30_ = _tmp29_;
	_tmp31_ = string_to_string (_tmp30_);
	_tmp32_ = g_strconcat (" :: ", _tmp31_, "\n", NULL);
	_tmp33_ = _tmp32_;
	fprintf (_tmp27_, "%s", _tmp33_);
	_g_free0 (_tmp33_);
	_tmp34_ = stderr;
	fprintf (_tmp34_, "%s", "\n");
	_tmp35_ = resolution;
	proyecto_de_logica_resolution_solve (_tmp35_);
	_tmp37_ = proyecto_de_logica_formula_toggle;
	_tmp38_ = gtk_switch_get_state (_tmp37_);
	_tmp39_ = _tmp38_;
	if (_tmp39_ == TRUE) {
		GtkHeaderBar* _tmp40_ = NULL;
		const gchar* _tmp41_ = NULL;
		const gchar* _tmp42_ = NULL;
		_tmp40_ = proyecto_de_logica_headerbar;
		_tmp41_ = gtk_header_bar_get_subtitle (_tmp40_);
		_tmp42_ = _tmp41_;
		_tmp36_ = g_strcmp0 (_tmp42_, "1") == 0;
	} else {
		_tmp36_ = FALSE;
	}
	if (_tmp36_) {
		GtkLabel* _tmp43_ = NULL;
		const gchar* _tmp44_ = NULL;
		GtkLabel* _tmp45_ = NULL;
		const gchar* _tmp46_ = NULL;
		GtkHeaderBar* _tmp47_ = NULL;
		proyecto_de_logica_solver_reset_letters (self);
		_tmp43_ = proyecto_de_logica_formula_label;
		_tmp44_ = proyecto_de_logica_originalfi;
		gtk_label_set_label (_tmp43_, _tmp44_);
		_tmp45_ = proyecto_de_logica_override_label;
		_tmp46_ = proyecto_de_logica_originaloverride;
		gtk_label_set_label (_tmp45_, _tmp46_);
		_tmp47_ = proyecto_de_logica_headerbar;
		gtk_header_bar_set_subtitle (_tmp47_, "Invalid Formula");
		_g_object_unref0 (resolution);
		return;
	}
	proyecto_de_logica_solver_letters_sensitive (self, TRUE);
	_tmp48_ = proyecto_de_logica_formula_toggle;
	_tmp49_ = gtk_switch_get_state (_tmp48_);
	_tmp50_ = _tmp49_;
	if (_tmp50_ == TRUE) {
		GtkHeaderBar* _tmp51_ = NULL;
		_tmp51_ = proyecto_de_logica_headerbar;
		gtk_header_bar_set_subtitle (_tmp51_, "Valid Formula");
	}
	_tmp52_ = proyecto_de_logica_formula_label;
	_tmp53_ = proyecto_de_logica_originalfi;
	gtk_label_set_label (_tmp52_, _tmp53_);
	_tmp54_ = proyecto_de_logica_override_label;
	_tmp55_ = proyecto_de_logica_originaloverride;
	gtk_label_set_label (_tmp54_, _tmp55_);
	_g_object_unref0 (resolution);
}


static void ___lambda6__gtk_tool_button_clicked (GtkToolButton* _sender, gpointer self) {
	__lambda6_ (self);
}


static void __lambda7_ (Block2Data* _data2_) {
	ProyectoDeLogicaSolver* self;
	self = _data2_->self;
	gtk_widget_set_sensitive ((GtkWidget*) _data2_->solve_button, TRUE);
	proyecto_de_logica_solver_auto_solver (self);
}


static void ___lambda7__gtk_tool_button_clicked (GtkToolButton* _sender, gpointer self) {
	__lambda7_ (self);
}


static void __lambda8_ (Block2Data* _data2_) {
	ProyectoDeLogicaSolver* self;
	GtkWindow* _tmp0_ = NULL;
	ProyectoDeLogicaSolver* _tmp1_ = NULL;
	GtkWindow* _tmp2_ = NULL;
	GtkBox* _tmp3_ = NULL;
	GtkWindow* _tmp4_ = NULL;
	GtkHeaderBar* _tmp5_ = NULL;
	GtkHeaderBar* _tmp6_ = NULL;
	GtkHeaderBar* _tmp7_ = NULL;
	GtkHeaderBar* _tmp8_ = NULL;
	GtkToolButton* _tmp9_ = NULL;
	GtkHeaderBar* _tmp10_ = NULL;
	GtkSwitch* _tmp11_ = NULL;
	GtkHeaderBar* _tmp12_ = NULL;
	GtkHeaderBar* _tmp13_ = NULL;
	self = _data2_->self;
	_tmp0_ = proyecto_de_logica_app;
	_tmp1_ = proyecto_de_logica_solver_box;
	gtk_container_remove ((GtkContainer*) _tmp0_, (GtkWidget*) _tmp1_);
	_tmp2_ = proyecto_de_logica_app;
	_tmp3_ = proyecto_de_logica_mainbox;
	gtk_container_add ((GtkContainer*) _tmp2_, (GtkWidget*) _tmp3_);
	_tmp4_ = proyecto_de_logica_app;
	gtk_window_resize (_tmp4_, 1, 1);
	_tmp5_ = proyecto_de_logica_headerbar;
	gtk_container_remove ((GtkContainer*) _tmp5_, (GtkWidget*) _data2_->return_button);
	_tmp6_ = proyecto_de_logica_headerbar;
	gtk_container_remove ((GtkContainer*) _tmp6_, (GtkWidget*) _data2_->step_solve_button);
	_tmp7_ = proyecto_de_logica_headerbar;
	gtk_container_remove ((GtkContainer*) _tmp7_, (GtkWidget*) _data2_->solve_button);
	_tmp8_ = proyecto_de_logica_headerbar;
	_tmp9_ = self->priv->refresh_button;
	gtk_container_remove ((GtkContainer*) _tmp8_, (GtkWidget*) _tmp9_);
	_tmp10_ = proyecto_de_logica_headerbar;
	_tmp11_ = proyecto_de_logica_formula_toggle;
	gtk_header_bar_pack_end (_tmp10_, (GtkWidget*) _tmp11_);
	_tmp12_ = proyecto_de_logica_headerbar;
	gtk_header_bar_set_title (_tmp12_, "Logic Calculator");
	_tmp13_ = proyecto_de_logica_headerbar;
	gtk_header_bar_set_subtitle (_tmp13_, "By: Felipe Escoto");
}


static void ___lambda8__gtk_tool_button_clicked (GtkToolButton* _sender, gpointer self) {
	__lambda8_ (self);
}


ProyectoDeLogicaSolver* proyecto_de_logica_solver_construct (GType object_type) {
	ProyectoDeLogicaSolver * self = NULL;
	Block2Data* _data2_;
	GtkHeaderBar* _tmp0_ = NULL;
	GtkHeaderBar* _tmp1_ = NULL;
	GtkHeaderBar* _tmp2_ = NULL;
	GtkToolButton* _tmp3_ = NULL;
	GtkToolButton* _tmp4_ = NULL;
	GtkToolButton* _tmp5_ = NULL;
	GtkToolButton* _tmp6_ = NULL;
	GtkToolButton* _tmp7_ = NULL;
	GtkToolButton* _tmp8_ = NULL;
	GtkToolButton* _tmp9_ = NULL;
	GtkToolButton* _tmp10_ = NULL;
	GtkHeaderBar* _tmp11_ = NULL;
	GtkHeaderBar* _tmp12_ = NULL;
	GtkHeaderBar* _tmp13_ = NULL;
	GtkHeaderBar* _tmp14_ = NULL;
	GtkToolButton* _tmp15_ = NULL;
	GtkWindow* _tmp16_ = NULL;
	_data2_ = g_slice_new0 (Block2Data);
	_data2_->_ref_count_ = 1;
	self = (ProyectoDeLogicaSolver*) g_object_new (object_type, NULL);
	_data2_->self = g_object_ref (self);
	_tmp0_ = proyecto_de_logica_headerbar;
	gtk_header_bar_set_title (_tmp0_, "Logic Solver");
	_tmp1_ = proyecto_de_logica_headerbar;
	gtk_header_bar_set_subtitle (_tmp1_, "By: Felipe y Fer");
	_tmp2_ = proyecto_de_logica_headerbar;
	gtk_header_bar_set_show_close_button (_tmp2_, TRUE);
	_tmp3_ = (GtkToolButton*) gtk_tool_button_new_from_stock (GTK_STOCK_GO_FORWARD);
	g_object_ref_sink (_tmp3_);
	_data2_->step_solve_button = _tmp3_;
	_tmp4_ = (GtkToolButton*) gtk_tool_button_new_from_stock (GTK_STOCK_JUMP_TO);
	g_object_ref_sink (_tmp4_);
	_data2_->solve_button = _tmp4_;
	_tmp5_ = (GtkToolButton*) gtk_tool_button_new_from_stock (GTK_STOCK_REFRESH);
	g_object_ref_sink (_tmp5_);
	_g_object_unref0 (self->priv->refresh_button);
	self->priv->refresh_button = _tmp5_;
	_tmp6_ = self->priv->refresh_button;
	gtk_tool_item_set_tooltip_text ((GtkToolItem*) _tmp6_, "Restore formula");
	_tmp7_ = self->priv->refresh_button;
	gtk_widget_set_sensitive ((GtkWidget*) _tmp7_, FALSE);
	_tmp8_ = self->priv->refresh_button;
	g_signal_connect_data (_tmp8_, "clicked", (GCallback) ___lambda4__gtk_tool_button_clicked, block2_data_ref (_data2_), (GClosureNotify) block2_data_unref, 0);
	gtk_tool_item_set_tooltip_text ((GtkToolItem*) _data2_->solve_button, "Auto-solve");
	g_signal_connect_data (_data2_->solve_button, "clicked", (GCallback) ___lambda6__gtk_tool_button_clicked, block2_data_ref (_data2_), (GClosureNotify) block2_data_unref, 0);
	gtk_tool_item_set_tooltip_text ((GtkToolItem*) _data2_->step_solve_button, "Step by step");
	g_signal_connect_data (_data2_->step_solve_button, "clicked", (GCallback) ___lambda7__gtk_tool_button_clicked, block2_data_ref (_data2_), (GClosureNotify) block2_data_unref, 0);
	_tmp9_ = (GtkToolButton*) gtk_tool_button_new_from_stock (GTK_STOCK_GO_BACK);
	g_object_ref_sink (_tmp9_);
	_data2_->return_button = _tmp9_;
	gtk_tool_item_set_tooltip_text ((GtkToolItem*) _data2_->return_button, "Formula editor");
	g_signal_connect_data (_data2_->return_button, "clicked", (GCallback) ___lambda8__gtk_tool_button_clicked, block2_data_ref (_data2_), (GClosureNotify) block2_data_unref, 0);
	gtk_tool_item_set_tooltip_text ((GtkToolItem*) _data2_->solve_button, "Terminal Needed to\ndisplay truth table");
	_tmp10_ = self->priv->refresh_button;
	g_object_set ((GtkWidget*) _tmp10_, "can-focus", FALSE, NULL);
	g_object_set ((GtkWidget*) _data2_->solve_button, "can-focus", FALSE, NULL);
	_tmp11_ = proyecto_de_logica_headerbar;
	gtk_header_bar_pack_start (_tmp11_, (GtkWidget*) _data2_->return_button);
	_tmp12_ = proyecto_de_logica_headerbar;
	gtk_header_bar_pack_end (_tmp12_, (GtkWidget*) _data2_->solve_button);
	_tmp13_ = proyecto_de_logica_headerbar;
	gtk_header_bar_pack_end (_tmp13_, (GtkWidget*) _data2_->step_solve_button);
	_tmp14_ = proyecto_de_logica_headerbar;
	_tmp15_ = self->priv->refresh_button;
	gtk_header_bar_pack_end (_tmp14_, (GtkWidget*) _tmp15_);
	_tmp16_ = proyecto_de_logica_app;
	gtk_widget_show_all ((GtkWidget*) _tmp16_);
	block2_data_unref (_data2_);
	_data2_ = NULL;
	return self;
}


ProyectoDeLogicaSolver* proyecto_de_logica_solver_new (void) {
	return proyecto_de_logica_solver_construct (PROYECTO_DE_LOGICA_TYPE_SOLVER);
}


gint proyecto_de_logica_solver_letter_states (ProyectoDeLogicaSolver* self) {
	gint result = 0;
	ProyectoDeLogicaLetters* _tmp0_ = NULL;
	ProyectoDeLogicaLetters* _tmp1_ = NULL;
	ProyectoDeLogicaLetters* _tmp2_ = NULL;
	ProyectoDeLogicaLetters* _tmp3_ = NULL;
	ProyectoDeLogicaLetters* _tmp4_ = NULL;
	ProyectoDeLogicaLetters* _tmp5_ = NULL;
	ProyectoDeLogicaLetters* _tmp6_ = NULL;
	ProyectoDeLogicaLetters* _tmp7_ = NULL;
	ProyectoDeLogicaLetters* _tmp8_ = NULL;
	ProyectoDeLogicaLetters* _tmp9_ = NULL;
	ProyectoDeLogicaLetters* _tmp10_ = NULL;
	ProyectoDeLogicaLetters* _tmp11_ = NULL;
	ProyectoDeLogicaLetters* _tmp12_ = NULL;
	ProyectoDeLogicaLetters* _tmp13_ = NULL;
	ProyectoDeLogicaLetters* _tmp14_ = NULL;
	ProyectoDeLogicaLetters* _tmp15_ = NULL;
	ProyectoDeLogicaLetters* _tmp16_ = NULL;
	ProyectoDeLogicaLetters* _tmp17_ = NULL;
	ProyectoDeLogicaLetters* _tmp18_ = NULL;
	ProyectoDeLogicaLetters* _tmp19_ = NULL;
	ProyectoDeLogicaLetters* _tmp20_ = NULL;
	ProyectoDeLogicaLetters* _tmp21_ = NULL;
	ProyectoDeLogicaLetters* _tmp22_ = NULL;
	ProyectoDeLogicaLetters* _tmp23_ = NULL;
	ProyectoDeLogicaLetters* _tmp24_ = NULL;
	ProyectoDeLogicaLetters* _tmp25_ = NULL;
	g_return_val_if_fail (self != NULL, 0);
	_tmp0_ = proyecto_de_logica_A;
	proyecto_de_logica_letters_state (_tmp0_);
	_tmp1_ = proyecto_de_logica_B;
	proyecto_de_logica_letters_state (_tmp1_);
	_tmp2_ = proyecto_de_logica_C;
	proyecto_de_logica_letters_state (_tmp2_);
	_tmp3_ = proyecto_de_logica_D;
	proyecto_de_logica_letters_state (_tmp3_);
	_tmp4_ = proyecto_de_logica_E;
	proyecto_de_logica_letters_state (_tmp4_);
	_tmp5_ = proyecto_de_logica_F;
	proyecto_de_logica_letters_state (_tmp5_);
	_tmp6_ = proyecto_de_logica_G;
	proyecto_de_logica_letters_state (_tmp6_);
	_tmp7_ = proyecto_de_logica_H;
	proyecto_de_logica_letters_state (_tmp7_);
	_tmp8_ = proyecto_de_logica_I;
	proyecto_de_logica_letters_state (_tmp8_);
	_tmp9_ = proyecto_de_logica_J;
	proyecto_de_logica_letters_state (_tmp9_);
	_tmp10_ = proyecto_de_logica_K;
	proyecto_de_logica_letters_state (_tmp10_);
	_tmp11_ = proyecto_de_logica_L;
	proyecto_de_logica_letters_state (_tmp11_);
	_tmp12_ = proyecto_de_logica_M;
	proyecto_de_logica_letters_state (_tmp12_);
	_tmp13_ = proyecto_de_logica_N;
	proyecto_de_logica_letters_state (_tmp13_);
	_tmp14_ = proyecto_de_logica_O;
	proyecto_de_logica_letters_state (_tmp14_);
	_tmp15_ = proyecto_de_logica_P;
	proyecto_de_logica_letters_state (_tmp15_);
	_tmp16_ = proyecto_de_logica_Q;
	proyecto_de_logica_letters_state (_tmp16_);
	_tmp17_ = proyecto_de_logica_R;
	proyecto_de_logica_letters_state (_tmp17_);
	_tmp18_ = proyecto_de_logica_S;
	proyecto_de_logica_letters_state (_tmp18_);
	_tmp19_ = proyecto_de_logica_T;
	proyecto_de_logica_letters_state (_tmp19_);
	_tmp20_ = proyecto_de_logica_U;
	proyecto_de_logica_letters_state (_tmp20_);
	_tmp21_ = proyecto_de_logica_V;
	proyecto_de_logica_letters_state (_tmp21_);
	_tmp22_ = proyecto_de_logica_W;
	proyecto_de_logica_letters_state (_tmp22_);
	_tmp23_ = proyecto_de_logica_X;
	proyecto_de_logica_letters_state (_tmp23_);
	_tmp24_ = proyecto_de_logica_Y;
	proyecto_de_logica_letters_state (_tmp24_);
	_tmp25_ = proyecto_de_logica_Z;
	proyecto_de_logica_letters_state (_tmp25_);
	result = 1;
	return result;
}


gint proyecto_de_logica_solver_reset_letters (ProyectoDeLogicaSolver* self) {
	gint result = 0;
	ProyectoDeLogicaLetters* _tmp0_ = NULL;
	ProyectoDeLogicaLetters* _tmp1_ = NULL;
	ProyectoDeLogicaLetters* _tmp2_ = NULL;
	ProyectoDeLogicaLetters* _tmp3_ = NULL;
	ProyectoDeLogicaLetters* _tmp4_ = NULL;
	ProyectoDeLogicaLetters* _tmp5_ = NULL;
	ProyectoDeLogicaLetters* _tmp6_ = NULL;
	ProyectoDeLogicaLetters* _tmp7_ = NULL;
	ProyectoDeLogicaLetters* _tmp8_ = NULL;
	ProyectoDeLogicaLetters* _tmp9_ = NULL;
	ProyectoDeLogicaLetters* _tmp10_ = NULL;
	ProyectoDeLogicaLetters* _tmp11_ = NULL;
	ProyectoDeLogicaLetters* _tmp12_ = NULL;
	ProyectoDeLogicaLetters* _tmp13_ = NULL;
	ProyectoDeLogicaLetters* _tmp14_ = NULL;
	ProyectoDeLogicaLetters* _tmp15_ = NULL;
	ProyectoDeLogicaLetters* _tmp16_ = NULL;
	ProyectoDeLogicaLetters* _tmp17_ = NULL;
	ProyectoDeLogicaLetters* _tmp18_ = NULL;
	ProyectoDeLogicaLetters* _tmp19_ = NULL;
	ProyectoDeLogicaLetters* _tmp20_ = NULL;
	ProyectoDeLogicaLetters* _tmp21_ = NULL;
	ProyectoDeLogicaLetters* _tmp22_ = NULL;
	ProyectoDeLogicaLetters* _tmp23_ = NULL;
	ProyectoDeLogicaLetters* _tmp24_ = NULL;
	ProyectoDeLogicaLetters* _tmp25_ = NULL;
	g_return_val_if_fail (self != NULL, 0);
	_tmp0_ = proyecto_de_logica_A;
	proyecto_de_logica_letters_reset (_tmp0_);
	_tmp1_ = proyecto_de_logica_B;
	proyecto_de_logica_letters_reset (_tmp1_);
	_tmp2_ = proyecto_de_logica_C;
	proyecto_de_logica_letters_reset (_tmp2_);
	_tmp3_ = proyecto_de_logica_D;
	proyecto_de_logica_letters_reset (_tmp3_);
	_tmp4_ = proyecto_de_logica_E;
	proyecto_de_logica_letters_reset (_tmp4_);
	_tmp5_ = proyecto_de_logica_F;
	proyecto_de_logica_letters_reset (_tmp5_);
	_tmp6_ = proyecto_de_logica_G;
	proyecto_de_logica_letters_reset (_tmp6_);
	_tmp7_ = proyecto_de_logica_H;
	proyecto_de_logica_letters_reset (_tmp7_);
	_tmp8_ = proyecto_de_logica_I;
	proyecto_de_logica_letters_reset (_tmp8_);
	_tmp9_ = proyecto_de_logica_J;
	proyecto_de_logica_letters_reset (_tmp9_);
	_tmp10_ = proyecto_de_logica_K;
	proyecto_de_logica_letters_reset (_tmp10_);
	_tmp11_ = proyecto_de_logica_L;
	proyecto_de_logica_letters_reset (_tmp11_);
	_tmp12_ = proyecto_de_logica_M;
	proyecto_de_logica_letters_reset (_tmp12_);
	_tmp13_ = proyecto_de_logica_N;
	proyecto_de_logica_letters_reset (_tmp13_);
	_tmp14_ = proyecto_de_logica_O;
	proyecto_de_logica_letters_reset (_tmp14_);
	_tmp15_ = proyecto_de_logica_P;
	proyecto_de_logica_letters_reset (_tmp15_);
	_tmp16_ = proyecto_de_logica_Q;
	proyecto_de_logica_letters_reset (_tmp16_);
	_tmp17_ = proyecto_de_logica_R;
	proyecto_de_logica_letters_reset (_tmp17_);
	_tmp18_ = proyecto_de_logica_S;
	proyecto_de_logica_letters_reset (_tmp18_);
	_tmp19_ = proyecto_de_logica_T;
	proyecto_de_logica_letters_reset (_tmp19_);
	_tmp20_ = proyecto_de_logica_U;
	proyecto_de_logica_letters_reset (_tmp20_);
	_tmp21_ = proyecto_de_logica_V;
	proyecto_de_logica_letters_reset (_tmp21_);
	_tmp22_ = proyecto_de_logica_W;
	proyecto_de_logica_letters_reset (_tmp22_);
	_tmp23_ = proyecto_de_logica_X;
	proyecto_de_logica_letters_reset (_tmp23_);
	_tmp24_ = proyecto_de_logica_Y;
	proyecto_de_logica_letters_reset (_tmp24_);
	_tmp25_ = proyecto_de_logica_Z;
	proyecto_de_logica_letters_reset (_tmp25_);
	result = 1;
	return result;
}


gchar* proyecto_de_logica_solver_row_FNC (ProyectoDeLogicaSolver* self) {
	gchar* result = NULL;
	ProyectoDeLogicaLetters* _tmp0_ = NULL;
	gchar* _tmp1_ = NULL;
	gchar* _tmp2_ = NULL;
	const gchar* _tmp3_ = NULL;
	ProyectoDeLogicaLetters* _tmp4_ = NULL;
	gchar* _tmp5_ = NULL;
	gchar* _tmp6_ = NULL;
	const gchar* _tmp7_ = NULL;
	ProyectoDeLogicaLetters* _tmp8_ = NULL;
	gchar* _tmp9_ = NULL;
	gchar* _tmp10_ = NULL;
	const gchar* _tmp11_ = NULL;
	ProyectoDeLogicaLetters* _tmp12_ = NULL;
	gchar* _tmp13_ = NULL;
	gchar* _tmp14_ = NULL;
	const gchar* _tmp15_ = NULL;
	ProyectoDeLogicaLetters* _tmp16_ = NULL;
	gchar* _tmp17_ = NULL;
	gchar* _tmp18_ = NULL;
	const gchar* _tmp19_ = NULL;
	ProyectoDeLogicaLetters* _tmp20_ = NULL;
	gchar* _tmp21_ = NULL;
	gchar* _tmp22_ = NULL;
	const gchar* _tmp23_ = NULL;
	ProyectoDeLogicaLetters* _tmp24_ = NULL;
	gchar* _tmp25_ = NULL;
	gchar* _tmp26_ = NULL;
	const gchar* _tmp27_ = NULL;
	ProyectoDeLogicaLetters* _tmp28_ = NULL;
	gchar* _tmp29_ = NULL;
	gchar* _tmp30_ = NULL;
	const gchar* _tmp31_ = NULL;
	ProyectoDeLogicaLetters* _tmp32_ = NULL;
	gchar* _tmp33_ = NULL;
	gchar* _tmp34_ = NULL;
	const gchar* _tmp35_ = NULL;
	ProyectoDeLogicaLetters* _tmp36_ = NULL;
	gchar* _tmp37_ = NULL;
	gchar* _tmp38_ = NULL;
	const gchar* _tmp39_ = NULL;
	ProyectoDeLogicaLetters* _tmp40_ = NULL;
	gchar* _tmp41_ = NULL;
	gchar* _tmp42_ = NULL;
	const gchar* _tmp43_ = NULL;
	ProyectoDeLogicaLetters* _tmp44_ = NULL;
	gchar* _tmp45_ = NULL;
	gchar* _tmp46_ = NULL;
	const gchar* _tmp47_ = NULL;
	ProyectoDeLogicaLetters* _tmp48_ = NULL;
	gchar* _tmp49_ = NULL;
	gchar* _tmp50_ = NULL;
	const gchar* _tmp51_ = NULL;
	ProyectoDeLogicaLetters* _tmp52_ = NULL;
	gchar* _tmp53_ = NULL;
	gchar* _tmp54_ = NULL;
	const gchar* _tmp55_ = NULL;
	ProyectoDeLogicaLetters* _tmp56_ = NULL;
	gchar* _tmp57_ = NULL;
	gchar* _tmp58_ = NULL;
	const gchar* _tmp59_ = NULL;
	ProyectoDeLogicaLetters* _tmp60_ = NULL;
	gchar* _tmp61_ = NULL;
	gchar* _tmp62_ = NULL;
	const gchar* _tmp63_ = NULL;
	ProyectoDeLogicaLetters* _tmp64_ = NULL;
	gchar* _tmp65_ = NULL;
	gchar* _tmp66_ = NULL;
	const gchar* _tmp67_ = NULL;
	ProyectoDeLogicaLetters* _tmp68_ = NULL;
	gchar* _tmp69_ = NULL;
	gchar* _tmp70_ = NULL;
	const gchar* _tmp71_ = NULL;
	ProyectoDeLogicaLetters* _tmp72_ = NULL;
	gchar* _tmp73_ = NULL;
	gchar* _tmp74_ = NULL;
	const gchar* _tmp75_ = NULL;
	ProyectoDeLogicaLetters* _tmp76_ = NULL;
	gchar* _tmp77_ = NULL;
	gchar* _tmp78_ = NULL;
	const gchar* _tmp79_ = NULL;
	ProyectoDeLogicaLetters* _tmp80_ = NULL;
	gchar* _tmp81_ = NULL;
	gchar* _tmp82_ = NULL;
	const gchar* _tmp83_ = NULL;
	ProyectoDeLogicaLetters* _tmp84_ = NULL;
	gchar* _tmp85_ = NULL;
	gchar* _tmp86_ = NULL;
	const gchar* _tmp87_ = NULL;
	ProyectoDeLogicaLetters* _tmp88_ = NULL;
	gchar* _tmp89_ = NULL;
	gchar* _tmp90_ = NULL;
	const gchar* _tmp91_ = NULL;
	ProyectoDeLogicaLetters* _tmp92_ = NULL;
	gchar* _tmp93_ = NULL;
	gchar* _tmp94_ = NULL;
	const gchar* _tmp95_ = NULL;
	ProyectoDeLogicaLetters* _tmp96_ = NULL;
	gchar* _tmp97_ = NULL;
	gchar* _tmp98_ = NULL;
	const gchar* _tmp99_ = NULL;
	ProyectoDeLogicaLetters* _tmp100_ = NULL;
	gchar* _tmp101_ = NULL;
	gchar* _tmp102_ = NULL;
	const gchar* _tmp103_ = NULL;
	gchar* _tmp104_ = NULL;
	gchar* _tmp105_ = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	_tmp0_ = proyecto_de_logica_A;
	_tmp1_ = proyecto_de_logica_letters_val (_tmp0_);
	_tmp2_ = _tmp1_;
	_tmp3_ = string_to_string (_tmp2_);
	_tmp4_ = proyecto_de_logica_B;
	_tmp5_ = proyecto_de_logica_letters_val (_tmp4_);
	_tmp6_ = _tmp5_;
	_tmp7_ = string_to_string (_tmp6_);
	_tmp8_ = proyecto_de_logica_C;
	_tmp9_ = proyecto_de_logica_letters_val (_tmp8_);
	_tmp10_ = _tmp9_;
	_tmp11_ = string_to_string (_tmp10_);
	_tmp12_ = proyecto_de_logica_D;
	_tmp13_ = proyecto_de_logica_letters_val (_tmp12_);
	_tmp14_ = _tmp13_;
	_tmp15_ = string_to_string (_tmp14_);
	_tmp16_ = proyecto_de_logica_E;
	_tmp17_ = proyecto_de_logica_letters_val (_tmp16_);
	_tmp18_ = _tmp17_;
	_tmp19_ = string_to_string (_tmp18_);
	_tmp20_ = proyecto_de_logica_F;
	_tmp21_ = proyecto_de_logica_letters_val (_tmp20_);
	_tmp22_ = _tmp21_;
	_tmp23_ = string_to_string (_tmp22_);
	_tmp24_ = proyecto_de_logica_G;
	_tmp25_ = proyecto_de_logica_letters_val (_tmp24_);
	_tmp26_ = _tmp25_;
	_tmp27_ = string_to_string (_tmp26_);
	_tmp28_ = proyecto_de_logica_H;
	_tmp29_ = proyecto_de_logica_letters_val (_tmp28_);
	_tmp30_ = _tmp29_;
	_tmp31_ = string_to_string (_tmp30_);
	_tmp32_ = proyecto_de_logica_I;
	_tmp33_ = proyecto_de_logica_letters_val (_tmp32_);
	_tmp34_ = _tmp33_;
	_tmp35_ = string_to_string (_tmp34_);
	_tmp36_ = proyecto_de_logica_J;
	_tmp37_ = proyecto_de_logica_letters_val (_tmp36_);
	_tmp38_ = _tmp37_;
	_tmp39_ = string_to_string (_tmp38_);
	_tmp40_ = proyecto_de_logica_K;
	_tmp41_ = proyecto_de_logica_letters_val (_tmp40_);
	_tmp42_ = _tmp41_;
	_tmp43_ = string_to_string (_tmp42_);
	_tmp44_ = proyecto_de_logica_L;
	_tmp45_ = proyecto_de_logica_letters_val (_tmp44_);
	_tmp46_ = _tmp45_;
	_tmp47_ = string_to_string (_tmp46_);
	_tmp48_ = proyecto_de_logica_M;
	_tmp49_ = proyecto_de_logica_letters_val (_tmp48_);
	_tmp50_ = _tmp49_;
	_tmp51_ = string_to_string (_tmp50_);
	_tmp52_ = proyecto_de_logica_N;
	_tmp53_ = proyecto_de_logica_letters_val (_tmp52_);
	_tmp54_ = _tmp53_;
	_tmp55_ = string_to_string (_tmp54_);
	_tmp56_ = proyecto_de_logica_O;
	_tmp57_ = proyecto_de_logica_letters_val (_tmp56_);
	_tmp58_ = _tmp57_;
	_tmp59_ = string_to_string (_tmp58_);
	_tmp60_ = proyecto_de_logica_P;
	_tmp61_ = proyecto_de_logica_letters_val (_tmp60_);
	_tmp62_ = _tmp61_;
	_tmp63_ = string_to_string (_tmp62_);
	_tmp64_ = proyecto_de_logica_Q;
	_tmp65_ = proyecto_de_logica_letters_val (_tmp64_);
	_tmp66_ = _tmp65_;
	_tmp67_ = string_to_string (_tmp66_);
	_tmp68_ = proyecto_de_logica_R;
	_tmp69_ = proyecto_de_logica_letters_val (_tmp68_);
	_tmp70_ = _tmp69_;
	_tmp71_ = string_to_string (_tmp70_);
	_tmp72_ = proyecto_de_logica_S;
	_tmp73_ = proyecto_de_logica_letters_val (_tmp72_);
	_tmp74_ = _tmp73_;
	_tmp75_ = string_to_string (_tmp74_);
	_tmp76_ = proyecto_de_logica_T;
	_tmp77_ = proyecto_de_logica_letters_val (_tmp76_);
	_tmp78_ = _tmp77_;
	_tmp79_ = string_to_string (_tmp78_);
	_tmp80_ = proyecto_de_logica_U;
	_tmp81_ = proyecto_de_logica_letters_val (_tmp80_);
	_tmp82_ = _tmp81_;
	_tmp83_ = string_to_string (_tmp82_);
	_tmp84_ = proyecto_de_logica_V;
	_tmp85_ = proyecto_de_logica_letters_val (_tmp84_);
	_tmp86_ = _tmp85_;
	_tmp87_ = string_to_string (_tmp86_);
	_tmp88_ = proyecto_de_logica_W;
	_tmp89_ = proyecto_de_logica_letters_val (_tmp88_);
	_tmp90_ = _tmp89_;
	_tmp91_ = string_to_string (_tmp90_);
	_tmp92_ = proyecto_de_logica_X;
	_tmp93_ = proyecto_de_logica_letters_val (_tmp92_);
	_tmp94_ = _tmp93_;
	_tmp95_ = string_to_string (_tmp94_);
	_tmp96_ = proyecto_de_logica_Y;
	_tmp97_ = proyecto_de_logica_letters_val (_tmp96_);
	_tmp98_ = _tmp97_;
	_tmp99_ = string_to_string (_tmp98_);
	_tmp100_ = proyecto_de_logica_Z;
	_tmp101_ = proyecto_de_logica_letters_val (_tmp100_);
	_tmp102_ = _tmp101_;
	_tmp103_ = string_to_string (_tmp102_);
	_tmp104_ = g_strconcat (_tmp3_, _tmp7_, _tmp11_, _tmp15_, _tmp19_, _tmp23_, _tmp27_, _tmp31_, _tmp35_, _tmp39_, _tmp43_, _tmp47_, _tmp51_, _tmp55_, _tmp59_, _tmp63_, _tmp67_, _tmp71_, _tmp75_, _tmp79_, _tmp83_, _tmp87_, _tmp91_, _tmp95_, _tmp99_, _tmp103_, NULL);
	_tmp105_ = _tmp104_;
	_g_free0 (_tmp102_);
	_g_free0 (_tmp98_);
	_g_free0 (_tmp94_);
	_g_free0 (_tmp90_);
	_g_free0 (_tmp86_);
	_g_free0 (_tmp82_);
	_g_free0 (_tmp78_);
	_g_free0 (_tmp74_);
	_g_free0 (_tmp70_);
	_g_free0 (_tmp66_);
	_g_free0 (_tmp62_);
	_g_free0 (_tmp58_);
	_g_free0 (_tmp54_);
	_g_free0 (_tmp50_);
	_g_free0 (_tmp46_);
	_g_free0 (_tmp42_);
	_g_free0 (_tmp38_);
	_g_free0 (_tmp34_);
	_g_free0 (_tmp30_);
	_g_free0 (_tmp26_);
	_g_free0 (_tmp22_);
	_g_free0 (_tmp18_);
	_g_free0 (_tmp14_);
	_g_free0 (_tmp10_);
	_g_free0 (_tmp6_);
	_g_free0 (_tmp2_);
	result = _tmp105_;
	return result;
}


gint proyecto_de_logica_solver_letters_sensitive (ProyectoDeLogicaSolver* self, gboolean state) {
	gint result = 0;
	ProyectoDeLogicaLetters* _tmp0_ = NULL;
	gboolean _tmp1_ = FALSE;
	ProyectoDeLogicaLetters* _tmp2_ = NULL;
	gboolean _tmp3_ = FALSE;
	ProyectoDeLogicaLetters* _tmp4_ = NULL;
	gboolean _tmp5_ = FALSE;
	ProyectoDeLogicaLetters* _tmp6_ = NULL;
	gboolean _tmp7_ = FALSE;
	ProyectoDeLogicaLetters* _tmp8_ = NULL;
	gboolean _tmp9_ = FALSE;
	ProyectoDeLogicaLetters* _tmp10_ = NULL;
	gboolean _tmp11_ = FALSE;
	ProyectoDeLogicaLetters* _tmp12_ = NULL;
	gboolean _tmp13_ = FALSE;
	ProyectoDeLogicaLetters* _tmp14_ = NULL;
	gboolean _tmp15_ = FALSE;
	ProyectoDeLogicaLetters* _tmp16_ = NULL;
	gboolean _tmp17_ = FALSE;
	ProyectoDeLogicaLetters* _tmp18_ = NULL;
	gboolean _tmp19_ = FALSE;
	ProyectoDeLogicaLetters* _tmp20_ = NULL;
	gboolean _tmp21_ = FALSE;
	ProyectoDeLogicaLetters* _tmp22_ = NULL;
	gboolean _tmp23_ = FALSE;
	ProyectoDeLogicaLetters* _tmp24_ = NULL;
	gboolean _tmp25_ = FALSE;
	ProyectoDeLogicaLetters* _tmp26_ = NULL;
	gboolean _tmp27_ = FALSE;
	ProyectoDeLogicaLetters* _tmp28_ = NULL;
	gboolean _tmp29_ = FALSE;
	ProyectoDeLogicaLetters* _tmp30_ = NULL;
	gboolean _tmp31_ = FALSE;
	ProyectoDeLogicaLetters* _tmp32_ = NULL;
	gboolean _tmp33_ = FALSE;
	ProyectoDeLogicaLetters* _tmp34_ = NULL;
	gboolean _tmp35_ = FALSE;
	ProyectoDeLogicaLetters* _tmp36_ = NULL;
	gboolean _tmp37_ = FALSE;
	ProyectoDeLogicaLetters* _tmp38_ = NULL;
	gboolean _tmp39_ = FALSE;
	ProyectoDeLogicaLetters* _tmp40_ = NULL;
	gboolean _tmp41_ = FALSE;
	ProyectoDeLogicaLetters* _tmp42_ = NULL;
	gboolean _tmp43_ = FALSE;
	ProyectoDeLogicaLetters* _tmp44_ = NULL;
	gboolean _tmp45_ = FALSE;
	ProyectoDeLogicaLetters* _tmp46_ = NULL;
	gboolean _tmp47_ = FALSE;
	ProyectoDeLogicaLetters* _tmp48_ = NULL;
	gboolean _tmp49_ = FALSE;
	ProyectoDeLogicaLetters* _tmp50_ = NULL;
	gboolean _tmp51_ = FALSE;
	g_return_val_if_fail (self != NULL, 0);
	_tmp0_ = proyecto_de_logica_A;
	_tmp1_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp0_, _tmp1_);
	_tmp2_ = proyecto_de_logica_B;
	_tmp3_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp2_, _tmp3_);
	_tmp4_ = proyecto_de_logica_C;
	_tmp5_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp4_, _tmp5_);
	_tmp6_ = proyecto_de_logica_D;
	_tmp7_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp6_, _tmp7_);
	_tmp8_ = proyecto_de_logica_E;
	_tmp9_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp8_, _tmp9_);
	_tmp10_ = proyecto_de_logica_F;
	_tmp11_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp10_, _tmp11_);
	_tmp12_ = proyecto_de_logica_G;
	_tmp13_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp12_, _tmp13_);
	_tmp14_ = proyecto_de_logica_H;
	_tmp15_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp14_, _tmp15_);
	_tmp16_ = proyecto_de_logica_I;
	_tmp17_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp16_, _tmp17_);
	_tmp18_ = proyecto_de_logica_J;
	_tmp19_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp18_, _tmp19_);
	_tmp20_ = proyecto_de_logica_K;
	_tmp21_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp20_, _tmp21_);
	_tmp22_ = proyecto_de_logica_L;
	_tmp23_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp22_, _tmp23_);
	_tmp24_ = proyecto_de_logica_M;
	_tmp25_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp24_, _tmp25_);
	_tmp26_ = proyecto_de_logica_N;
	_tmp27_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp26_, _tmp27_);
	_tmp28_ = proyecto_de_logica_O;
	_tmp29_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp28_, _tmp29_);
	_tmp30_ = proyecto_de_logica_P;
	_tmp31_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp30_, _tmp31_);
	_tmp32_ = proyecto_de_logica_Q;
	_tmp33_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp32_, _tmp33_);
	_tmp34_ = proyecto_de_logica_R;
	_tmp35_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp34_, _tmp35_);
	_tmp36_ = proyecto_de_logica_S;
	_tmp37_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp36_, _tmp37_);
	_tmp38_ = proyecto_de_logica_T;
	_tmp39_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp38_, _tmp39_);
	_tmp40_ = proyecto_de_logica_U;
	_tmp41_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp40_, _tmp41_);
	_tmp42_ = proyecto_de_logica_V;
	_tmp43_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp42_, _tmp43_);
	_tmp44_ = proyecto_de_logica_W;
	_tmp45_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp44_, _tmp45_);
	_tmp46_ = proyecto_de_logica_X;
	_tmp47_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp46_, _tmp47_);
	_tmp48_ = proyecto_de_logica_Y;
	_tmp49_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp48_, _tmp49_);
	_tmp50_ = proyecto_de_logica_Z;
	_tmp51_ = state;
	proyecto_de_logica_letters_letter_sensitive (_tmp50_, _tmp51_);
	result = 1;
	return result;
}


gint proyecto_de_logica_solver_auto_solver (ProyectoDeLogicaSolver* self) {
	gint result = 0;
	ProyectoDeLogicaLetters* _tmp0_ = NULL;
	gint _tmp1_ = 0;
	ProyectoDeLogicaLetters* _tmp2_ = NULL;
	gint _tmp3_ = 0;
	ProyectoDeLogicaLetters* _tmp4_ = NULL;
	gint _tmp5_ = 0;
	ProyectoDeLogicaLetters* _tmp6_ = NULL;
	gint _tmp7_ = 0;
	ProyectoDeLogicaLetters* _tmp8_ = NULL;
	gint _tmp9_ = 0;
	ProyectoDeLogicaLetters* _tmp10_ = NULL;
	gint _tmp11_ = 0;
	ProyectoDeLogicaLetters* _tmp12_ = NULL;
	gint _tmp13_ = 0;
	ProyectoDeLogicaLetters* _tmp14_ = NULL;
	gint _tmp15_ = 0;
	ProyectoDeLogicaLetters* _tmp16_ = NULL;
	gint _tmp17_ = 0;
	ProyectoDeLogicaLetters* _tmp18_ = NULL;
	gint _tmp19_ = 0;
	ProyectoDeLogicaLetters* _tmp20_ = NULL;
	gint _tmp21_ = 0;
	ProyectoDeLogicaLetters* _tmp22_ = NULL;
	gint _tmp23_ = 0;
	ProyectoDeLogicaLetters* _tmp24_ = NULL;
	gint _tmp25_ = 0;
	ProyectoDeLogicaLetters* _tmp26_ = NULL;
	gint _tmp27_ = 0;
	ProyectoDeLogicaLetters* _tmp28_ = NULL;
	gint _tmp29_ = 0;
	ProyectoDeLogicaLetters* _tmp30_ = NULL;
	gint _tmp31_ = 0;
	ProyectoDeLogicaLetters* _tmp32_ = NULL;
	gint _tmp33_ = 0;
	ProyectoDeLogicaLetters* _tmp34_ = NULL;
	gint _tmp35_ = 0;
	ProyectoDeLogicaLetters* _tmp36_ = NULL;
	gint _tmp37_ = 0;
	ProyectoDeLogicaLetters* _tmp38_ = NULL;
	gint _tmp39_ = 0;
	ProyectoDeLogicaLetters* _tmp40_ = NULL;
	gint _tmp41_ = 0;
	ProyectoDeLogicaLetters* _tmp42_ = NULL;
	gint _tmp43_ = 0;
	ProyectoDeLogicaLetters* _tmp44_ = NULL;
	gint _tmp45_ = 0;
	ProyectoDeLogicaLetters* _tmp46_ = NULL;
	gint _tmp47_ = 0;
	ProyectoDeLogicaLetters* _tmp48_ = NULL;
	gint _tmp49_ = 0;
	ProyectoDeLogicaLetters* _tmp50_ = NULL;
	gint _tmp51_ = 0;
	g_return_val_if_fail (self != NULL, 0);
	_tmp0_ = proyecto_de_logica_A;
	_tmp1_ = proyecto_de_logica_letters_toggle (_tmp0_);
	if (_tmp1_ == 1) {
		result = 0;
		return result;
	}
	_tmp2_ = proyecto_de_logica_B;
	_tmp3_ = proyecto_de_logica_letters_toggle (_tmp2_);
	if (_tmp3_ == 1) {
		result = 0;
		return result;
	}
	_tmp4_ = proyecto_de_logica_C;
	_tmp5_ = proyecto_de_logica_letters_toggle (_tmp4_);
	if (_tmp5_ == 1) {
		result = 0;
		return result;
	}
	_tmp6_ = proyecto_de_logica_D;
	_tmp7_ = proyecto_de_logica_letters_toggle (_tmp6_);
	if (_tmp7_ == 1) {
		result = 0;
		return result;
	}
	_tmp8_ = proyecto_de_logica_E;
	_tmp9_ = proyecto_de_logica_letters_toggle (_tmp8_);
	if (_tmp9_ == 1) {
		result = 0;
		return result;
	}
	_tmp10_ = proyecto_de_logica_F;
	_tmp11_ = proyecto_de_logica_letters_toggle (_tmp10_);
	if (_tmp11_ == 1) {
		result = 0;
		return result;
	}
	_tmp12_ = proyecto_de_logica_G;
	_tmp13_ = proyecto_de_logica_letters_toggle (_tmp12_);
	if (_tmp13_ == 1) {
		result = 0;
		return result;
	}
	_tmp14_ = proyecto_de_logica_H;
	_tmp15_ = proyecto_de_logica_letters_toggle (_tmp14_);
	if (_tmp15_ == 1) {
		result = 0;
		return result;
	}
	_tmp16_ = proyecto_de_logica_I;
	_tmp17_ = proyecto_de_logica_letters_toggle (_tmp16_);
	if (_tmp17_ == 1) {
		result = 0;
		return result;
	}
	_tmp18_ = proyecto_de_logica_J;
	_tmp19_ = proyecto_de_logica_letters_toggle (_tmp18_);
	if (_tmp19_ == 1) {
		result = 0;
		return result;
	}
	_tmp20_ = proyecto_de_logica_K;
	_tmp21_ = proyecto_de_logica_letters_toggle (_tmp20_);
	if (_tmp21_ == 1) {
		result = 0;
		return result;
	}
	_tmp22_ = proyecto_de_logica_L;
	_tmp23_ = proyecto_de_logica_letters_toggle (_tmp22_);
	if (_tmp23_ == 1) {
		result = 0;
		return result;
	}
	_tmp24_ = proyecto_de_logica_M;
	_tmp25_ = proyecto_de_logica_letters_toggle (_tmp24_);
	if (_tmp25_ == 1) {
		result = 0;
		return result;
	}
	_tmp26_ = proyecto_de_logica_N;
	_tmp27_ = proyecto_de_logica_letters_toggle (_tmp26_);
	if (_tmp27_ == 1) {
		result = 0;
		return result;
	}
	_tmp28_ = proyecto_de_logica_O;
	_tmp29_ = proyecto_de_logica_letters_toggle (_tmp28_);
	if (_tmp29_ == 1) {
		result = 0;
		return result;
	}
	_tmp30_ = proyecto_de_logica_P;
	_tmp31_ = proyecto_de_logica_letters_toggle (_tmp30_);
	if (_tmp31_ == 1) {
		result = 0;
		return result;
	}
	_tmp32_ = proyecto_de_logica_Q;
	_tmp33_ = proyecto_de_logica_letters_toggle (_tmp32_);
	if (_tmp33_ == 1) {
		result = 0;
		return result;
	}
	_tmp34_ = proyecto_de_logica_R;
	_tmp35_ = proyecto_de_logica_letters_toggle (_tmp34_);
	if (_tmp35_ == 1) {
		result = 0;
		return result;
	}
	_tmp36_ = proyecto_de_logica_S;
	_tmp37_ = proyecto_de_logica_letters_toggle (_tmp36_);
	if (_tmp37_ == 1) {
		result = 0;
		return result;
	}
	_tmp38_ = proyecto_de_logica_T;
	_tmp39_ = proyecto_de_logica_letters_toggle (_tmp38_);
	if (_tmp39_ == 1) {
		result = 0;
		return result;
	}
	_tmp40_ = proyecto_de_logica_U;
	_tmp41_ = proyecto_de_logica_letters_toggle (_tmp40_);
	if (_tmp41_ == 1) {
		result = 0;
		return result;
	}
	_tmp42_ = proyecto_de_logica_V;
	_tmp43_ = proyecto_de_logica_letters_toggle (_tmp42_);
	if (_tmp43_ == 1) {
		result = 0;
		return result;
	}
	_tmp44_ = proyecto_de_logica_W;
	_tmp45_ = proyecto_de_logica_letters_toggle (_tmp44_);
	if (_tmp45_ == 1) {
		result = 0;
		return result;
	}
	_tmp46_ = proyecto_de_logica_X;
	_tmp47_ = proyecto_de_logica_letters_toggle (_tmp46_);
	if (_tmp47_ == 1) {
		result = 0;
		return result;
	}
	_tmp48_ = proyecto_de_logica_Y;
	_tmp49_ = proyecto_de_logica_letters_toggle (_tmp48_);
	if (_tmp49_ == 1) {
		result = 0;
		return result;
	}
	_tmp50_ = proyecto_de_logica_Z;
	_tmp51_ = proyecto_de_logica_letters_toggle (_tmp50_);
	if (_tmp51_ == 1) {
		result = 0;
		return result;
	}
	result = 1;
	return result;
}


static void __lambda9_ (ProyectoDeLogicaSolver* self) {
	ProyectoDeLogicaLetters* _tmp0_ = NULL;
	ProyectoDeLogicaLetters* _tmp1_ = NULL;
	ProyectoDeLogicaLetters* _tmp2_ = NULL;
	ProyectoDeLogicaLetters* _tmp3_ = NULL;
	ProyectoDeLogicaLetters* _tmp4_ = NULL;
	ProyectoDeLogicaLetters* _tmp5_ = NULL;
	ProyectoDeLogicaLetters* _tmp6_ = NULL;
	ProyectoDeLogicaLetters* _tmp7_ = NULL;
	ProyectoDeLogicaLetters* _tmp8_ = NULL;
	ProyectoDeLogicaLetters* _tmp9_ = NULL;
	ProyectoDeLogicaLetters* _tmp10_ = NULL;
	ProyectoDeLogicaLetters* _tmp11_ = NULL;
	ProyectoDeLogicaLetters* _tmp12_ = NULL;
	ProyectoDeLogicaLetters* _tmp13_ = NULL;
	ProyectoDeLogicaLetters* _tmp14_ = NULL;
	ProyectoDeLogicaLetters* _tmp15_ = NULL;
	ProyectoDeLogicaLetters* _tmp16_ = NULL;
	ProyectoDeLogicaLetters* _tmp17_ = NULL;
	ProyectoDeLogicaLetters* _tmp18_ = NULL;
	ProyectoDeLogicaLetters* _tmp19_ = NULL;
	ProyectoDeLogicaLetters* _tmp20_ = NULL;
	ProyectoDeLogicaLetters* _tmp21_ = NULL;
	ProyectoDeLogicaLetters* _tmp22_ = NULL;
	ProyectoDeLogicaLetters* _tmp23_ = NULL;
	ProyectoDeLogicaLetters* _tmp24_ = NULL;
	ProyectoDeLogicaLetters* _tmp25_ = NULL;
	GtkToolButton* _tmp26_ = NULL;
	GtkHeaderBar* _tmp27_ = NULL;
	GtkLabel* _tmp28_ = NULL;
	const gchar* _tmp29_ = NULL;
	const gchar* _tmp30_ = NULL;
	gchar* _tmp31_ = NULL;
	gchar* _tmp32_ = NULL;
	_tmp0_ = proyecto_de_logica_A;
	proyecto_de_logica_letters_update (_tmp0_);
	_tmp1_ = proyecto_de_logica_B;
	proyecto_de_logica_letters_update (_tmp1_);
	_tmp2_ = proyecto_de_logica_C;
	proyecto_de_logica_letters_update (_tmp2_);
	_tmp3_ = proyecto_de_logica_D;
	proyecto_de_logica_letters_update (_tmp3_);
	_tmp4_ = proyecto_de_logica_E;
	proyecto_de_logica_letters_update (_tmp4_);
	_tmp5_ = proyecto_de_logica_F;
	proyecto_de_logica_letters_update (_tmp5_);
	_tmp6_ = proyecto_de_logica_G;
	proyecto_de_logica_letters_update (_tmp6_);
	_tmp7_ = proyecto_de_logica_H;
	proyecto_de_logica_letters_update (_tmp7_);
	_tmp8_ = proyecto_de_logica_I;
	proyecto_de_logica_letters_update (_tmp8_);
	_tmp9_ = proyecto_de_logica_J;
	proyecto_de_logica_letters_update (_tmp9_);
	_tmp10_ = proyecto_de_logica_K;
	proyecto_de_logica_letters_update (_tmp10_);
	_tmp11_ = proyecto_de_logica_L;
	proyecto_de_logica_letters_update (_tmp11_);
	_tmp12_ = proyecto_de_logica_M;
	proyecto_de_logica_letters_update (_tmp12_);
	_tmp13_ = proyecto_de_logica_N;
	proyecto_de_logica_letters_update (_tmp13_);
	_tmp14_ = proyecto_de_logica_O;
	proyecto_de_logica_letters_update (_tmp14_);
	_tmp15_ = proyecto_de_logica_P;
	proyecto_de_logica_letters_update (_tmp15_);
	_tmp16_ = proyecto_de_logica_Q;
	proyecto_de_logica_letters_update (_tmp16_);
	_tmp17_ = proyecto_de_logica_R;
	proyecto_de_logica_letters_update (_tmp17_);
	_tmp18_ = proyecto_de_logica_S;
	proyecto_de_logica_letters_update (_tmp18_);
	_tmp19_ = proyecto_de_logica_T;
	proyecto_de_logica_letters_update (_tmp19_);
	_tmp20_ = proyecto_de_logica_U;
	proyecto_de_logica_letters_update (_tmp20_);
	_tmp21_ = proyecto_de_logica_V;
	proyecto_de_logica_letters_update (_tmp21_);
	_tmp22_ = proyecto_de_logica_W;
	proyecto_de_logica_letters_update (_tmp22_);
	_tmp23_ = proyecto_de_logica_X;
	proyecto_de_logica_letters_update (_tmp23_);
	_tmp24_ = proyecto_de_logica_Y;
	proyecto_de_logica_letters_update (_tmp24_);
	_tmp25_ = proyecto_de_logica_Z;
	proyecto_de_logica_letters_update (_tmp25_);
	_tmp26_ = self->priv->refresh_button;
	gtk_widget_set_sensitive ((GtkWidget*) _tmp26_, TRUE);
	_tmp27_ = proyecto_de_logica_headerbar;
	_tmp28_ = proyecto_de_logica_formula_label;
	_tmp29_ = gtk_label_get_label (_tmp28_);
	_tmp30_ = _tmp29_;
	_tmp31_ = proyecto_de_logica_solver_Calculate (self, _tmp30_);
	_tmp32_ = _tmp31_;
	gtk_header_bar_set_subtitle (_tmp27_, _tmp32_);
	_g_free0 (_tmp32_);
}


static void ___lambda9__proyecto_de_logica_solver_update (ProyectoDeLogicaSolver* _sender, gpointer self) {
	__lambda9_ ((ProyectoDeLogicaSolver*) self);
}


void proyecto_de_logica_solver_populate (ProyectoDeLogicaSolver* self, const gchar* formula_, const gchar* formula_override) {
	const gchar* _tmp0_ = NULL;
	gchar* _tmp1_ = NULL;
	const gchar* _tmp2_ = NULL;
	gchar* _tmp3_ = NULL;
	const gchar* _tmp4_ = NULL;
	GtkLabel* _tmp5_ = NULL;
	const gchar* _tmp6_ = NULL;
	GtkLabel* _tmp7_ = NULL;
	GtkLabel* _tmp8_ = NULL;
	GtkStyleContext* _tmp9_ = NULL;
	GtkLabel* _tmp10_ = NULL;
	GtkStyleContext* _tmp11_ = NULL;
	const gchar* _tmp12_ = NULL;
	ProyectoDeLogicaLetters* _tmp15_ = NULL;
	ProyectoDeLogicaLetters* _tmp16_ = NULL;
	ProyectoDeLogicaLetters* _tmp17_ = NULL;
	ProyectoDeLogicaLetters* _tmp18_ = NULL;
	ProyectoDeLogicaLetters* _tmp19_ = NULL;
	ProyectoDeLogicaLetters* _tmp20_ = NULL;
	ProyectoDeLogicaLetters* _tmp21_ = NULL;
	ProyectoDeLogicaLetters* _tmp22_ = NULL;
	ProyectoDeLogicaLetters* _tmp23_ = NULL;
	ProyectoDeLogicaLetters* _tmp24_ = NULL;
	ProyectoDeLogicaLetters* _tmp25_ = NULL;
	ProyectoDeLogicaLetters* _tmp26_ = NULL;
	ProyectoDeLogicaLetters* _tmp27_ = NULL;
	ProyectoDeLogicaLetters* _tmp28_ = NULL;
	ProyectoDeLogicaLetters* _tmp29_ = NULL;
	ProyectoDeLogicaLetters* _tmp30_ = NULL;
	ProyectoDeLogicaLetters* _tmp31_ = NULL;
	ProyectoDeLogicaLetters* _tmp32_ = NULL;
	ProyectoDeLogicaLetters* _tmp33_ = NULL;
	ProyectoDeLogicaLetters* _tmp34_ = NULL;
	ProyectoDeLogicaLetters* _tmp35_ = NULL;
	ProyectoDeLogicaLetters* _tmp36_ = NULL;
	ProyectoDeLogicaLetters* _tmp37_ = NULL;
	ProyectoDeLogicaLetters* _tmp38_ = NULL;
	ProyectoDeLogicaLetters* _tmp39_ = NULL;
	ProyectoDeLogicaLetters* _tmp40_ = NULL;
	g_return_if_fail (self != NULL);
	g_return_if_fail (formula_ != NULL);
	g_return_if_fail (formula_override != NULL);
	_tmp0_ = formula_;
	_tmp1_ = g_strdup (_tmp0_);
	_g_free0 (proyecto_de_logica_originalfi);
	proyecto_de_logica_originalfi = _tmp1_;
	_tmp2_ = formula_override;
	_tmp3_ = g_strdup (_tmp2_);
	_g_free0 (proyecto_de_logica_originaloverride);
	proyecto_de_logica_originaloverride = _tmp3_;
	_tmp4_ = formula_;
	_tmp5_ = (GtkLabel*) gtk_label_new (_tmp4_);
	g_object_ref_sink (_tmp5_);
	_g_object_unref0 (proyecto_de_logica_formula_label);
	proyecto_de_logica_formula_label = _tmp5_;
	_tmp6_ = formula_override;
	_tmp7_ = (GtkLabel*) gtk_label_new (_tmp6_);
	g_object_ref_sink (_tmp7_);
	_g_object_unref0 (proyecto_de_logica_override_label);
	proyecto_de_logica_override_label = _tmp7_;
	_tmp8_ = proyecto_de_logica_formula_label;
	_tmp9_ = gtk_widget_get_style_context ((GtkWidget*) _tmp8_);
	gtk_style_context_add_class (_tmp9_, "h2");
	_tmp10_ = proyecto_de_logica_override_label;
	_tmp11_ = gtk_widget_get_style_context ((GtkWidget*) _tmp10_);
	gtk_style_context_add_class (_tmp11_, "h2");
	_tmp12_ = formula_override;
	if (g_strcmp0 (_tmp12_, "") == 0) {
		GtkLabel* _tmp13_ = NULL;
		_tmp13_ = proyecto_de_logica_formula_label;
		gtk_container_add ((GtkContainer*) self, (GtkWidget*) _tmp13_);
	} else {
		GtkLabel* _tmp14_ = NULL;
		_tmp14_ = proyecto_de_logica_override_label;
		gtk_container_add ((GtkContainer*) self, (GtkWidget*) _tmp14_);
	}
	gtk_box_set_spacing ((GtkBox*) self, 4);
	_tmp15_ = proyecto_de_logica_letters_new ("A");
	g_object_ref_sink (_tmp15_);
	_g_object_unref0 (proyecto_de_logica_A);
	proyecto_de_logica_A = _tmp15_;
	_tmp16_ = proyecto_de_logica_letters_new ("B");
	g_object_ref_sink (_tmp16_);
	_g_object_unref0 (proyecto_de_logica_B);
	proyecto_de_logica_B = _tmp16_;
	_tmp17_ = proyecto_de_logica_letters_new ("C");
	g_object_ref_sink (_tmp17_);
	_g_object_unref0 (proyecto_de_logica_C);
	proyecto_de_logica_C = _tmp17_;
	_tmp18_ = proyecto_de_logica_letters_new ("D");
	g_object_ref_sink (_tmp18_);
	_g_object_unref0 (proyecto_de_logica_D);
	proyecto_de_logica_D = _tmp18_;
	_tmp19_ = proyecto_de_logica_letters_new ("E");
	g_object_ref_sink (_tmp19_);
	_g_object_unref0 (proyecto_de_logica_E);
	proyecto_de_logica_E = _tmp19_;
	_tmp20_ = proyecto_de_logica_letters_new ("F");
	g_object_ref_sink (_tmp20_);
	_g_object_unref0 (proyecto_de_logica_F);
	proyecto_de_logica_F = _tmp20_;
	_tmp21_ = proyecto_de_logica_letters_new ("G");
	g_object_ref_sink (_tmp21_);
	_g_object_unref0 (proyecto_de_logica_G);
	proyecto_de_logica_G = _tmp21_;
	_tmp22_ = proyecto_de_logica_letters_new ("H");
	g_object_ref_sink (_tmp22_);
	_g_object_unref0 (proyecto_de_logica_H);
	proyecto_de_logica_H = _tmp22_;
	_tmp23_ = proyecto_de_logica_letters_new ("I");
	g_object_ref_sink (_tmp23_);
	_g_object_unref0 (proyecto_de_logica_I);
	proyecto_de_logica_I = _tmp23_;
	_tmp24_ = proyecto_de_logica_letters_new ("J");
	g_object_ref_sink (_tmp24_);
	_g_object_unref0 (proyecto_de_logica_J);
	proyecto_de_logica_J = _tmp24_;
	_tmp25_ = proyecto_de_logica_letters_new ("K");
	g_object_ref_sink (_tmp25_);
	_g_object_unref0 (proyecto_de_logica_K);
	proyecto_de_logica_K = _tmp25_;
	_tmp26_ = proyecto_de_logica_letters_new ("L");
	g_object_ref_sink (_tmp26_);
	_g_object_unref0 (proyecto_de_logica_L);
	proyecto_de_logica_L = _tmp26_;
	_tmp27_ = proyecto_de_logica_letters_new ("M");
	g_object_ref_sink (_tmp27_);
	_g_object_unref0 (proyecto_de_logica_M);
	proyecto_de_logica_M = _tmp27_;
	_tmp28_ = proyecto_de_logica_letters_new ("N");
	g_object_ref_sink (_tmp28_);
	_g_object_unref0 (proyecto_de_logica_N);
	proyecto_de_logica_N = _tmp28_;
	_tmp29_ = proyecto_de_logica_letters_new ("O");
	g_object_ref_sink (_tmp29_);
	_g_object_unref0 (proyecto_de_logica_O);
	proyecto_de_logica_O = _tmp29_;
	_tmp30_ = proyecto_de_logica_letters_new ("P");
	g_object_ref_sink (_tmp30_);
	_g_object_unref0 (proyecto_de_logica_P);
	proyecto_de_logica_P = _tmp30_;
	_tmp31_ = proyecto_de_logica_letters_new ("Q");
	g_object_ref_sink (_tmp31_);
	_g_object_unref0 (proyecto_de_logica_Q);
	proyecto_de_logica_Q = _tmp31_;
	_tmp32_ = proyecto_de_logica_letters_new ("R");
	g_object_ref_sink (_tmp32_);
	_g_object_unref0 (proyecto_de_logica_R);
	proyecto_de_logica_R = _tmp32_;
	_tmp33_ = proyecto_de_logica_letters_new ("S");
	g_object_ref_sink (_tmp33_);
	_g_object_unref0 (proyecto_de_logica_S);
	proyecto_de_logica_S = _tmp33_;
	_tmp34_ = proyecto_de_logica_letters_new ("T");
	g_object_ref_sink (_tmp34_);
	_g_object_unref0 (proyecto_de_logica_T);
	proyecto_de_logica_T = _tmp34_;
	_tmp35_ = proyecto_de_logica_letters_new ("U");
	g_object_ref_sink (_tmp35_);
	_g_object_unref0 (proyecto_de_logica_U);
	proyecto_de_logica_U = _tmp35_;
	_tmp36_ = proyecto_de_logica_letters_new ("V");
	g_object_ref_sink (_tmp36_);
	_g_object_unref0 (proyecto_de_logica_V);
	proyecto_de_logica_V = _tmp36_;
	_tmp37_ = proyecto_de_logica_letters_new ("W");
	g_object_ref_sink (_tmp37_);
	_g_object_unref0 (proyecto_de_logica_W);
	proyecto_de_logica_W = _tmp37_;
	_tmp38_ = proyecto_de_logica_letters_new ("X");
	g_object_ref_sink (_tmp38_);
	_g_object_unref0 (proyecto_de_logica_X);
	proyecto_de_logica_X = _tmp38_;
	_tmp39_ = proyecto_de_logica_letters_new ("Y");
	g_object_ref_sink (_tmp39_);
	_g_object_unref0 (proyecto_de_logica_Y);
	proyecto_de_logica_Y = _tmp39_;
	_tmp40_ = proyecto_de_logica_letters_new ("Z");
	g_object_ref_sink (_tmp40_);
	_g_object_unref0 (proyecto_de_logica_Z);
	proyecto_de_logica_Z = _tmp40_;
	g_signal_connect_object (self, "update", (GCallback) ___lambda9__proyecto_de_logica_solver_update, self, 0);
}


static void proyecto_de_logica_solver_class_init (ProyectoDeLogicaSolverClass * klass) {
	proyecto_de_logica_solver_parent_class = g_type_class_peek_parent (klass);
	g_type_class_add_private (klass, sizeof (ProyectoDeLogicaSolverPrivate));
	G_OBJECT_CLASS (klass)->finalize = proyecto_de_logica_solver_finalize;
	g_signal_new ("update", PROYECTO_DE_LOGICA_TYPE_SOLVER, G_SIGNAL_RUN_LAST, 0, NULL, NULL, g_cclosure_marshal_VOID__VOID, G_TYPE_NONE, 0);
}


static void proyecto_de_logica_solver_instance_init (ProyectoDeLogicaSolver * self) {
	self->priv = PROYECTO_DE_LOGICA_SOLVER_GET_PRIVATE (self);
}


static void proyecto_de_logica_solver_finalize (GObject* obj) {
	ProyectoDeLogicaSolver * self;
	self = G_TYPE_CHECK_INSTANCE_CAST (obj, PROYECTO_DE_LOGICA_TYPE_SOLVER, ProyectoDeLogicaSolver);
	_g_object_unref0 (self->priv->refresh_button);
	G_OBJECT_CLASS (proyecto_de_logica_solver_parent_class)->finalize (obj);
}


GType proyecto_de_logica_solver_get_type (void) {
	static volatile gsize proyecto_de_logica_solver_type_id__volatile = 0;
	if (g_once_init_enter (&proyecto_de_logica_solver_type_id__volatile)) {
		static const GTypeInfo g_define_type_info = { sizeof (ProyectoDeLogicaSolverClass), (GBaseInitFunc) NULL, (GBaseFinalizeFunc) NULL, (GClassInitFunc) proyecto_de_logica_solver_class_init, (GClassFinalizeFunc) NULL, NULL, sizeof (ProyectoDeLogicaSolver), 0, (GInstanceInitFunc) proyecto_de_logica_solver_instance_init, NULL };
		GType proyecto_de_logica_solver_type_id;
		proyecto_de_logica_solver_type_id = g_type_register_static (gtk_vbox_get_type (), "ProyectoDeLogicaSolver", &g_define_type_info, 0);
		g_once_init_leave (&proyecto_de_logica_solver_type_id__volatile, proyecto_de_logica_solver_type_id);
	}
	return proyecto_de_logica_solver_type_id__volatile;
}



