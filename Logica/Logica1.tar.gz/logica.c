#include <glib.h>
#include <glib-object.h>
#include <gio/gio.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>
#include <gdk/gdk.h>


#define PROYECTO_DE_LOGICA_TYPE_SOLVER (proyecto_de_logica_solver_get_type ())
#define PROYECTO_DE_LOGICA_SOLVER(obj) (G_TYPE_CHECK_INSTANCE_CAST ((obj), PROYECTO_DE_LOGICA_TYPE_SOLVER, ProyectoDeLogicaSolver))
#define PROYECTO_DE_LOGICA_SOLVER_CLASS(klass) (G_TYPE_CHECK_CLASS_CAST ((klass), PROYECTO_DE_LOGICA_TYPE_SOLVER, ProyectoDeLogicaSolverClass))
#define PROYECTO_DE_LOGICA_IS_SOLVER(obj) (G_TYPE_CHECK_INSTANCE_TYPE ((obj), PROYECTO_DE_LOGICA_TYPE_SOLVER))
#define PROYECTO_DE_LOGICA_IS_SOLVER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), PROYECTO_DE_LOGICA_TYPE_SOLVER))
#define PROYECTO_DE_LOGICA_SOLVER_GET_CLASS(obj) (G_TYPE_INSTANCE_GET_CLASS ((obj), PROYECTO_DE_LOGICA_TYPE_SOLVER, ProyectoDeLogicaSolverClass))

typedef struct _ProyectoDeLogicaSolver ProyectoDeLogicaSolver;
typedef struct _ProyectoDeLogicaSolverClass ProyectoDeLogicaSolverClass;

#define PROYECTO_DE_LOGICA_TYPE_LETTERS (proyecto_de_logica_letters_get_type ())
#define PROYECTO_DE_LOGICA_LETTERS(obj) (G_TYPE_CHECK_INSTANCE_CAST ((obj), PROYECTO_DE_LOGICA_TYPE_LETTERS, ProyectoDeLogicaLetters))
#define PROYECTO_DE_LOGICA_LETTERS_CLASS(klass) (G_TYPE_CHECK_CLASS_CAST ((klass), PROYECTO_DE_LOGICA_TYPE_LETTERS, ProyectoDeLogicaLettersClass))
#define PROYECTO_DE_LOGICA_IS_LETTERS(obj) (G_TYPE_CHECK_INSTANCE_TYPE ((obj), PROYECTO_DE_LOGICA_TYPE_LETTERS))
#define PROYECTO_DE_LOGICA_IS_LETTERS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), PROYECTO_DE_LOGICA_TYPE_LETTERS))
#define PROYECTO_DE_LOGICA_LETTERS_GET_CLASS(obj) (G_TYPE_INSTANCE_GET_CLASS ((obj), PROYECTO_DE_LOGICA_TYPE_LETTERS, ProyectoDeLogicaLettersClass))

typedef struct _ProyectoDeLogicaLetters ProyectoDeLogicaLetters;
typedef struct _ProyectoDeLogicaLettersClass ProyectoDeLogicaLettersClass;

#define PROYECTO_DE_LOGICA_TYPE_LOGIC (proyecto_de_logica_logic_get_type ())
#define PROYECTO_DE_LOGICA_LOGIC(obj) (G_TYPE_CHECK_INSTANCE_CAST ((obj), PROYECTO_DE_LOGICA_TYPE_LOGIC, ProyectoDeLogicaLogic))
#define PROYECTO_DE_LOGICA_LOGIC_CLASS(klass) (G_TYPE_CHECK_CLASS_CAST ((klass), PROYECTO_DE_LOGICA_TYPE_LOGIC, ProyectoDeLogicaLogicClass))
#define PROYECTO_DE_LOGICA_IS_LOGIC(obj) (G_TYPE_CHECK_INSTANCE_TYPE ((obj), PROYECTO_DE_LOGICA_TYPE_LOGIC))
#define PROYECTO_DE_LOGICA_IS_LOGIC_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), PROYECTO_DE_LOGICA_TYPE_LOGIC))
#define PROYECTO_DE_LOGICA_LOGIC_GET_CLASS(obj) (G_TYPE_INSTANCE_GET_CLASS ((obj), PROYECTO_DE_LOGICA_TYPE_LOGIC, ProyectoDeLogicaLogicClass))

typedef struct _ProyectoDeLogicaLogic ProyectoDeLogicaLogic;
typedef struct _ProyectoDeLogicaLogicClass ProyectoDeLogicaLogicClass;
typedef struct _ProyectoDeLogicaLogicPrivate ProyectoDeLogicaLogicPrivate;
#define _g_free0(var) (var = (g_free (var), NULL))
#define _g_regex_unref0(var) ((var == NULL) ? NULL : (var = (g_regex_unref (var), NULL)))
#define _g_error_free0(var) ((var == NULL) ? NULL : (var = (g_error_free (var), NULL)))
#define _g_string_free0(var) ((var == NULL) ? NULL : (var = (g_string_free (var, TRUE), NULL)))
#define _g_object_unref0(var) ((var == NULL) ? NULL : (var = (g_object_unref (var), NULL)))
typedef struct _Block1Data Block1Data;

struct _ProyectoDeLogicaLogic {
	GtkWindow parent_instance;
	ProyectoDeLogicaLogicPrivate * priv;
	gboolean formula_focus;
	gint formula_valid;
	gboolean simplify_type;
	gboolean dont_exit;
};

struct _ProyectoDeLogicaLogicClass {
	GtkWindowClass parent_class;
};

struct _Block1Data {
	int _ref_count_;
	ProyectoDeLogicaLogic* self;
	GtkCssProvider* error_css;
	GtkLabel* entails;
	GtkButton* Calculate;
};


extern GSettings* proyecto_de_logica_settings;
GSettings* proyecto_de_logica_settings = NULL;
extern GtkSwitch* proyecto_de_logica_formula_toggle;
GtkSwitch* proyecto_de_logica_formula_toggle = NULL;
extern GtkEntry* proyecto_de_logica_formula;
GtkEntry* proyecto_de_logica_formula = NULL;
extern GtkEntry* proyecto_de_logica_formula2;
GtkEntry* proyecto_de_logica_formula2 = NULL;
extern gchar* proyecto_de_logica_originalfi;
gchar* proyecto_de_logica_originalfi = NULL;
extern gchar* proyecto_de_logica_originaloverride;
gchar* proyecto_de_logica_originaloverride = NULL;
extern GtkLabel* proyecto_de_logica_formula_label;
GtkLabel* proyecto_de_logica_formula_label = NULL;
extern GtkLabel* proyecto_de_logica_override_label;
GtkLabel* proyecto_de_logica_override_label = NULL;
extern GtkBox* proyecto_de_logica_box;
GtkBox* proyecto_de_logica_box = NULL;
extern GtkBox* proyecto_de_logica_mainbox;
GtkBox* proyecto_de_logica_mainbox = NULL;
extern GtkWindow* proyecto_de_logica_app;
GtkWindow* proyecto_de_logica_app = NULL;
extern ProyectoDeLogicaSolver* proyecto_de_logica_solver_box;
ProyectoDeLogicaSolver* proyecto_de_logica_solver_box = NULL;
extern GtkHeaderBar* proyecto_de_logica_headerbar;
GtkHeaderBar* proyecto_de_logica_headerbar = NULL;
extern GtkGrid* proyecto_de_logica_grid;
GtkGrid* proyecto_de_logica_grid = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_A;
ProyectoDeLogicaLetters* proyecto_de_logica_A = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_B;
ProyectoDeLogicaLetters* proyecto_de_logica_B = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_C;
ProyectoDeLogicaLetters* proyecto_de_logica_C = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_D;
ProyectoDeLogicaLetters* proyecto_de_logica_D = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_E;
ProyectoDeLogicaLetters* proyecto_de_logica_E = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_F;
ProyectoDeLogicaLetters* proyecto_de_logica_F = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_G;
ProyectoDeLogicaLetters* proyecto_de_logica_G = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_H;
ProyectoDeLogicaLetters* proyecto_de_logica_H = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_I;
ProyectoDeLogicaLetters* proyecto_de_logica_I = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_J;
ProyectoDeLogicaLetters* proyecto_de_logica_J = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_K;
ProyectoDeLogicaLetters* proyecto_de_logica_K = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_L;
ProyectoDeLogicaLetters* proyecto_de_logica_L = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_M;
ProyectoDeLogicaLetters* proyecto_de_logica_M = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_N;
ProyectoDeLogicaLetters* proyecto_de_logica_N = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_O;
ProyectoDeLogicaLetters* proyecto_de_logica_O = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_P;
ProyectoDeLogicaLetters* proyecto_de_logica_P = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_Q;
ProyectoDeLogicaLetters* proyecto_de_logica_Q = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_R;
ProyectoDeLogicaLetters* proyecto_de_logica_R = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_S;
ProyectoDeLogicaLetters* proyecto_de_logica_S = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_T;
ProyectoDeLogicaLetters* proyecto_de_logica_T = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_U;
ProyectoDeLogicaLetters* proyecto_de_logica_U = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_V;
ProyectoDeLogicaLetters* proyecto_de_logica_V = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_W;
ProyectoDeLogicaLetters* proyecto_de_logica_W = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_X;
ProyectoDeLogicaLetters* proyecto_de_logica_X = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_Y;
ProyectoDeLogicaLetters* proyecto_de_logica_Y = NULL;
extern ProyectoDeLogicaLetters* proyecto_de_logica_Z;
ProyectoDeLogicaLetters* proyecto_de_logica_Z = NULL;
static gpointer proyecto_de_logica_logic_parent_class = NULL;

GType proyecto_de_logica_solver_get_type (void) G_GNUC_CONST;
GType proyecto_de_logica_letters_get_type (void) G_GNUC_CONST;
GType proyecto_de_logica_logic_get_type (void) G_GNUC_CONST;
enum  {
	PROYECTO_DE_LOGICA_LOGIC_DUMMY_PROPERTY
};
static gboolean proyecto_de_logica_logic_real_delete_event (GtkWidget* base, GdkEventAny* event);
gchar* proyecto_de_logica_logic_final_check (ProyectoDeLogicaLogic* self, const gchar* fi);
gchar* proyecto_de_logica_logic_check_formula (ProyectoDeLogicaLogic* self, const gchar* fi);
gchar* proyecto_de_logica_logic_remove_extrapars (ProyectoDeLogicaLogic* self, const gchar* fi);
gchar* proyecto_de_logica_logic_simplify_formula (ProyectoDeLogicaLogic* self, const gchar* fi);
gchar* proyecto_de_logica_logic_remove_spaces (ProyectoDeLogicaLogic* self, const gchar* fi);
gchar* proyecto_de_logica_logic_add_spaces (ProyectoDeLogicaLogic* self, const gchar* fi, gint a);
gboolean proyecto_de_logica_logic_count_pars (ProyectoDeLogicaLogic* self, const gchar* fi);
gboolean proyecto_de_logica_logic_check_pars (ProyectoDeLogicaLogic* self, const gchar* fi);
static gchar* proyecto_de_logica_logic_easy_build (ProyectoDeLogicaLogic* self, const gchar* fi);
static void proyecto_de_logica_logic_button_clicked (ProyectoDeLogicaLogic* self, const gchar* label);
GtkButton* proyecto_de_logica_logic_LogicButton (ProyectoDeLogicaLogic* self, const gchar* text);
ProyectoDeLogicaLogic* proyecto_de_logica_logic_new (void);
ProyectoDeLogicaLogic* proyecto_de_logica_logic_construct (GType object_type);
static Block1Data* block1_data_ref (Block1Data* _data1_);
static void block1_data_unref (void * _userdata_);
static void _gtk_main_quit_gtk_widget_destroy (GtkWidget* _sender, gpointer self);
static gboolean __lambda10_ (Block1Data* _data1_, gboolean state);
static gboolean ___lambda10__gtk_switch_state_set (GtkSwitch* _sender, gboolean state, gpointer self);
static gboolean __lambda11_ (ProyectoDeLogicaLogic* self);
static gboolean ___lambda11__gtk_widget_focus_in_event (GtkWidget* _sender, GdkEventFocus* event, gpointer self);
static void __lambda12_ (ProyectoDeLogicaLogic* self);
static void ___lambda12__gtk_button_clicked (GtkButton* _sender, gpointer self);
static void __lambda13_ (ProyectoDeLogicaLogic* self);
static void ___lambda13__gtk_button_clicked (GtkButton* _sender, gpointer self);
static void __lambda14_ (ProyectoDeLogicaLogic* self);
static void ___lambda14__gtk_button_clicked (GtkButton* _sender, gpointer self);
static void __lambda15_ (ProyectoDeLogicaLogic* self);
static void ___lambda15__gtk_button_clicked (GtkButton* _sender, gpointer self);
static void __lambda16_ (ProyectoDeLogicaLogic* self);
static void ___lambda16__gtk_button_clicked (GtkButton* _sender, gpointer self);
static void __lambda17_ (ProyectoDeLogicaLogic* self);
static void ___lambda17__gtk_button_clicked (GtkButton* _sender, gpointer self);
static void __lambda18_ (ProyectoDeLogicaLogic* self);
static void ___lambda18__gtk_button_clicked (GtkButton* _sender, gpointer self);
static void __lambda19_ (ProyectoDeLogicaLogic* self);
static void ___lambda19__gtk_button_clicked (GtkButton* _sender, gpointer self);
static void __lambda20_ (Block1Data* _data1_);
static void ___lambda20__gtk_editable_changed (GtkEditable* _sender, gpointer self);
static void __lambda21_ (Block1Data* _data1_);
static void ___lambda21__gtk_editable_changed (GtkEditable* _sender, gpointer self);
static void __lambda22_ (Block1Data* _data1_);
static void ___lambda22__proyecto_de_logica_logic_check (ProyectoDeLogicaLogic* _sender, gpointer self);
static void __lambda23_ (Block1Data* _data1_);
static void ___lambda23__gtk_entry_activate (GtkEntry* _sender, gpointer self);
static void __lambda24_ (ProyectoDeLogicaLogic* self);
static void ___lambda24__gtk_entry_activate (GtkEntry* _sender, gpointer self);
static void __lambda25_ (Block1Data* _data1_);
static void ___lambda25__proyecto_de_logica_logic_good_formula (ProyectoDeLogicaLogic* _sender, gpointer self);
static void __lambda26_ (Block1Data* _data1_);
ProyectoDeLogicaSolver* proyecto_de_logica_solver_new (void);
ProyectoDeLogicaSolver* proyecto_de_logica_solver_construct (GType object_type);
void proyecto_de_logica_solver_populate (ProyectoDeLogicaSolver* self, const gchar* formula_, const gchar* formula_override);
static void ___lambda26__gtk_button_clicked (GtkButton* _sender, gpointer self);
static void __lambda27_ (ProyectoDeLogicaLogic* self);
static void ___lambda27__gtk_button_clicked (GtkButton* _sender, gpointer self);
static void proyecto_de_logica_logic_finalize (GObject* obj);
gint proyecto_de_logica_main (gchar** args, int args_length1);

const gunichar PROYECTO_DE_LOGICA_letter[26] = {(gunichar) 'A', (gunichar) 'B', (gunichar) 'C', (gunichar) 'D', (gunichar) 'E', (gunichar) 'F', (gunichar) 'G', (gunichar) 'H', (gunichar) 'I', (gunichar) 'J', (gunichar) 'K', (gunichar) 'L', (gunichar) 'M', (gunichar) 'N', (gunichar) 'O', (gunichar) 'P', (gunichar) 'Q', (gunichar) 'R', (gunichar) 'S', (gunichar) 'T', (gunichar) 'U', (gunichar) 'V', (gunichar) 'W', (gunichar) 'X', (gunichar) 'Y', (gunichar) 'Z'};

static const gchar* string_to_string (const gchar* self) {
	const gchar* result = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	result = self;
	return result;
}


static gboolean proyecto_de_logica_logic_real_delete_event (GtkWidget* base, GdkEventAny* event) {
	ProyectoDeLogicaLogic * self;
	gboolean result = FALSE;
	GSettings* _tmp0_ = NULL;
	GtkEntry* _tmp1_ = NULL;
	const gchar* _tmp2_ = NULL;
	const gchar* _tmp3_ = NULL;
	const gchar* _tmp4_ = NULL;
	GSettings* _tmp5_ = NULL;
	GtkEntry* _tmp6_ = NULL;
	const gchar* _tmp7_ = NULL;
	const gchar* _tmp8_ = NULL;
	const gchar* _tmp9_ = NULL;
	gboolean _tmp10_ = FALSE;
	self = (ProyectoDeLogicaLogic*) base;
	g_return_val_if_fail (event != NULL, FALSE);
	_tmp0_ = proyecto_de_logica_settings;
	_tmp1_ = proyecto_de_logica_formula;
	_tmp2_ = gtk_entry_get_text (_tmp1_);
	_tmp3_ = _tmp2_;
	_tmp4_ = string_to_string (_tmp3_);
	g_settings_set_string (_tmp0_, "formula0", _tmp4_);
	_tmp5_ = proyecto_de_logica_settings;
	_tmp6_ = proyecto_de_logica_formula2;
	_tmp7_ = gtk_entry_get_text (_tmp6_);
	_tmp8_ = _tmp7_;
	_tmp9_ = string_to_string (_tmp8_);
	g_settings_set_string (_tmp5_, "formula1", _tmp9_);
	gtk_widget_destroy ((GtkWidget*) self);
	_tmp10_ = self->dont_exit;
	result = _tmp10_;
	return result;
}


static gboolean string_contains (const gchar* self, const gchar* needle) {
	gboolean result = FALSE;
	const gchar* _tmp0_ = NULL;
	gchar* _tmp1_ = NULL;
	g_return_val_if_fail (self != NULL, FALSE);
	g_return_val_if_fail (needle != NULL, FALSE);
	_tmp0_ = needle;
	_tmp1_ = strstr ((gchar*) self, (gchar*) _tmp0_);
	result = _tmp1_ != NULL;
	return result;
}


static gchar* string_replace (const gchar* self, const gchar* old, const gchar* replacement) {
	gchar* result = NULL;
	GError * _inner_error_ = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	g_return_val_if_fail (old != NULL, NULL);
	g_return_val_if_fail (replacement != NULL, NULL);
	{
		GRegex* regex = NULL;
		const gchar* _tmp0_ = NULL;
		gchar* _tmp1_ = NULL;
		gchar* _tmp2_ = NULL;
		GRegex* _tmp3_ = NULL;
		GRegex* _tmp4_ = NULL;
		gchar* _tmp5_ = NULL;
		GRegex* _tmp6_ = NULL;
		const gchar* _tmp7_ = NULL;
		gchar* _tmp8_ = NULL;
		gchar* _tmp9_ = NULL;
		_tmp0_ = old;
		_tmp1_ = g_regex_escape_string (_tmp0_, -1);
		_tmp2_ = _tmp1_;
		_tmp3_ = g_regex_new (_tmp2_, 0, 0, &_inner_error_);
		_tmp4_ = _tmp3_;
		_g_free0 (_tmp2_);
		regex = _tmp4_;
		if (G_UNLIKELY (_inner_error_ != NULL)) {
			if (_inner_error_->domain == G_REGEX_ERROR) {
				goto __catch0_g_regex_error;
			}
			g_critical ("file %s: line %d: unexpected error: %s (%s, %d)", __FILE__, __LINE__, _inner_error_->message, g_quark_to_string (_inner_error_->domain), _inner_error_->code);
			g_clear_error (&_inner_error_);
			return NULL;
		}
		_tmp6_ = regex;
		_tmp7_ = replacement;
		_tmp8_ = g_regex_replace_literal (_tmp6_, self, (gssize) (-1), 0, _tmp7_, 0, &_inner_error_);
		_tmp5_ = _tmp8_;
		if (G_UNLIKELY (_inner_error_ != NULL)) {
			_g_regex_unref0 (regex);
			if (_inner_error_->domain == G_REGEX_ERROR) {
				goto __catch0_g_regex_error;
			}
			_g_regex_unref0 (regex);
			g_critical ("file %s: line %d: unexpected error: %s (%s, %d)", __FILE__, __LINE__, _inner_error_->message, g_quark_to_string (_inner_error_->domain), _inner_error_->code);
			g_clear_error (&_inner_error_);
			return NULL;
		}
		_tmp9_ = _tmp5_;
		_tmp5_ = NULL;
		result = _tmp9_;
		_g_free0 (_tmp5_);
		_g_regex_unref0 (regex);
		return result;
	}
	goto __finally0;
	__catch0_g_regex_error:
	{
		GError* e = NULL;
		e = _inner_error_;
		_inner_error_ = NULL;
		g_assert_not_reached ();
		_g_error_free0 (e);
	}
	__finally0:
	if (G_UNLIKELY (_inner_error_ != NULL)) {
		g_critical ("file %s: line %d: uncaught error: %s (%s, %d)", __FILE__, __LINE__, _inner_error_->message, g_quark_to_string (_inner_error_->domain), _inner_error_->code);
		g_clear_error (&_inner_error_);
		return NULL;
	}
}


gchar* proyecto_de_logica_logic_final_check (ProyectoDeLogicaLogic* self, const gchar* fi) {
	gchar* result = NULL;
	gchar* test = NULL;
	const gchar* _tmp0_ = NULL;
	gboolean _tmp1_ = FALSE;
	const gchar* _tmp6_ = NULL;
	const gchar* _tmp7_ = NULL;
	const gchar* _tmp8_ = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	g_return_val_if_fail (fi != NULL, NULL);
	_tmp0_ = fi;
	_tmp1_ = string_contains (_tmp0_, "X,X");
	if (_tmp1_) {
		const gchar* _tmp2_ = NULL;
		gchar* _tmp3_ = NULL;
		_tmp2_ = fi;
		_tmp3_ = string_replace (_tmp2_, "X,X", "X");
		_g_free0 (test);
		test = _tmp3_;
	} else {
		const gchar* _tmp4_ = NULL;
		gchar* _tmp5_ = NULL;
		_tmp4_ = fi;
		_tmp5_ = g_strdup (_tmp4_);
		_g_free0 (test);
		test = _tmp5_;
	}
	_tmp6_ = test;
	if (g_strcmp0 (_tmp6_, "X") == 0) {
		g_signal_emit_by_name (self, "good-formula");
		result = test;
		return result;
	}
	_tmp7_ = fi;
	_tmp8_ = test;
	if (g_strcmp0 (_tmp7_, _tmp8_) == 0) {
		result = test;
		return result;
	} else {
		const gchar* _tmp9_ = NULL;
		gchar* _tmp10_ = NULL;
		_tmp9_ = test;
		_tmp10_ = proyecto_de_logica_logic_final_check (self, _tmp9_);
		result = _tmp10_;
		_g_free0 (test);
		return result;
	}
	_g_free0 (test);
}


gchar* proyecto_de_logica_logic_check_formula (ProyectoDeLogicaLogic* self, const gchar* fi) {
	gchar* result = NULL;
	gboolean _tmp0_ = FALSE;
	gboolean _tmp1_ = FALSE;
	gboolean _tmp2_ = FALSE;
	gboolean _tmp3_ = FALSE;
	const gchar* _tmp4_ = NULL;
	gboolean _tmp9_ = FALSE;
	const gchar* _tmp10_ = NULL;
	gboolean _tmp11_ = FALSE;
	gchar* formula_new = NULL;
	const gchar* _tmp14_ = NULL;
	gchar* _tmp15_ = NULL;
	gchar* _tmp16_ = NULL;
	gchar* _tmp17_ = NULL;
	gchar* _tmp18_ = NULL;
	const gchar* _tmp19_ = NULL;
	const gchar* _tmp20_ = NULL;
	const gchar* _tmp24_ = NULL;
	gchar* _tmp25_ = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	g_return_val_if_fail (fi != NULL, NULL);
	_tmp4_ = fi;
	if (g_strcmp0 (_tmp4_, "T") == 0) {
		_tmp3_ = TRUE;
	} else {
		const gchar* _tmp5_ = NULL;
		_tmp5_ = fi;
		_tmp3_ = g_strcmp0 (_tmp5_, "") == 0;
	}
	if (_tmp3_) {
		_tmp2_ = TRUE;
	} else {
		const gchar* _tmp6_ = NULL;
		_tmp6_ = fi;
		_tmp2_ = g_strcmp0 (_tmp6_, "&") == 0;
	}
	if (_tmp2_) {
		_tmp1_ = TRUE;
	} else {
		const gchar* _tmp7_ = NULL;
		_tmp7_ = fi;
		_tmp1_ = g_strcmp0 (_tmp7_, "X)") == 0;
	}
	if (_tmp1_) {
		_tmp0_ = TRUE;
	} else {
		const gchar* _tmp8_ = NULL;
		_tmp8_ = fi;
		_tmp0_ = g_strcmp0 (_tmp8_, "(X") == 0;
	}
	if (_tmp0_) {
		result = NULL;
		return result;
	}
	_tmp10_ = fi;
	_tmp11_ = string_contains (_tmp10_, "(&");
	if (_tmp11_) {
		_tmp9_ = TRUE;
	} else {
		const gchar* _tmp12_ = NULL;
		gboolean _tmp13_ = FALSE;
		_tmp12_ = fi;
		_tmp13_ = string_contains (_tmp12_, "&)");
		_tmp9_ = _tmp13_;
	}
	if (_tmp9_) {
		result = NULL;
		return result;
	}
	_tmp14_ = fi;
	_tmp15_ = string_replace (_tmp14_, "(X&X)", "X");
	_tmp16_ = _tmp15_;
	_tmp17_ = proyecto_de_logica_logic_remove_extrapars (self, _tmp16_);
	_tmp18_ = _tmp17_;
	_g_free0 (_tmp16_);
	formula_new = _tmp18_;
	_tmp19_ = formula_new;
	_tmp20_ = fi;
	if (g_strcmp0 (_tmp19_, _tmp20_) != 0) {
		const gchar* _tmp21_ = NULL;
		gchar* _tmp22_ = NULL;
		gchar* _tmp23_ = NULL;
		_tmp21_ = formula_new;
		_tmp22_ = proyecto_de_logica_logic_check_formula (self, _tmp21_);
		_tmp23_ = _tmp22_;
		_g_free0 (_tmp23_);
	}
	_tmp24_ = fi;
	_tmp25_ = proyecto_de_logica_logic_final_check (self, _tmp24_);
	result = _tmp25_;
	_g_free0 (formula_new);
	return result;
}


static gboolean string_get_next_char (const gchar* self, gint* index, gunichar* c) {
	gunichar _vala_c = 0U;
	gboolean result = FALSE;
	gint _tmp0_ = 0;
	gunichar _tmp1_ = 0U;
	gunichar _tmp2_ = 0U;
	g_return_val_if_fail (self != NULL, FALSE);
	_tmp0_ = *index;
	_tmp1_ = g_utf8_get_char (((gchar*) self) + _tmp0_);
	_vala_c = _tmp1_;
	_tmp2_ = _vala_c;
	if (_tmp2_ != ((gunichar) 0)) {
		gint _tmp3_ = 0;
		gchar* _tmp4_ = NULL;
		_tmp3_ = *index;
		_tmp4_ = g_utf8_next_char (((gchar*) self) + _tmp3_);
		*index = (gint) (_tmp4_ - ((gchar*) self));
		result = TRUE;
		if (c) {
			*c = _vala_c;
		}
		return result;
	} else {
		result = FALSE;
		if (c) {
			*c = _vala_c;
		}
		return result;
	}
	if (c) {
		*c = _vala_c;
	}
}


gchar* proyecto_de_logica_logic_simplify_formula (ProyectoDeLogicaLogic* self, const gchar* fi) {
	gchar* result = NULL;
	gunichar c = 0U;
	gboolean modified = FALSE;
	GString* builder = NULL;
	GString* _tmp0_ = NULL;
	GString* builder_final = NULL;
	GString* _tmp1_ = NULL;
	GString* _tmp9_ = NULL;
	const gchar* _tmp10_ = NULL;
	gboolean _tmp11_ = FALSE;
	gchar* builded = NULL;
	GString* _tmp15_ = NULL;
	const gchar* _tmp16_ = NULL;
	gchar* _tmp17_ = NULL;
	const gchar* _tmp18_ = NULL;
	const gchar* _tmp19_ = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	g_return_val_if_fail (fi != NULL, NULL);
	modified = FALSE;
	_tmp0_ = g_string_new ("");
	builder = _tmp0_;
	_tmp1_ = g_string_new ("");
	builder_final = _tmp1_;
	{
		gint i = 0;
		i = 0;
		{
			gboolean _tmp2_ = FALSE;
			_tmp2_ = TRUE;
			while (TRUE) {
				const gchar* _tmp3_ = NULL;
				gunichar _tmp4_ = 0U;
				gboolean _tmp5_ = FALSE;
				gunichar _tmp6_ = 0U;
				GString* _tmp7_ = NULL;
				gunichar _tmp8_ = 0U;
				if (!_tmp2_) {
				}
				_tmp2_ = FALSE;
				_tmp3_ = fi;
				_tmp5_ = string_get_next_char (_tmp3_, &i, &_tmp4_);
				c = _tmp4_;
				if (!_tmp5_) {
					break;
				}
				_tmp6_ = c;
				switch (_tmp6_) {
					case 'A':
					case 'B':
					case 'C':
					case 'D':
					case 'E':
					case 'F':
					case 'G':
					case 'H':
					case 'I':
					case 'J':
					case 'K':
					case 'L':
					case 'M':
					case 'N':
					case 'O':
					case 'P':
					case 'Q':
					case 'R':
					case 'S':
					case 'T':
					case 'U':
					case 'V':
					case 'W':
					case 'X':
					case 'Y':
					case 'Z':
					case 9723U:
					{
						c = (gunichar) 'X';
						break;
					}
					case '|':
					case 8658U:
					case 8660U:
					case 8659U:
					case 8657U:
					{
						c = (gunichar) '&';
						break;
					}
					case '[':
					case '{':
					{
						c = (gunichar) '(';
						break;
					}
					case ']':
					case '}':
					{
						c = (gunichar) ')';
						break;
					}
					default:
					break;
				}
				_tmp7_ = builder;
				_tmp8_ = c;
				g_string_append_unichar (_tmp7_, _tmp8_);
			}
		}
	}
	_tmp9_ = builder;
	_tmp10_ = _tmp9_->str;
	_tmp11_ = string_contains (_tmp10_, ")!");
	if (_tmp11_) {
		GString* _tmp12_ = NULL;
		const gchar* _tmp13_ = NULL;
		gchar* _tmp14_ = NULL;
		_tmp12_ = builder;
		_tmp13_ = _tmp12_->str;
		_tmp14_ = g_strdup (_tmp13_);
		result = _tmp14_;
		_g_string_free0 (builder_final);
		_g_string_free0 (builder);
		return result;
	}
	_tmp15_ = builder;
	_tmp16_ = _tmp15_->str;
	_tmp17_ = g_strdup (_tmp16_);
	builded = _tmp17_;
	_tmp18_ = fi;
	_tmp19_ = builded;
	if (g_strcmp0 (_tmp18_, _tmp19_) == 0) {
		const gchar* _tmp20_ = NULL;
		gchar* _tmp21_ = NULL;
		_tmp20_ = builded;
		_tmp21_ = proyecto_de_logica_logic_remove_extrapars (self, _tmp20_);
		result = _tmp21_;
		_g_free0 (builded);
		_g_string_free0 (builder_final);
		_g_string_free0 (builder);
		return result;
	} else {
		const gchar* _tmp22_ = NULL;
		gchar* _tmp23_ = NULL;
		_tmp22_ = builded;
		_tmp23_ = proyecto_de_logica_logic_simplify_formula (self, _tmp22_);
		result = _tmp23_;
		_g_free0 (builded);
		_g_string_free0 (builder_final);
		_g_string_free0 (builder);
		return result;
	}
	_g_free0 (builded);
	_g_string_free0 (builder_final);
	_g_string_free0 (builder);
}


gchar* proyecto_de_logica_logic_remove_extrapars (ProyectoDeLogicaLogic* self, const gchar* fi) {
	gchar* result = NULL;
	gchar* test = NULL;
	const gchar* _tmp0_ = NULL;
	gboolean _tmp1_ = FALSE;
	const gchar* _tmp18_ = NULL;
	const gchar* _tmp19_ = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	g_return_val_if_fail (fi != NULL, NULL);
	_tmp0_ = fi;
	_tmp1_ = string_contains (_tmp0_, "!(X)");
	if (_tmp1_) {
		const gchar* _tmp2_ = NULL;
		gchar* _tmp3_ = NULL;
		_tmp2_ = fi;
		_tmp3_ = string_replace (_tmp2_, "!(X)", "X");
		_g_free0 (test);
		test = _tmp3_;
	} else {
		const gchar* _tmp4_ = NULL;
		gboolean _tmp5_ = FALSE;
		_tmp4_ = fi;
		_tmp5_ = string_contains (_tmp4_, "!X");
		if (_tmp5_) {
			const gchar* _tmp6_ = NULL;
			gchar* _tmp7_ = NULL;
			_tmp6_ = fi;
			_tmp7_ = string_replace (_tmp6_, "!X", "X");
			_g_free0 (test);
			test = _tmp7_;
		} else {
			const gchar* _tmp8_ = NULL;
			gboolean _tmp9_ = FALSE;
			_tmp8_ = fi;
			_tmp9_ = string_contains (_tmp8_, "(X)");
			if (_tmp9_) {
				const gchar* _tmp10_ = NULL;
				gchar* _tmp11_ = NULL;
				_tmp10_ = fi;
				_tmp11_ = string_replace (_tmp10_, "(X)", "X");
				_g_free0 (test);
				test = _tmp11_;
			} else {
				const gchar* _tmp12_ = NULL;
				gboolean _tmp13_ = FALSE;
				_tmp12_ = fi;
				_tmp13_ = string_contains (_tmp12_, "((X&X))");
				if (_tmp13_) {
					const gchar* _tmp14_ = NULL;
					gchar* _tmp15_ = NULL;
					_tmp14_ = fi;
					_tmp15_ = string_replace (_tmp14_, "((X&X))", "(X&X)");
					_g_free0 (test);
					test = _tmp15_;
				} else {
					const gchar* _tmp16_ = NULL;
					gchar* _tmp17_ = NULL;
					_tmp16_ = fi;
					_tmp17_ = g_strdup (_tmp16_);
					_g_free0 (test);
					test = _tmp17_;
				}
			}
		}
	}
	_tmp18_ = test;
	_tmp19_ = fi;
	if (g_strcmp0 (_tmp18_, _tmp19_) == 0) {
		result = test;
		return result;
	} else {
		const gchar* _tmp20_ = NULL;
		gchar* _tmp21_ = NULL;
		_tmp20_ = test;
		_tmp21_ = proyecto_de_logica_logic_remove_extrapars (self, _tmp20_);
		result = _tmp21_;
		_g_free0 (test);
		return result;
	}
	_g_free0 (test);
}


gchar* proyecto_de_logica_logic_remove_spaces (ProyectoDeLogicaLogic* self, const gchar* fi) {
	gchar* result = NULL;
	gunichar c = 0U;
	GString* builder = NULL;
	GString* _tmp0_ = NULL;
	GString* _tmp8_ = NULL;
	const gchar* _tmp9_ = NULL;
	gchar* _tmp10_ = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	g_return_val_if_fail (fi != NULL, NULL);
	_tmp0_ = g_string_new ("");
	builder = _tmp0_;
	{
		gint i = 0;
		i = 0;
		{
			gboolean _tmp1_ = FALSE;
			_tmp1_ = TRUE;
			while (TRUE) {
				const gchar* _tmp2_ = NULL;
				gunichar _tmp3_ = 0U;
				gboolean _tmp4_ = FALSE;
				gunichar _tmp5_ = 0U;
				if (!_tmp1_) {
				}
				_tmp1_ = FALSE;
				_tmp2_ = fi;
				_tmp4_ = string_get_next_char (_tmp2_, &i, &_tmp3_);
				c = _tmp3_;
				if (!_tmp4_) {
					break;
				}
				_tmp5_ = c;
				if (_tmp5_ != ((gunichar) ' ')) {
					GString* _tmp6_ = NULL;
					gunichar _tmp7_ = 0U;
					_tmp6_ = builder;
					_tmp7_ = c;
					g_string_append_unichar (_tmp6_, _tmp7_);
				}
			}
		}
	}
	_tmp8_ = builder;
	_tmp9_ = _tmp8_->str;
	_tmp10_ = g_strdup (_tmp9_);
	result = _tmp10_;
	_g_string_free0 (builder);
	return result;
}


gchar* proyecto_de_logica_logic_add_spaces (ProyectoDeLogicaLogic* self, const gchar* fi, gint a) {
	gchar* result = NULL;
	gchar* nfi = NULL;
	gboolean _tmp0_ = FALSE;
	const gchar* _tmp1_ = NULL;
	gboolean _tmp2_ = FALSE;
	gint _tmp32_ = 0;
	gint _tmp33_ = 0;
	g_return_val_if_fail (self != NULL, NULL);
	g_return_val_if_fail (fi != NULL, NULL);
	_tmp1_ = fi;
	_tmp2_ = string_contains (_tmp1_, "&");
	if (_tmp2_) {
		gint _tmp3_ = 0;
		_tmp3_ = a;
		_tmp0_ = _tmp3_ == 0;
	} else {
		_tmp0_ = FALSE;
	}
	if (_tmp0_) {
		const gchar* _tmp4_ = NULL;
		gchar* _tmp5_ = NULL;
		_tmp4_ = fi;
		_tmp5_ = string_replace (_tmp4_, "&", " & ");
		_g_free0 (nfi);
		nfi = _tmp5_;
	} else {
		gboolean _tmp6_ = FALSE;
		const gchar* _tmp7_ = NULL;
		gboolean _tmp8_ = FALSE;
		_tmp7_ = fi;
		_tmp8_ = string_contains (_tmp7_, "|");
		if (_tmp8_) {
			gint _tmp9_ = 0;
			_tmp9_ = a;
			_tmp6_ = _tmp9_ == 1;
		} else {
			_tmp6_ = FALSE;
		}
		if (_tmp6_) {
			const gchar* _tmp10_ = NULL;
			gchar* _tmp11_ = NULL;
			_tmp10_ = fi;
			_tmp11_ = string_replace (_tmp10_, "|", " | ");
			_g_free0 (nfi);
			nfi = _tmp11_;
		} else {
			gboolean _tmp12_ = FALSE;
			const gchar* _tmp13_ = NULL;
			gboolean _tmp14_ = FALSE;
			_tmp13_ = fi;
			_tmp14_ = string_contains (_tmp13_, "⇒");
			if (_tmp14_) {
				gint _tmp15_ = 0;
				_tmp15_ = a;
				_tmp12_ = _tmp15_ == 2;
			} else {
				_tmp12_ = FALSE;
			}
			if (_tmp12_) {
				const gchar* _tmp16_ = NULL;
				gchar* _tmp17_ = NULL;
				_tmp16_ = fi;
				_tmp17_ = string_replace (_tmp16_, "⇒", " ⇒ ");
				_g_free0 (nfi);
				nfi = _tmp17_;
			} else {
				gboolean _tmp18_ = FALSE;
				const gchar* _tmp19_ = NULL;
				gboolean _tmp20_ = FALSE;
				_tmp19_ = fi;
				_tmp20_ = string_contains (_tmp19_, "⇔");
				if (_tmp20_) {
					gint _tmp21_ = 0;
					_tmp21_ = a;
					_tmp18_ = _tmp21_ == 3;
				} else {
					_tmp18_ = FALSE;
				}
				if (_tmp18_) {
					const gchar* _tmp22_ = NULL;
					gchar* _tmp23_ = NULL;
					_tmp22_ = fi;
					_tmp23_ = string_replace (_tmp22_, "⇔", " ⇔ ");
					_g_free0 (nfi);
					nfi = _tmp23_;
				} else {
					gboolean _tmp24_ = FALSE;
					const gchar* _tmp25_ = NULL;
					gboolean _tmp26_ = FALSE;
					_tmp25_ = fi;
					_tmp26_ = string_contains (_tmp25_, ",");
					if (_tmp26_) {
						gint _tmp27_ = 0;
						_tmp27_ = a;
						_tmp24_ = _tmp27_ == 4;
					} else {
						_tmp24_ = FALSE;
					}
					if (_tmp24_) {
						const gchar* _tmp28_ = NULL;
						gchar* _tmp29_ = NULL;
						_tmp28_ = fi;
						_tmp29_ = string_replace (_tmp28_, ",", " , ");
						_g_free0 (nfi);
						nfi = _tmp29_;
					} else {
						const gchar* _tmp30_ = NULL;
						gchar* _tmp31_ = NULL;
						_tmp30_ = fi;
						_tmp31_ = g_strdup (_tmp30_);
						_g_free0 (nfi);
						nfi = _tmp31_;
					}
				}
			}
		}
	}
	_tmp32_ = a;
	a = _tmp32_ + 1;
	_tmp33_ = a;
	if (_tmp33_ == 5) {
		result = nfi;
		return result;
	} else {
		const gchar* _tmp34_ = NULL;
		gint _tmp35_ = 0;
		gchar* _tmp36_ = NULL;
		_tmp34_ = nfi;
		_tmp35_ = a;
		_tmp36_ = proyecto_de_logica_logic_add_spaces (self, _tmp34_, _tmp35_);
		result = _tmp36_;
		_g_free0 (nfi);
		return result;
	}
	_g_free0 (nfi);
}


gboolean proyecto_de_logica_logic_count_pars (ProyectoDeLogicaLogic* self, const gchar* fi) {
	gboolean result = FALSE;
	g_return_val_if_fail (self != NULL, FALSE);
	g_return_val_if_fail (fi != NULL, FALSE);
	result = TRUE;
	return result;
}


gboolean proyecto_de_logica_logic_check_pars (ProyectoDeLogicaLogic* self, const gchar* fi) {
	gboolean result = FALSE;
	g_return_val_if_fail (self != NULL, FALSE);
	g_return_val_if_fail (fi != NULL, FALSE);
	result = TRUE;
	return result;
}


static gchar* proyecto_de_logica_logic_easy_build (ProyectoDeLogicaLogic* self, const gchar* fi) {
	gchar* result = NULL;
	gchar* nfi = NULL;
	const gchar* _tmp0_ = NULL;
	gboolean _tmp1_ = FALSE;
	const gchar* _tmp42_ = NULL;
	const gchar* _tmp43_ = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	g_return_val_if_fail (fi != NULL, NULL);
	_tmp0_ = fi;
	_tmp1_ = string_contains (_tmp0_, "<->");
	if (_tmp1_) {
		const gchar* _tmp2_ = NULL;
		gchar* _tmp3_ = NULL;
		_tmp2_ = fi;
		_tmp3_ = string_replace (_tmp2_, "<->", "⇔");
		_g_free0 (nfi);
		nfi = _tmp3_;
	} else {
		const gchar* _tmp4_ = NULL;
		gboolean _tmp5_ = FALSE;
		_tmp4_ = fi;
		_tmp5_ = string_contains (_tmp4_, "<=>");
		if (_tmp5_) {
			const gchar* _tmp6_ = NULL;
			gchar* _tmp7_ = NULL;
			_tmp6_ = fi;
			_tmp7_ = string_replace (_tmp6_, "<=>", "⇔");
			_g_free0 (nfi);
			nfi = _tmp7_;
		} else {
			const gchar* _tmp8_ = NULL;
			gboolean _tmp9_ = FALSE;
			_tmp8_ = fi;
			_tmp9_ = string_contains (_tmp8_, "->");
			if (_tmp9_) {
				const gchar* _tmp10_ = NULL;
				gchar* _tmp11_ = NULL;
				_tmp10_ = fi;
				_tmp11_ = string_replace (_tmp10_, "->", "⇒ ");
				_g_free0 (nfi);
				nfi = _tmp11_;
			} else {
				const gchar* _tmp12_ = NULL;
				gboolean _tmp13_ = FALSE;
				_tmp12_ = fi;
				_tmp13_ = string_contains (_tmp12_, "=>");
				if (_tmp13_) {
					const gchar* _tmp14_ = NULL;
					gchar* _tmp15_ = NULL;
					_tmp14_ = fi;
					_tmp15_ = string_replace (_tmp14_, "=>", "⇒ ");
					_g_free0 (nfi);
					nfi = _tmp15_;
				} else {
					const gchar* _tmp16_ = NULL;
					gboolean _tmp17_ = FALSE;
					_tmp16_ = fi;
					_tmp17_ = string_contains (_tmp16_, "⟷");
					if (_tmp17_) {
						const gchar* _tmp18_ = NULL;
						gchar* _tmp19_ = NULL;
						_tmp18_ = fi;
						_tmp19_ = string_replace (_tmp18_, "⟷", "⇔");
						_g_free0 (nfi);
						nfi = _tmp19_;
					} else {
						const gchar* _tmp20_ = NULL;
						gboolean _tmp21_ = FALSE;
						_tmp20_ = fi;
						_tmp21_ = string_contains (_tmp20_, "→");
						if (_tmp21_) {
							const gchar* _tmp22_ = NULL;
							gchar* _tmp23_ = NULL;
							_tmp22_ = fi;
							_tmp23_ = string_replace (_tmp22_, "→", "⇒");
							_g_free0 (nfi);
							nfi = _tmp23_;
						} else {
							const gchar* _tmp24_ = NULL;
							gboolean _tmp25_ = FALSE;
							_tmp24_ = fi;
							_tmp25_ = string_contains (_tmp24_, "∧");
							if (_tmp25_) {
								const gchar* _tmp26_ = NULL;
								gchar* _tmp27_ = NULL;
								_tmp26_ = fi;
								_tmp27_ = string_replace (_tmp26_, "∧", "&");
								_g_free0 (nfi);
								nfi = _tmp27_;
							} else {
								const gchar* _tmp28_ = NULL;
								gboolean _tmp29_ = FALSE;
								_tmp28_ = fi;
								_tmp29_ = string_contains (_tmp28_, "∨");
								if (_tmp29_) {
									const gchar* _tmp30_ = NULL;
									gchar* _tmp31_ = NULL;
									_tmp30_ = fi;
									_tmp31_ = string_replace (_tmp30_, "∨", "|");
									_g_free0 (nfi);
									nfi = _tmp31_;
								} else {
									const gchar* _tmp32_ = NULL;
									gboolean _tmp33_ = FALSE;
									_tmp32_ = fi;
									_tmp33_ = string_contains (_tmp32_, "¬");
									if (_tmp33_) {
										const gchar* _tmp34_ = NULL;
										gchar* _tmp35_ = NULL;
										_tmp34_ = fi;
										_tmp35_ = string_replace (_tmp34_, "¬", "!");
										_g_free0 (nfi);
										nfi = _tmp35_;
									} else {
										const gchar* _tmp36_ = NULL;
										gboolean _tmp37_ = FALSE;
										_tmp36_ = fi;
										_tmp37_ = string_contains (_tmp36_, "[]");
										if (_tmp37_) {
											const gchar* _tmp38_ = NULL;
											gchar* _tmp39_ = NULL;
											_tmp38_ = fi;
											_tmp39_ = string_replace (_tmp38_, "[]", "◻");
											_g_free0 (nfi);
											nfi = _tmp39_;
										} else {
											const gchar* _tmp40_ = NULL;
											gchar* _tmp41_ = NULL;
											_tmp40_ = fi;
											_tmp41_ = g_strdup (_tmp40_);
											_g_free0 (nfi);
											nfi = _tmp41_;
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	_tmp42_ = nfi;
	_tmp43_ = fi;
	if (g_strcmp0 (_tmp42_, _tmp43_) == 0) {
		result = nfi;
		return result;
	} else {
		const gchar* _tmp44_ = NULL;
		gchar* _tmp45_ = NULL;
		_tmp44_ = nfi;
		_tmp45_ = proyecto_de_logica_logic_easy_build (self, _tmp44_);
		result = _tmp45_;
		_g_free0 (nfi);
		return result;
	}
	_g_free0 (nfi);
}


static void proyecto_de_logica_logic_button_clicked (ProyectoDeLogicaLogic* self, const gchar* label) {
	GtkEntry* _tmp0_ = NULL;
	gboolean _tmp1_ = FALSE;
	gboolean _tmp2_ = FALSE;
	g_return_if_fail (self != NULL);
	g_return_if_fail (label != NULL);
	_tmp0_ = proyecto_de_logica_formula;
	g_object_get ((GtkWidget*) _tmp0_, "has-focus", &_tmp1_, NULL);
	_tmp2_ = _tmp1_;
	if (_tmp2_) {
		GtkEntry* _tmp3_ = NULL;
		gint new_position = 0;
		GtkEntry* _tmp4_ = NULL;
		gint _tmp5_ = 0;
		GtkEntry* _tmp6_ = NULL;
		const gchar* _tmp7_ = NULL;
		gint _tmp8_ = 0;
		const gchar* _tmp9_ = NULL;
		gint _tmp10_ = 0;
		gint _tmp11_ = 0;
		gint _tmp18_ = 0;
		GtkEntry* _tmp19_ = NULL;
		GtkEntry* _tmp20_ = NULL;
		gint _tmp21_ = 0;
		_tmp3_ = proyecto_de_logica_formula;
		gtk_editable_delete_selection ((GtkEditable*) _tmp3_);
		_tmp4_ = proyecto_de_logica_formula;
		_tmp5_ = gtk_editable_get_position ((GtkEditable*) _tmp4_);
		new_position = _tmp5_;
		_tmp6_ = proyecto_de_logica_formula;
		_tmp7_ = label;
		g_signal_emit_by_name (_tmp6_, "insert-at-cursor", _tmp7_);
		_tmp9_ = label;
		_tmp10_ = strlen (_tmp9_);
		_tmp11_ = _tmp10_;
		if (_tmp11_ > 4) {
			const gchar* _tmp12_ = NULL;
			gint _tmp13_ = 0;
			gint _tmp14_ = 0;
			_tmp12_ = label;
			_tmp13_ = strlen (_tmp12_);
			_tmp14_ = _tmp13_;
			_tmp8_ = _tmp14_ - 4;
		} else {
			const gchar* _tmp15_ = NULL;
			gint _tmp16_ = 0;
			gint _tmp17_ = 0;
			_tmp15_ = label;
			_tmp16_ = strlen (_tmp15_);
			_tmp17_ = _tmp16_;
			_tmp8_ = _tmp17_ - 1;
		}
		_tmp18_ = new_position;
		new_position = _tmp18_ + _tmp8_;
		_tmp19_ = proyecto_de_logica_formula;
		gtk_widget_grab_focus ((GtkWidget*) _tmp19_);
		_tmp20_ = proyecto_de_logica_formula;
		_tmp21_ = new_position;
		gtk_editable_set_position ((GtkEditable*) _tmp20_, _tmp21_);
	} else {
		GtkEntry* _tmp22_ = NULL;
		gboolean _tmp23_ = FALSE;
		gboolean _tmp24_ = FALSE;
		_tmp22_ = proyecto_de_logica_formula2;
		g_object_get ((GtkWidget*) _tmp22_, "has-focus", &_tmp23_, NULL);
		_tmp24_ = _tmp23_;
		if (_tmp24_) {
			GtkEntry* _tmp25_ = NULL;
			gint new_position = 0;
			GtkEntry* _tmp26_ = NULL;
			gint _tmp27_ = 0;
			GtkEntry* _tmp28_ = NULL;
			const gchar* _tmp29_ = NULL;
			gint _tmp30_ = 0;
			const gchar* _tmp31_ = NULL;
			gint _tmp32_ = 0;
			gint _tmp33_ = 0;
			gint _tmp40_ = 0;
			GtkEntry* _tmp41_ = NULL;
			GtkEntry* _tmp42_ = NULL;
			gint _tmp43_ = 0;
			_tmp25_ = proyecto_de_logica_formula2;
			gtk_editable_delete_selection ((GtkEditable*) _tmp25_);
			_tmp26_ = proyecto_de_logica_formula2;
			_tmp27_ = gtk_editable_get_position ((GtkEditable*) _tmp26_);
			new_position = _tmp27_;
			_tmp28_ = proyecto_de_logica_formula2;
			_tmp29_ = label;
			g_signal_emit_by_name (_tmp28_, "insert-at-cursor", _tmp29_);
			_tmp31_ = label;
			_tmp32_ = strlen (_tmp31_);
			_tmp33_ = _tmp32_;
			if (_tmp33_ > 4) {
				const gchar* _tmp34_ = NULL;
				gint _tmp35_ = 0;
				gint _tmp36_ = 0;
				_tmp34_ = label;
				_tmp35_ = strlen (_tmp34_);
				_tmp36_ = _tmp35_;
				_tmp30_ = _tmp36_ - 4;
			} else {
				const gchar* _tmp37_ = NULL;
				gint _tmp38_ = 0;
				gint _tmp39_ = 0;
				_tmp37_ = label;
				_tmp38_ = strlen (_tmp37_);
				_tmp39_ = _tmp38_;
				_tmp30_ = _tmp39_ - 1;
			}
			_tmp40_ = new_position;
			new_position = _tmp40_ + _tmp30_;
			_tmp41_ = proyecto_de_logica_formula2;
			gtk_widget_grab_focus ((GtkWidget*) _tmp41_);
			_tmp42_ = proyecto_de_logica_formula2;
			_tmp43_ = new_position;
			gtk_editable_set_position ((GtkEditable*) _tmp42_, _tmp43_);
		}
	}
}


GtkButton* proyecto_de_logica_logic_LogicButton (ProyectoDeLogicaLogic* self, const gchar* text) {
	GtkButton* result = NULL;
	GtkButton* temp = NULL;
	const gchar* _tmp0_ = NULL;
	GtkButton* _tmp1_ = NULL;
	GtkStyleContext* _tmp2_ = NULL;
	g_return_val_if_fail (self != NULL, NULL);
	g_return_val_if_fail (text != NULL, NULL);
	_tmp0_ = text;
	_tmp1_ = (GtkButton*) gtk_button_new_with_label (_tmp0_);
	g_object_ref_sink (_tmp1_);
	temp = _tmp1_;
	_tmp2_ = gtk_widget_get_style_context ((GtkWidget*) temp);
	gtk_style_context_add_class (_tmp2_, "h3");
	gtk_widget_set_size_request ((GtkWidget*) temp, 60, 45);
	g_object_set ((GtkWidget*) temp, "can-focus", FALSE, NULL);
	result = temp;
	return result;
}


static Block1Data* block1_data_ref (Block1Data* _data1_) {
	g_atomic_int_inc (&_data1_->_ref_count_);
	return _data1_;
}


static void block1_data_unref (void * _userdata_) {
	Block1Data* _data1_;
	_data1_ = (Block1Data*) _userdata_;
	if (g_atomic_int_dec_and_test (&_data1_->_ref_count_)) {
		ProyectoDeLogicaLogic* self;
		self = _data1_->self;
		_g_object_unref0 (_data1_->Calculate);
		_g_object_unref0 (_data1_->entails);
		_g_object_unref0 (_data1_->error_css);
		_g_object_unref0 (self);
		g_slice_free (Block1Data, _data1_);
	}
}


static void _gtk_main_quit_gtk_widget_destroy (GtkWidget* _sender, gpointer self) {
	gtk_main_quit ();
}


static gboolean __lambda10_ (Block1Data* _data1_, gboolean state) {
	ProyectoDeLogicaLogic* self;
	gboolean result = FALSE;
	gboolean _tmp0_ = FALSE;
	GtkEntry* _tmp25_ = NULL;
	GtkEntry* _tmp26_ = NULL;
	const gchar* _tmp27_ = NULL;
	const gchar* _tmp28_ = NULL;
	gchar* _tmp29_ = NULL;
	gchar* _tmp30_ = NULL;
	GtkEntry* _tmp31_ = NULL;
	GtkEntry* _tmp32_ = NULL;
	const gchar* _tmp33_ = NULL;
	const gchar* _tmp34_ = NULL;
	gchar* _tmp35_ = NULL;
	gchar* _tmp36_ = NULL;
	GtkEntry* _tmp37_ = NULL;
	GtkEntry* _tmp38_ = NULL;
	const gchar* _tmp39_ = NULL;
	const gchar* _tmp40_ = NULL;
	gchar* _tmp41_ = NULL;
	gchar* _tmp42_ = NULL;
	GtkEntry* _tmp43_ = NULL;
	GtkEntry* _tmp44_ = NULL;
	const gchar* _tmp45_ = NULL;
	const gchar* _tmp46_ = NULL;
	gchar* _tmp47_ = NULL;
	gchar* _tmp48_ = NULL;
	self = _data1_->self;
	_tmp0_ = state;
	if (_tmp0_) {
		GtkGrid* _tmp1_ = NULL;
		GtkEntry* _tmp2_ = NULL;
		GtkGrid* _tmp3_ = NULL;
		GtkEntry* _tmp4_ = NULL;
		GtkGrid* _tmp5_ = NULL;
		GtkGrid* _tmp6_ = NULL;
		GtkEntry* _tmp7_ = NULL;
		_tmp1_ = proyecto_de_logica_grid;
		_tmp2_ = proyecto_de_logica_formula;
		gtk_container_remove ((GtkContainer*) _tmp1_, (GtkWidget*) _tmp2_);
		_tmp3_ = proyecto_de_logica_grid;
		_tmp4_ = proyecto_de_logica_formula;
		gtk_grid_attach (_tmp3_, (GtkWidget*) _tmp4_, 0, 0, 7, 1);
		_tmp5_ = proyecto_de_logica_grid;
		gtk_grid_attach (_tmp5_, (GtkWidget*) _data1_->entails, 7, 0, 1, 1);
		_tmp6_ = proyecto_de_logica_grid;
		_tmp7_ = proyecto_de_logica_formula2;
		gtk_grid_attach (_tmp6_, (GtkWidget*) _tmp7_, 8, 0, 7, 1);
		gtk_label_set_label (_data1_->entails, "⊨");
		gtk_widget_show_all ((GtkWidget*) self);
	} else {
		GtkEntry* _tmp8_ = NULL;
		GtkGrid* _tmp9_ = NULL;
		GtkEntry* _tmp10_ = NULL;
		GtkGrid* _tmp11_ = NULL;
		GtkEntry* _tmp12_ = NULL;
		GtkGrid* _tmp13_ = NULL;
		GtkGrid* _tmp14_ = NULL;
		GtkEntry* _tmp15_ = NULL;
		GtkEntry* _tmp16_ = NULL;
		const gchar* _tmp17_ = NULL;
		const gchar* _tmp18_ = NULL;
		gchar* _tmp19_ = NULL;
		gchar* _tmp20_ = NULL;
		gboolean _tmp21_ = FALSE;
		_tmp8_ = proyecto_de_logica_formula;
		g_object_set ((GtkWidget*) _tmp8_, "has-focus", TRUE, NULL);
		gtk_label_set_label (_data1_->entails, "0");
		_tmp9_ = proyecto_de_logica_grid;
		_tmp10_ = proyecto_de_logica_formula;
		gtk_container_remove ((GtkContainer*) _tmp9_, (GtkWidget*) _tmp10_);
		_tmp11_ = proyecto_de_logica_grid;
		_tmp12_ = proyecto_de_logica_formula2;
		gtk_container_remove ((GtkContainer*) _tmp11_, (GtkWidget*) _tmp12_);
		_tmp13_ = proyecto_de_logica_grid;
		gtk_container_remove ((GtkContainer*) _tmp13_, (GtkWidget*) _data1_->entails);
		_tmp14_ = proyecto_de_logica_grid;
		_tmp15_ = proyecto_de_logica_formula;
		gtk_grid_attach (_tmp14_, (GtkWidget*) _tmp15_, 0, 0, 15, 1);
		_tmp16_ = proyecto_de_logica_formula;
		_tmp17_ = gtk_entry_get_text (_tmp16_);
		_tmp18_ = _tmp17_;
		_tmp19_ = proyecto_de_logica_logic_remove_spaces (self, _tmp18_);
		_tmp20_ = _tmp19_;
		_tmp21_ = g_strcmp0 (_tmp20_, "") == 0;
		_g_free0 (_tmp20_);
		if (_tmp21_) {
			GtkStyleContext* _tmp22_ = NULL;
			GtkStyleContext* _tmp23_ = NULL;
			GdkScreen* _tmp24_ = NULL;
			_tmp22_ = gtk_widget_get_style_context ((GtkWidget*) _data1_->Calculate);
			gtk_style_context_add_class (_tmp22_, GTK_STYLE_CLASS_SUGGESTED_ACTION);
			_tmp23_ = gtk_widget_get_style_context ((GtkWidget*) _data1_->Calculate);
			gtk_style_context_remove_class (_tmp23_, GTK_STYLE_CLASS_DESTRUCTIVE_ACTION);
			_tmp24_ = gdk_screen_get_default ();
			gtk_style_context_remove_provider_for_screen (_tmp24_, (GtkStyleProvider*) _data1_->error_css);
		}
	}
	_tmp25_ = proyecto_de_logica_formula;
	_tmp26_ = proyecto_de_logica_formula;
	_tmp27_ = gtk_entry_get_text (_tmp26_);
	_tmp28_ = _tmp27_;
	_tmp29_ = g_strconcat (_tmp28_, "~", NULL);
	_tmp30_ = _tmp29_;
	gtk_entry_set_text (_tmp25_, _tmp30_);
	_g_free0 (_tmp30_);
	_tmp31_ = proyecto_de_logica_formula;
	_tmp32_ = proyecto_de_logica_formula;
	_tmp33_ = gtk_entry_get_text (_tmp32_);
	_tmp34_ = _tmp33_;
	_tmp35_ = string_replace (_tmp34_, "~", "");
	_tmp36_ = _tmp35_;
	gtk_entry_set_text (_tmp31_, _tmp36_);
	_g_free0 (_tmp36_);
	_tmp37_ = proyecto_de_logica_formula2;
	_tmp38_ = proyecto_de_logica_formula2;
	_tmp39_ = gtk_entry_get_text (_tmp38_);
	_tmp40_ = _tmp39_;
	_tmp41_ = g_strconcat (_tmp40_, "~", NULL);
	_tmp42_ = _tmp41_;
	gtk_entry_set_text (_tmp37_, _tmp42_);
	_g_free0 (_tmp42_);
	_tmp43_ = proyecto_de_logica_formula2;
	_tmp44_ = proyecto_de_logica_formula2;
	_tmp45_ = gtk_entry_get_text (_tmp44_);
	_tmp46_ = _tmp45_;
	_tmp47_ = string_replace (_tmp46_, "~", "");
	_tmp48_ = _tmp47_;
	gtk_entry_set_text (_tmp43_, _tmp48_);
	_g_free0 (_tmp48_);
	result = FALSE;
	return result;
}


static gboolean ___lambda10__gtk_switch_state_set (GtkSwitch* _sender, gboolean state, gpointer self) {
	gboolean result;
	result = __lambda10_ (self, state);
	return result;
}


static gboolean __lambda11_ (ProyectoDeLogicaLogic* self) {
	gboolean result = FALSE;
	gboolean _tmp0_ = FALSE;
	_tmp0_ = self->formula_focus;
	if (_tmp0_ == FALSE) {
		self->formula_focus = TRUE;
	}
	result = FALSE;
	return result;
}


static gboolean ___lambda11__gtk_widget_focus_in_event (GtkWidget* _sender, GdkEventFocus* event, gpointer self) {
	gboolean result;
	result = __lambda11_ ((ProyectoDeLogicaLogic*) self);
	return result;
}


static void __lambda12_ (ProyectoDeLogicaLogic* self) {
	proyecto_de_logica_logic_button_clicked (self, "( & )");
}


static void ___lambda12__gtk_button_clicked (GtkButton* _sender, gpointer self) {
	__lambda12_ ((ProyectoDeLogicaLogic*) self);
}


static void __lambda13_ (ProyectoDeLogicaLogic* self) {
	proyecto_de_logica_logic_button_clicked (self, "( | )");
}


static void ___lambda13__gtk_button_clicked (GtkButton* _sender, gpointer self) {
	__lambda13_ ((ProyectoDeLogicaLogic*) self);
}


static void __lambda14_ (ProyectoDeLogicaLogic* self) {
	proyecto_de_logica_logic_button_clicked (self, "!()");
}


static void ___lambda14__gtk_button_clicked (GtkButton* _sender, gpointer self) {
	__lambda14_ ((ProyectoDeLogicaLogic*) self);
}


static void __lambda15_ (ProyectoDeLogicaLogic* self) {
	proyecto_de_logica_logic_button_clicked (self, "( )");
}


static void ___lambda15__gtk_button_clicked (GtkButton* _sender, gpointer self) {
	__lambda15_ ((ProyectoDeLogicaLogic*) self);
}


static void __lambda16_ (ProyectoDeLogicaLogic* self) {
	proyecto_de_logica_logic_button_clicked (self, "( ⇒ )");
}


static void ___lambda16__gtk_button_clicked (GtkButton* _sender, gpointer self) {
	__lambda16_ ((ProyectoDeLogicaLogic*) self);
}


static void __lambda17_ (ProyectoDeLogicaLogic* self) {
	proyecto_de_logica_logic_button_clicked (self, "( ⇔ )");
}


static void ___lambda17__gtk_button_clicked (GtkButton* _sender, gpointer self) {
	__lambda17_ ((ProyectoDeLogicaLogic*) self);
}


static void __lambda18_ (ProyectoDeLogicaLogic* self) {
	proyecto_de_logica_logic_button_clicked (self, "( ⇑ )");
}


static void ___lambda18__gtk_button_clicked (GtkButton* _sender, gpointer self) {
	__lambda18_ ((ProyectoDeLogicaLogic*) self);
}


static void __lambda19_ (ProyectoDeLogicaLogic* self) {
	proyecto_de_logica_logic_button_clicked (self, "( ⇓ )");
}


static void ___lambda19__gtk_button_clicked (GtkButton* _sender, gpointer self) {
	__lambda19_ ((ProyectoDeLogicaLogic*) self);
}


static void __lambda20_ (Block1Data* _data1_) {
	ProyectoDeLogicaLogic* self;
	GtkEntry* _tmp0_ = NULL;
	const gchar* _tmp1_ = NULL;
	const gchar* _tmp2_ = NULL;
	gboolean _tmp3_ = FALSE;
	GtkEntry* _tmp5_ = NULL;
	GtkStyleContext* _tmp6_ = NULL;
	GtkEntry* _tmp7_ = NULL;
	GtkEntry* _tmp8_ = NULL;
	const gchar* _tmp9_ = NULL;
	const gchar* _tmp10_ = NULL;
	gchar* _tmp11_ = NULL;
	gchar* _tmp12_ = NULL;
	GtkEntry* _tmp13_ = NULL;
	GtkEntry* _tmp14_ = NULL;
	const gchar* _tmp15_ = NULL;
	const gchar* _tmp16_ = NULL;
	gchar* _tmp17_ = NULL;
	gchar* _tmp18_ = NULL;
	GtkEntry* _tmp19_ = NULL;
	GtkEntry* _tmp20_ = NULL;
	const gchar* _tmp21_ = NULL;
	const gchar* _tmp22_ = NULL;
	gchar* _tmp23_ = NULL;
	gchar* _tmp24_ = NULL;
	gchar* _tmp25_ = NULL;
	gchar* _tmp26_ = NULL;
	gchar* _tmp27_ = NULL;
	gchar* _tmp28_ = NULL;
	const gchar* _tmp29_ = NULL;
	gboolean _tmp30_ = FALSE;
	const gchar* _tmp31_ = NULL;
	const gchar* _tmp32_ = NULL;
	self = _data1_->self;
	_tmp0_ = proyecto_de_logica_formula;
	_tmp1_ = gtk_entry_get_text (_tmp0_);
	_tmp2_ = _tmp1_;
	_tmp3_ = string_contains (_tmp2_, "◻");
	if (_tmp3_) {
		GtkEntry* _tmp4_ = NULL;
		_tmp4_ = proyecto_de_logica_formula;
		gtk_entry_set_text (_tmp4_, "◻");
	}
	_tmp5_ = proyecto_de_logica_formula;
	_tmp6_ = gtk_widget_get_style_context ((GtkWidget*) _tmp5_);
	gtk_style_context_add_provider (_tmp6_, (GtkStyleProvider*) _data1_->error_css, (guint) GTK_STYLE_PROVIDER_PRIORITY_USER);
	_tmp7_ = proyecto_de_logica_formula;
	_tmp8_ = proyecto_de_logica_formula;
	_tmp9_ = gtk_entry_get_text (_tmp8_);
	_tmp10_ = _tmp9_;
	_tmp11_ = g_utf8_strup (_tmp10_, (gssize) (-1));
	_tmp12_ = _tmp11_;
	gtk_entry_set_text (_tmp7_, _tmp12_);
	_g_free0 (_tmp12_);
	_tmp13_ = proyecto_de_logica_formula;
	_tmp14_ = proyecto_de_logica_formula;
	_tmp15_ = gtk_entry_get_text (_tmp14_);
	_tmp16_ = _tmp15_;
	_tmp17_ = proyecto_de_logica_logic_easy_build (self, _tmp16_);
	_tmp18_ = _tmp17_;
	gtk_entry_set_text (_tmp13_, _tmp18_);
	_g_free0 (_tmp18_);
	_tmp19_ = proyecto_de_logica_formula;
	_tmp20_ = proyecto_de_logica_formula;
	_tmp21_ = gtk_entry_get_text (_tmp20_);
	_tmp22_ = _tmp21_;
	_tmp23_ = proyecto_de_logica_logic_remove_spaces (self, _tmp22_);
	_tmp24_ = _tmp23_;
	_tmp25_ = proyecto_de_logica_logic_add_spaces (self, _tmp24_, 0);
	_tmp26_ = _tmp25_;
	_tmp27_ = string_replace (_tmp26_, " , ", "\n");
	_tmp28_ = _tmp27_;
	_tmp29_ = string_to_string (_tmp28_);
	gtk_widget_set_tooltip_text ((GtkWidget*) _tmp19_, _tmp29_);
	_g_free0 (_tmp28_);
	_g_free0 (_tmp26_);
	_g_free0 (_tmp24_);
	_tmp31_ = gtk_label_get_label (_data1_->entails);
	_tmp32_ = _tmp31_;
	if (g_strcmp0 (_tmp32_, "0") == 0) {
		GtkEntry* _tmp33_ = NULL;
		const gchar* _tmp34_ = NULL;
		const gchar* _tmp35_ = NULL;
		gchar* _tmp36_ = NULL;
		gchar* _tmp37_ = NULL;
		_tmp33_ = proyecto_de_logica_formula;
		_tmp34_ = gtk_entry_get_text (_tmp33_);
		_tmp35_ = _tmp34_;
		_tmp36_ = proyecto_de_logica_logic_remove_spaces (self, _tmp35_);
		_tmp37_ = _tmp36_;
		_tmp30_ = g_strcmp0 (_tmp37_, "") == 0;
		_g_free0 (_tmp37_);
	} else {
		_tmp30_ = FALSE;
	}
	if (_tmp30_) {
		GtkEntry* _tmp38_ = NULL;
		GtkStyleContext* _tmp39_ = NULL;
		_tmp38_ = proyecto_de_logica_formula;
		_tmp39_ = gtk_widget_get_style_context ((GtkWidget*) _tmp38_);
		gtk_style_context_remove_provider (_tmp39_, (GtkStyleProvider*) _data1_->error_css);
	}
	g_signal_emit_by_name (self, "check");
}


static void ___lambda20__gtk_editable_changed (GtkEditable* _sender, gpointer self) {
	__lambda20_ (self);
}


static void __lambda21_ (Block1Data* _data1_) {
	ProyectoDeLogicaLogic* self;
	GtkEntry* _tmp0_ = NULL;
	const gchar* _tmp1_ = NULL;
	const gchar* _tmp2_ = NULL;
	gboolean _tmp3_ = FALSE;
	GtkEntry* _tmp5_ = NULL;
	GtkStyleContext* _tmp6_ = NULL;
	GtkEntry* _tmp7_ = NULL;
	GtkEntry* _tmp8_ = NULL;
	const gchar* _tmp9_ = NULL;
	const gchar* _tmp10_ = NULL;
	gchar* _tmp11_ = NULL;
	gchar* _tmp12_ = NULL;
	GtkEntry* _tmp13_ = NULL;
	GtkEntry* _tmp14_ = NULL;
	const gchar* _tmp15_ = NULL;
	const gchar* _tmp16_ = NULL;
	gchar* _tmp17_ = NULL;
	gchar* _tmp18_ = NULL;
	GtkEntry* _tmp19_ = NULL;
	GtkEntry* _tmp20_ = NULL;
	const gchar* _tmp21_ = NULL;
	const gchar* _tmp22_ = NULL;
	gchar* _tmp23_ = NULL;
	gchar* _tmp24_ = NULL;
	gchar* _tmp25_ = NULL;
	gchar* _tmp26_ = NULL;
	gchar* _tmp27_ = NULL;
	gchar* _tmp28_ = NULL;
	const gchar* _tmp29_ = NULL;
	self = _data1_->self;
	_tmp0_ = proyecto_de_logica_formula2;
	_tmp1_ = gtk_entry_get_text (_tmp0_);
	_tmp2_ = _tmp1_;
	_tmp3_ = string_contains (_tmp2_, "◻");
	if (_tmp3_) {
		GtkEntry* _tmp4_ = NULL;
		_tmp4_ = proyecto_de_logica_formula2;
		gtk_entry_set_text (_tmp4_, "◻");
	}
	_tmp5_ = proyecto_de_logica_formula2;
	_tmp6_ = gtk_widget_get_style_context ((GtkWidget*) _tmp5_);
	gtk_style_context_add_provider (_tmp6_, (GtkStyleProvider*) _data1_->error_css, (guint) GTK_STYLE_PROVIDER_PRIORITY_USER);
	_tmp7_ = proyecto_de_logica_formula2;
	_tmp8_ = proyecto_de_logica_formula2;
	_tmp9_ = gtk_entry_get_text (_tmp8_);
	_tmp10_ = _tmp9_;
	_tmp11_ = g_utf8_strup (_tmp10_, (gssize) (-1));
	_tmp12_ = _tmp11_;
	gtk_entry_set_text (_tmp7_, _tmp12_);
	_g_free0 (_tmp12_);
	_tmp13_ = proyecto_de_logica_formula2;
	_tmp14_ = proyecto_de_logica_formula2;
	_tmp15_ = gtk_entry_get_text (_tmp14_);
	_tmp16_ = _tmp15_;
	_tmp17_ = proyecto_de_logica_logic_easy_build (self, _tmp16_);
	_tmp18_ = _tmp17_;
	gtk_entry_set_text (_tmp13_, _tmp18_);
	_g_free0 (_tmp18_);
	_tmp19_ = proyecto_de_logica_formula2;
	_tmp20_ = proyecto_de_logica_formula2;
	_tmp21_ = gtk_entry_get_text (_tmp20_);
	_tmp22_ = _tmp21_;
	_tmp23_ = proyecto_de_logica_logic_remove_spaces (self, _tmp22_);
	_tmp24_ = _tmp23_;
	_tmp25_ = proyecto_de_logica_logic_add_spaces (self, _tmp24_, 0);
	_tmp26_ = _tmp25_;
	_tmp27_ = string_replace (_tmp26_, " , ", "\n");
	_tmp28_ = _tmp27_;
	_tmp29_ = string_to_string (_tmp28_);
	gtk_widget_set_tooltip_text ((GtkWidget*) _tmp19_, _tmp29_);
	_g_free0 (_tmp28_);
	_g_free0 (_tmp26_);
	_g_free0 (_tmp24_);
	g_signal_emit_by_name (self, "check");
}


static void ___lambda21__gtk_editable_changed (GtkEditable* _sender, gpointer self) {
	__lambda21_ (self);
}


static void __lambda22_ (Block1Data* _data1_) {
	ProyectoDeLogicaLogic* self;
	GtkStyleContext* _tmp0_ = NULL;
	const gchar* _tmp1_ = NULL;
	const gchar* _tmp2_ = NULL;
	self = _data1_->self;
	gtk_button_set_label (_data1_->Calculate, "Check");
	_tmp0_ = gtk_widget_get_style_context ((GtkWidget*) _data1_->Calculate);
	gtk_style_context_add_class (_tmp0_, GTK_STYLE_CLASS_DESTRUCTIVE_ACTION);
	self->formula_valid = 0;
	_tmp1_ = gtk_label_get_label (_data1_->entails);
	_tmp2_ = _tmp1_;
	if (g_strcmp0 (_tmp2_, "0") != 0) {
		GtkEntry* _tmp3_ = NULL;
		const gchar* _tmp4_ = NULL;
		const gchar* _tmp5_ = NULL;
		gchar* _tmp6_ = NULL;
		gchar* _tmp7_ = NULL;
		gchar* _tmp8_ = NULL;
		gchar* _tmp9_ = NULL;
		gchar* _tmp10_ = NULL;
		gchar* _tmp11_ = NULL;
		GtkEntry* _tmp12_ = NULL;
		const gchar* _tmp13_ = NULL;
		const gchar* _tmp14_ = NULL;
		gchar* _tmp15_ = NULL;
		gchar* _tmp16_ = NULL;
		gchar* _tmp17_ = NULL;
		gchar* _tmp18_ = NULL;
		gchar* _tmp19_ = NULL;
		gchar* _tmp20_ = NULL;
		GtkEntry* _tmp21_ = NULL;
		const gchar* _tmp22_ = NULL;
		const gchar* _tmp23_ = NULL;
		gchar* _tmp24_ = NULL;
		gchar* _tmp25_ = NULL;
		gchar* _tmp26_ = NULL;
		gchar* _tmp27_ = NULL;
		gchar* _tmp28_ = NULL;
		gchar* _tmp29_ = NULL;
		_tmp3_ = proyecto_de_logica_formula;
		_tmp4_ = gtk_entry_get_text (_tmp3_);
		_tmp5_ = _tmp4_;
		_tmp6_ = proyecto_de_logica_logic_remove_spaces (self, _tmp5_);
		_tmp7_ = _tmp6_;
		_tmp8_ = proyecto_de_logica_logic_simplify_formula (self, _tmp7_);
		_tmp9_ = _tmp8_;
		_tmp10_ = proyecto_de_logica_logic_check_formula (self, _tmp9_);
		_tmp11_ = _tmp10_;
		_g_free0 (_tmp11_);
		_g_free0 (_tmp9_);
		_g_free0 (_tmp7_);
		_tmp12_ = proyecto_de_logica_formula2;
		_tmp13_ = gtk_entry_get_text (_tmp12_);
		_tmp14_ = _tmp13_;
		_tmp15_ = proyecto_de_logica_logic_remove_spaces (self, _tmp14_);
		_tmp16_ = _tmp15_;
		_tmp17_ = proyecto_de_logica_logic_simplify_formula (self, _tmp16_);
		_tmp18_ = _tmp17_;
		_tmp19_ = proyecto_de_logica_logic_check_formula (self, _tmp18_);
		_tmp20_ = _tmp19_;
		_g_free0 (_tmp20_);
		_g_free0 (_tmp18_);
		_g_free0 (_tmp16_);
		_tmp21_ = proyecto_de_logica_formula2;
		_tmp22_ = gtk_entry_get_text (_tmp21_);
		_tmp23_ = _tmp22_;
		_tmp24_ = proyecto_de_logica_logic_remove_spaces (self, _tmp23_);
		_tmp25_ = _tmp24_;
		_tmp26_ = proyecto_de_logica_logic_simplify_formula (self, _tmp25_);
		_tmp27_ = _tmp26_;
		_tmp28_ = proyecto_de_logica_logic_check_formula (self, _tmp27_);
		_tmp29_ = _tmp28_;
		_g_free0 (_tmp29_);
		_g_free0 (_tmp27_);
		_g_free0 (_tmp25_);
	} else {
		GtkEntry* _tmp30_ = NULL;
		const gchar* _tmp31_ = NULL;
		const gchar* _tmp32_ = NULL;
		gchar* _tmp33_ = NULL;
		gchar* _tmp34_ = NULL;
		gchar* _tmp35_ = NULL;
		gchar* _tmp36_ = NULL;
		gchar* _tmp37_ = NULL;
		gchar* _tmp38_ = NULL;
		_tmp30_ = proyecto_de_logica_formula;
		_tmp31_ = gtk_entry_get_text (_tmp30_);
		_tmp32_ = _tmp31_;
		_tmp33_ = proyecto_de_logica_logic_remove_spaces (self, _tmp32_);
		_tmp34_ = _tmp33_;
		_tmp35_ = proyecto_de_logica_logic_simplify_formula (self, _tmp34_);
		_tmp36_ = _tmp35_;
		_tmp37_ = proyecto_de_logica_logic_check_formula (self, _tmp36_);
		_tmp38_ = _tmp37_;
		_g_free0 (_tmp38_);
		_g_free0 (_tmp36_);
		_g_free0 (_tmp34_);
	}
}


static void ___lambda22__proyecto_de_logica_logic_check (ProyectoDeLogicaLogic* _sender, gpointer self) {
	__lambda22_ (self);
}


static void __lambda23_ (Block1Data* _data1_) {
	ProyectoDeLogicaLogic* self;
	self = _data1_->self;
	gtk_button_clicked (_data1_->Calculate);
}


static void ___lambda23__gtk_entry_activate (GtkEntry* _sender, gpointer self) {
	__lambda23_ (self);
}


static void __lambda24_ (ProyectoDeLogicaLogic* self) {
	GtkEntry* _tmp0_ = NULL;
	_tmp0_ = proyecto_de_logica_formula;
	g_signal_emit_by_name (_tmp0_, "activate");
}


static void ___lambda24__gtk_entry_activate (GtkEntry* _sender, gpointer self) {
	__lambda24_ ((ProyectoDeLogicaLogic*) self);
}


static void __lambda25_ (Block1Data* _data1_) {
	ProyectoDeLogicaLogic* self;
	gint _tmp0_ = 0;
	gboolean _tmp1_ = FALSE;
	const gchar* _tmp2_ = NULL;
	const gchar* _tmp3_ = NULL;
	self = _data1_->self;
	_tmp0_ = self->formula_valid;
	self->formula_valid = _tmp0_ + 1;
	_tmp2_ = gtk_label_get_label (_data1_->entails);
	_tmp3_ = _tmp2_;
	if (g_strcmp0 (_tmp3_, "0") == 0) {
		gint _tmp4_ = 0;
		_tmp4_ = self->formula_valid;
		_tmp1_ = _tmp4_ == 1;
	} else {
		_tmp1_ = FALSE;
	}
	if (_tmp1_) {
		GtkStyleContext* _tmp5_ = NULL;
		GtkStyleContext* _tmp6_ = NULL;
		GtkEntry* _tmp7_ = NULL;
		GtkStyleContext* _tmp8_ = NULL;
		_tmp5_ = gtk_widget_get_style_context ((GtkWidget*) _data1_->Calculate);
		gtk_style_context_add_class (_tmp5_, GTK_STYLE_CLASS_SUGGESTED_ACTION);
		_tmp6_ = gtk_widget_get_style_context ((GtkWidget*) _data1_->Calculate);
		gtk_style_context_remove_class (_tmp6_, GTK_STYLE_CLASS_DESTRUCTIVE_ACTION);
		_tmp7_ = proyecto_de_logica_formula;
		_tmp8_ = gtk_widget_get_style_context ((GtkWidget*) _tmp7_);
		gtk_style_context_remove_provider (_tmp8_, (GtkStyleProvider*) _data1_->error_css);
	} else {
		gint _tmp9_ = 0;
		_tmp9_ = self->formula_valid;
		if (_tmp9_ == 1) {
			GtkEntry* _tmp10_ = NULL;
			GtkStyleContext* _tmp11_ = NULL;
			GtkEntry* _tmp12_ = NULL;
			GtkStyleContext* _tmp13_ = NULL;
			_tmp10_ = proyecto_de_logica_formula;
			_tmp11_ = gtk_widget_get_style_context ((GtkWidget*) _tmp10_);
			gtk_style_context_remove_provider (_tmp11_, (GtkStyleProvider*) _data1_->error_css);
			_tmp12_ = proyecto_de_logica_formula2;
			_tmp13_ = gtk_widget_get_style_context ((GtkWidget*) _tmp12_);
			gtk_style_context_add_provider (_tmp13_, (GtkStyleProvider*) _data1_->error_css, (guint) GTK_STYLE_PROVIDER_PRIORITY_USER);
		} else {
			gint _tmp14_ = 0;
			_tmp14_ = self->formula_valid;
			if (_tmp14_ == 2) {
				GtkEntry* _tmp15_ = NULL;
				GtkStyleContext* _tmp16_ = NULL;
				GtkEntry* _tmp17_ = NULL;
				GtkStyleContext* _tmp18_ = NULL;
				_tmp15_ = proyecto_de_logica_formula2;
				_tmp16_ = gtk_widget_get_style_context ((GtkWidget*) _tmp15_);
				gtk_style_context_remove_provider (_tmp16_, (GtkStyleProvider*) _data1_->error_css);
				_tmp17_ = proyecto_de_logica_formula;
				_tmp18_ = gtk_widget_get_style_context ((GtkWidget*) _tmp17_);
				gtk_style_context_add_provider (_tmp18_, (GtkStyleProvider*) _data1_->error_css, (guint) GTK_STYLE_PROVIDER_PRIORITY_USER);
			} else {
				gint _tmp19_ = 0;
				_tmp19_ = self->formula_valid;
				if (_tmp19_ == 3) {
					GtkStyleContext* _tmp20_ = NULL;
					GtkStyleContext* _tmp21_ = NULL;
					GtkEntry* _tmp22_ = NULL;
					GtkStyleContext* _tmp23_ = NULL;
					GtkEntry* _tmp24_ = NULL;
					GtkStyleContext* _tmp25_ = NULL;
					_tmp20_ = gtk_widget_get_style_context ((GtkWidget*) _data1_->Calculate);
					gtk_style_context_add_class (_tmp20_, GTK_STYLE_CLASS_SUGGESTED_ACTION);
					_tmp21_ = gtk_widget_get_style_context ((GtkWidget*) _data1_->Calculate);
					gtk_style_context_remove_class (_tmp21_, GTK_STYLE_CLASS_DESTRUCTIVE_ACTION);
					_tmp22_ = proyecto_de_logica_formula;
					_tmp23_ = gtk_widget_get_style_context ((GtkWidget*) _tmp22_);
					gtk_style_context_remove_provider (_tmp23_, (GtkStyleProvider*) _data1_->error_css);
					_tmp24_ = proyecto_de_logica_formula2;
					_tmp25_ = gtk_widget_get_style_context ((GtkWidget*) _tmp24_);
					gtk_style_context_remove_provider (_tmp25_, (GtkStyleProvider*) _data1_->error_css);
				}
			}
		}
	}
}


static void ___lambda25__proyecto_de_logica_logic_good_formula (ProyectoDeLogicaLogic* _sender, gpointer self) {
	__lambda25_ (self);
}


static void __lambda26_ (Block1Data* _data1_) {
	ProyectoDeLogicaLogic* self;
	gboolean _tmp0_ = FALSE;
	gint _tmp1_ = 0;
	self = _data1_->self;
	_tmp1_ = self->formula_valid;
	if (_tmp1_ == 3) {
		_tmp0_ = TRUE;
	} else {
		gboolean _tmp2_ = FALSE;
		const gchar* _tmp3_ = NULL;
		const gchar* _tmp4_ = NULL;
		_tmp3_ = gtk_label_get_label (_data1_->entails);
		_tmp4_ = _tmp3_;
		if (g_strcmp0 (_tmp4_, "0") == 0) {
			gint _tmp5_ = 0;
			_tmp5_ = self->formula_valid;
			_tmp2_ = _tmp5_ == 1;
		} else {
			_tmp2_ = FALSE;
		}
		_tmp0_ = _tmp2_;
	}
	if (_tmp0_) {
		GtkBox* _tmp6_ = NULL;
		GtkHeaderBar* _tmp7_ = NULL;
		GtkSwitch* _tmp8_ = NULL;
		GtkEntry* _tmp9_ = NULL;
		GtkEntry* _tmp10_ = NULL;
		const gchar* _tmp11_ = NULL;
		const gchar* _tmp12_ = NULL;
		gchar* _tmp13_ = NULL;
		gchar* _tmp14_ = NULL;
		GtkEntry* _tmp15_ = NULL;
		GtkEntry* _tmp16_ = NULL;
		const gchar* _tmp17_ = NULL;
		const gchar* _tmp18_ = NULL;
		gchar* _tmp19_ = NULL;
		gchar* _tmp20_ = NULL;
		ProyectoDeLogicaSolver* _tmp21_ = NULL;
		GtkSwitch* _tmp22_ = NULL;
		gboolean _tmp23_ = FALSE;
		gboolean _tmp24_ = FALSE;
		ProyectoDeLogicaSolver* _tmp62_ = NULL;
		ProyectoDeLogicaSolver* _tmp63_ = NULL;
		_tmp6_ = proyecto_de_logica_mainbox;
		gtk_container_remove ((GtkContainer*) self, (GtkWidget*) _tmp6_);
		_tmp7_ = proyecto_de_logica_headerbar;
		_tmp8_ = proyecto_de_logica_formula_toggle;
		gtk_container_remove ((GtkContainer*) _tmp7_, (GtkWidget*) _tmp8_);
		_tmp9_ = proyecto_de_logica_formula;
		_tmp10_ = proyecto_de_logica_formula;
		_tmp11_ = gtk_entry_get_text (_tmp10_);
		_tmp12_ = _tmp11_;
		_tmp13_ = proyecto_de_logica_logic_remove_spaces (self, _tmp12_);
		_tmp14_ = _tmp13_;
		gtk_entry_set_text (_tmp9_, _tmp14_);
		_g_free0 (_tmp14_);
		_tmp15_ = proyecto_de_logica_formula;
		_tmp16_ = proyecto_de_logica_formula;
		_tmp17_ = gtk_entry_get_text (_tmp16_);
		_tmp18_ = _tmp17_;
		_tmp19_ = proyecto_de_logica_logic_add_spaces (self, _tmp18_, 0);
		_tmp20_ = _tmp19_;
		gtk_entry_set_text (_tmp15_, _tmp20_);
		_g_free0 (_tmp20_);
		_tmp21_ = proyecto_de_logica_solver_new ();
		g_object_ref_sink (_tmp21_);
		_g_object_unref0 (proyecto_de_logica_solver_box);
		proyecto_de_logica_solver_box = _tmp21_;
		_tmp22_ = proyecto_de_logica_formula_toggle;
		_tmp23_ = gtk_switch_get_state (_tmp22_);
		_tmp24_ = _tmp23_;
		if (_tmp24_ == TRUE) {
			GtkEntry* _tmp25_ = NULL;
			GtkEntry* _tmp26_ = NULL;
			const gchar* _tmp27_ = NULL;
			const gchar* _tmp28_ = NULL;
			gchar* _tmp29_ = NULL;
			gchar* _tmp30_ = NULL;
			GtkEntry* _tmp31_ = NULL;
			GtkEntry* _tmp32_ = NULL;
			const gchar* _tmp33_ = NULL;
			const gchar* _tmp34_ = NULL;
			gchar* _tmp35_ = NULL;
			gchar* _tmp36_ = NULL;
			ProyectoDeLogicaSolver* _tmp37_ = NULL;
			GtkEntry* _tmp38_ = NULL;
			const gchar* _tmp39_ = NULL;
			const gchar* _tmp40_ = NULL;
			const gchar* _tmp41_ = NULL;
			GtkEntry* _tmp42_ = NULL;
			const gchar* _tmp43_ = NULL;
			const gchar* _tmp44_ = NULL;
			const gchar* _tmp45_ = NULL;
			gchar* _tmp46_ = NULL;
			gchar* _tmp47_ = NULL;
			GtkEntry* _tmp48_ = NULL;
			const gchar* _tmp49_ = NULL;
			const gchar* _tmp50_ = NULL;
			const gchar* _tmp51_ = NULL;
			GtkEntry* _tmp52_ = NULL;
			const gchar* _tmp53_ = NULL;
			const gchar* _tmp54_ = NULL;
			const gchar* _tmp55_ = NULL;
			gchar* _tmp56_ = NULL;
			gchar* _tmp57_ = NULL;
			_tmp25_ = proyecto_de_logica_formula2;
			_tmp26_ = proyecto_de_logica_formula2;
			_tmp27_ = gtk_entry_get_text (_tmp26_);
			_tmp28_ = _tmp27_;
			_tmp29_ = proyecto_de_logica_logic_remove_spaces (self, _tmp28_);
			_tmp30_ = _tmp29_;
			gtk_entry_set_text (_tmp25_, _tmp30_);
			_g_free0 (_tmp30_);
			_tmp31_ = proyecto_de_logica_formula2;
			_tmp32_ = proyecto_de_logica_formula2;
			_tmp33_ = gtk_entry_get_text (_tmp32_);
			_tmp34_ = _tmp33_;
			_tmp35_ = proyecto_de_logica_logic_add_spaces (self, _tmp34_, 0);
			_tmp36_ = _tmp35_;
			gtk_entry_set_text (_tmp31_, _tmp36_);
			_g_free0 (_tmp36_);
			_tmp37_ = proyecto_de_logica_solver_box;
			_tmp38_ = proyecto_de_logica_formula;
			_tmp39_ = gtk_entry_get_text (_tmp38_);
			_tmp40_ = _tmp39_;
			_tmp41_ = string_to_string (_tmp40_);
			_tmp42_ = proyecto_de_logica_formula2;
			_tmp43_ = gtk_entry_get_text (_tmp42_);
			_tmp44_ = _tmp43_;
			_tmp45_ = string_to_string (_tmp44_);
			_tmp46_ = g_strconcat (_tmp41_, " , !(", _tmp45_, ")", NULL);
			_tmp47_ = _tmp46_;
			_tmp48_ = proyecto_de_logica_formula;
			_tmp49_ = gtk_entry_get_text (_tmp48_);
			_tmp50_ = _tmp49_;
			_tmp51_ = string_to_string (_tmp50_);
			_tmp52_ = proyecto_de_logica_formula2;
			_tmp53_ = gtk_entry_get_text (_tmp52_);
			_tmp54_ = _tmp53_;
			_tmp55_ = string_to_string (_tmp54_);
			_tmp56_ = g_strconcat (_tmp51_, " ⊨  ", _tmp55_, NULL);
			_tmp57_ = _tmp56_;
			proyecto_de_logica_solver_populate (_tmp37_, _tmp47_, _tmp57_);
			_g_free0 (_tmp57_);
			_g_free0 (_tmp47_);
		} else {
			ProyectoDeLogicaSolver* _tmp58_ = NULL;
			GtkEntry* _tmp59_ = NULL;
			const gchar* _tmp60_ = NULL;
			const gchar* _tmp61_ = NULL;
			_tmp58_ = proyecto_de_logica_solver_box;
			_tmp59_ = proyecto_de_logica_formula;
			_tmp60_ = gtk_entry_get_text (_tmp59_);
			_tmp61_ = _tmp60_;
			proyecto_de_logica_solver_populate (_tmp58_, _tmp61_, "");
		}
		_tmp62_ = proyecto_de_logica_solver_box;
		gtk_container_add ((GtkContainer*) self, (GtkWidget*) _tmp62_);
		_tmp63_ = proyecto_de_logica_solver_box;
		gtk_widget_show_all ((GtkWidget*) _tmp63_);
	}
}


static void ___lambda26__gtk_button_clicked (GtkButton* _sender, gpointer self) {
	__lambda26_ (self);
}


static void __lambda27_ (ProyectoDeLogicaLogic* self) {
	GtkEntry* _tmp0_ = NULL;
	gboolean _tmp1_ = FALSE;
	gboolean _tmp2_ = FALSE;
	GtkEntry* _tmp4_ = NULL;
	gboolean _tmp5_ = FALSE;
	gboolean _tmp6_ = FALSE;
	_tmp0_ = proyecto_de_logica_formula;
	g_object_get ((GtkWidget*) _tmp0_, "has-focus", &_tmp1_, NULL);
	_tmp2_ = _tmp1_;
	if (_tmp2_) {
		GtkEntry* _tmp3_ = NULL;
		_tmp3_ = proyecto_de_logica_formula;
		gtk_entry_set_text (_tmp3_, "");
	}
	_tmp4_ = proyecto_de_logica_formula2;
	g_object_get ((GtkWidget*) _tmp4_, "has-focus", &_tmp5_, NULL);
	_tmp6_ = _tmp5_;
	if (_tmp6_) {
		GtkEntry* _tmp7_ = NULL;
		_tmp7_ = proyecto_de_logica_formula2;
		gtk_entry_set_text (_tmp7_, "");
	}
}


static void ___lambda27__gtk_button_clicked (GtkButton* _sender, gpointer self) {
	__lambda27_ ((ProyectoDeLogicaLogic*) self);
}


ProyectoDeLogicaLogic* proyecto_de_logica_logic_construct (GType object_type) {
	ProyectoDeLogicaLogic * self = NULL;
	Block1Data* _data1_;
	GtkCssProvider* _tmp0_ = NULL;
	gchar* css_file = NULL;
	gchar* _tmp1_ = NULL;
	GtkHeaderBar* _tmp2_ = NULL;
	GtkHeaderBar* _tmp3_ = NULL;
	GtkHeaderBar* _tmp4_ = NULL;
	GtkHeaderBar* _tmp5_ = NULL;
	GtkHeaderBar* _tmp6_ = NULL;
	GtkHeaderBar* _tmp7_ = NULL;
	GtkBox* _tmp8_ = NULL;
	GtkBox* _tmp9_ = NULL;
	GtkEntry* _tmp10_ = NULL;
	GtkEntry* _tmp11_ = NULL;
	GtkLabel* _tmp12_ = NULL;
	GtkButton* clear = NULL;
	GtkButton* _tmp13_ = NULL;
	GtkButton* _tmp14_ = NULL;
	GtkButton* button_and = NULL;
	GtkButton* _tmp15_ = NULL;
	GtkButton* button_or = NULL;
	GtkButton* _tmp16_ = NULL;
	GtkButton* button_not = NULL;
	GtkButton* _tmp17_ = NULL;
	GtkButton* button_pars = NULL;
	GtkButton* _tmp18_ = NULL;
	GtkButton* button_ifif = NULL;
	GtkButton* _tmp19_ = NULL;
	GtkButton* button_if = NULL;
	GtkButton* _tmp20_ = NULL;
	GtkButton* button_nand = NULL;
	GtkButton* _tmp21_ = NULL;
	GtkButton* button_nor = NULL;
	GtkButton* _tmp22_ = NULL;
	GtkEntry* _tmp23_ = NULL;
	GtkEntry* _tmp24_ = NULL;
	GtkSwitch* _tmp25_ = NULL;
	GtkStyleContext* _tmp26_ = NULL;
	GtkStyleContext* _tmp27_ = NULL;
	GtkStyleContext* _tmp28_ = NULL;
	GtkEntry* _tmp29_ = NULL;
	GtkStyleContext* _tmp30_ = NULL;
	GtkEntry* _tmp31_ = NULL;
	GtkStyleContext* _tmp32_ = NULL;
	GtkStyleContext* _tmp33_ = NULL;
	GtkGrid* _tmp34_ = NULL;
	GtkGrid* _tmp35_ = NULL;
	GtkEntry* _tmp36_ = NULL;
	GtkGrid* _tmp37_ = NULL;
	GtkGrid* _tmp38_ = NULL;
	GtkGrid* _tmp39_ = NULL;
	GtkGrid* _tmp40_ = NULL;
	GtkGrid* _tmp41_ = NULL;
	GtkGrid* _tmp42_ = NULL;
	GtkGrid* _tmp43_ = NULL;
	GtkGrid* _tmp44_ = NULL;
	GtkGrid* _tmp45_ = NULL;
	GtkGrid* _tmp46_ = NULL;
	GtkGrid* _tmp47_ = NULL;
	GtkGrid* _tmp48_ = NULL;
	GtkGrid* _tmp49_ = NULL;
	GtkSwitch* _tmp50_ = NULL;
	GtkSwitch* _tmp51_ = NULL;
	GtkHeaderBar* _tmp52_ = NULL;
	GtkSwitch* _tmp53_ = NULL;
	GtkSwitch* _tmp54_ = NULL;
	GtkEntry* _tmp55_ = NULL;
	GtkBox* _tmp56_ = NULL;
	GtkGrid* _tmp57_ = NULL;
	GtkBox* _tmp58_ = NULL;
	GtkEntry* _tmp59_ = NULL;
	GtkEntry* _tmp60_ = NULL;
	GtkEntry* _tmp61_ = NULL;
	GtkEntry* _tmp62_ = NULL;
	GSettings* _tmp63_ = NULL;
	gchar* _tmp64_ = NULL;
	gchar* _tmp65_ = NULL;
	gboolean _tmp66_ = FALSE;
	GSettings* _tmp71_ = NULL;
	gchar* _tmp72_ = NULL;
	gchar* _tmp73_ = NULL;
	gboolean _tmp74_ = FALSE;
	GError * _inner_error_ = NULL;
	_data1_ = g_slice_new0 (Block1Data);
	_data1_->_ref_count_ = 1;
	self = (ProyectoDeLogicaLogic*) g_object_new (object_type, NULL);
	_data1_->self = g_object_ref (self);
	g_signal_connect ((GtkWidget*) self, "destroy", (GCallback) _gtk_main_quit_gtk_widget_destroy, NULL);
	gtk_container_set_border_width ((GtkContainer*) self, (guint) 12);
	_tmp0_ = gtk_css_provider_new ();
	_data1_->error_css = _tmp0_;
	_tmp1_ = g_strdup ("/home/felipe/Code/vala/Logica/custom.css");
	css_file = _tmp1_;
	_tmp2_ = (GtkHeaderBar*) gtk_header_bar_new ();
	g_object_ref_sink (_tmp2_);
	_g_object_unref0 (proyecto_de_logica_headerbar);
	proyecto_de_logica_headerbar = _tmp2_;
	_tmp3_ = proyecto_de_logica_headerbar;
	gtk_window_set_titlebar ((GtkWindow*) self, (GtkWidget*) _tmp3_);
	_tmp4_ = proyecto_de_logica_headerbar;
	gtk_header_bar_set_title (_tmp4_, "Logic Calculator");
	_tmp5_ = proyecto_de_logica_headerbar;
	gtk_header_bar_set_subtitle (_tmp5_, "By: Felipe & Fer");
	_tmp6_ = proyecto_de_logica_headerbar;
	gtk_header_bar_set_decoration_layout (_tmp6_, "close");
	_tmp7_ = proyecto_de_logica_headerbar;
	gtk_header_bar_set_show_close_button (_tmp7_, TRUE);
	_tmp8_ = (GtkBox*) gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);
	g_object_ref_sink (_tmp8_);
	_g_object_unref0 (proyecto_de_logica_mainbox);
	proyecto_de_logica_mainbox = _tmp8_;
	_tmp9_ = proyecto_de_logica_mainbox;
	gtk_container_add ((GtkContainer*) self, (GtkWidget*) _tmp9_);
	_tmp10_ = (GtkEntry*) gtk_entry_new ();
	g_object_ref_sink (_tmp10_);
	_g_object_unref0 (proyecto_de_logica_formula);
	proyecto_de_logica_formula = _tmp10_;
	_tmp11_ = (GtkEntry*) gtk_entry_new ();
	g_object_ref_sink (_tmp11_);
	_g_object_unref0 (proyecto_de_logica_formula2);
	proyecto_de_logica_formula2 = _tmp11_;
	_tmp12_ = (GtkLabel*) gtk_label_new ("0");
	g_object_ref_sink (_tmp12_);
	_data1_->entails = _tmp12_;
	_tmp13_ = (GtkButton*) gtk_button_new_with_label ("Clear");
	g_object_ref_sink (_tmp13_);
	clear = _tmp13_;
	_tmp14_ = (GtkButton*) gtk_button_new_with_label ("Check");
	g_object_ref_sink (_tmp14_);
	_data1_->Calculate = _tmp14_;
	_tmp15_ = proyecto_de_logica_logic_LogicButton (self, " & ");
	button_and = _tmp15_;
	_tmp16_ = proyecto_de_logica_logic_LogicButton (self, " | ");
	button_or = _tmp16_;
	_tmp17_ = proyecto_de_logica_logic_LogicButton (self, " ! ");
	button_not = _tmp17_;
	_tmp18_ = proyecto_de_logica_logic_LogicButton (self, "( )");
	button_pars = _tmp18_;
	_tmp19_ = proyecto_de_logica_logic_LogicButton (self, "⇔");
	button_ifif = _tmp19_;
	_tmp20_ = proyecto_de_logica_logic_LogicButton (self, "⇒");
	button_if = _tmp20_;
	_tmp21_ = proyecto_de_logica_logic_LogicButton (self, "⇑");
	button_nand = _tmp21_;
	_tmp22_ = proyecto_de_logica_logic_LogicButton (self, "⇓");
	button_nor = _tmp22_;
	gtk_widget_set_tooltip_text ((GtkWidget*) button_and, "And");
	gtk_widget_set_tooltip_text ((GtkWidget*) button_or, "Or");
	gtk_widget_set_tooltip_text ((GtkWidget*) button_not, "Not");
	gtk_widget_set_tooltip_text ((GtkWidget*) button_if, "If");
	gtk_widget_set_tooltip_text ((GtkWidget*) button_ifif, "If and ONLY IF");
	gtk_widget_set_tooltip_text ((GtkWidget*) button_nor, "NOR");
	gtk_widget_set_tooltip_text ((GtkWidget*) button_nand, "NAND");
	_tmp23_ = proyecto_de_logica_formula;
	gtk_widget_set_margin_bottom ((GtkWidget*) _tmp23_, 10);
	_tmp24_ = proyecto_de_logica_formula2;
	gtk_widget_set_margin_bottom ((GtkWidget*) _tmp24_, 10);
	_tmp25_ = proyecto_de_logica_formula_toggle;
	g_object_set ((GtkWidget*) _tmp25_, "can-focus", FALSE, NULL);
	_tmp26_ = gtk_widget_get_style_context ((GtkWidget*) _data1_->Calculate);
	gtk_style_context_add_class (_tmp26_, GTK_STYLE_CLASS_SUGGESTED_ACTION);
	_tmp27_ = gtk_widget_get_style_context ((GtkWidget*) _data1_->Calculate);
	gtk_style_context_add_class (_tmp27_, "h3");
	_tmp28_ = gtk_widget_get_style_context ((GtkWidget*) clear);
	gtk_style_context_add_class (_tmp28_, "h3");
	_tmp29_ = proyecto_de_logica_formula;
	_tmp30_ = gtk_widget_get_style_context ((GtkWidget*) _tmp29_);
	gtk_style_context_add_class (_tmp30_, "h2");
	_tmp31_ = proyecto_de_logica_formula2;
	_tmp32_ = gtk_widget_get_style_context ((GtkWidget*) _tmp31_);
	gtk_style_context_add_class (_tmp32_, "h2");
	_tmp33_ = gtk_widget_get_style_context ((GtkWidget*) _data1_->entails);
	gtk_style_context_add_class (_tmp33_, "h2");
	gtk_button_set_focus_on_click (_data1_->Calculate, FALSE);
	gtk_button_set_focus_on_click (clear, FALSE);
	_tmp34_ = (GtkGrid*) gtk_grid_new ();
	g_object_ref_sink (_tmp34_);
	_g_object_unref0 (proyecto_de_logica_grid);
	proyecto_de_logica_grid = _tmp34_;
	_tmp35_ = proyecto_de_logica_grid;
	_tmp36_ = proyecto_de_logica_formula;
	gtk_grid_attach (_tmp35_, (GtkWidget*) _tmp36_, 0, 0, 15, 1);
	_tmp37_ = proyecto_de_logica_grid;
	gtk_grid_attach (_tmp37_, (GtkWidget*) button_and, 0, 3, 3, 1);
	_tmp38_ = proyecto_de_logica_grid;
	gtk_grid_attach (_tmp38_, (GtkWidget*) button_or, 3, 3, 3, 1);
	_tmp39_ = proyecto_de_logica_grid;
	gtk_grid_attach (_tmp39_, (GtkWidget*) button_not, 6, 3, 3, 1);
	_tmp40_ = proyecto_de_logica_grid;
	gtk_grid_attach (_tmp40_, (GtkWidget*) button_pars, 9, 3, 3, 1);
	_tmp41_ = proyecto_de_logica_grid;
	gtk_grid_attach (_tmp41_, (GtkWidget*) clear, 12, 3, 3, 1);
	_tmp42_ = proyecto_de_logica_grid;
	gtk_grid_attach (_tmp42_, (GtkWidget*) button_if, 0, 6, 3, 1);
	_tmp43_ = proyecto_de_logica_grid;
	gtk_grid_attach (_tmp43_, (GtkWidget*) button_ifif, 3, 6, 3, 1);
	_tmp44_ = proyecto_de_logica_grid;
	gtk_grid_attach (_tmp44_, (GtkWidget*) button_nand, 6, 6, 3, 1);
	_tmp45_ = proyecto_de_logica_grid;
	gtk_grid_attach (_tmp45_, (GtkWidget*) button_nor, 9, 6, 3, 1);
	_tmp46_ = proyecto_de_logica_grid;
	gtk_grid_attach (_tmp46_, (GtkWidget*) _data1_->Calculate, 12, 6, 3, 1);
	_tmp47_ = proyecto_de_logica_grid;
	gtk_grid_set_column_homogeneous (_tmp47_, TRUE);
	_tmp48_ = proyecto_de_logica_grid;
	gtk_grid_set_row_spacing (_tmp48_, 4);
	_tmp49_ = proyecto_de_logica_grid;
	gtk_grid_set_column_spacing (_tmp49_, 4);
	_tmp50_ = (GtkSwitch*) gtk_switch_new ();
	g_object_ref_sink (_tmp50_);
	_g_object_unref0 (proyecto_de_logica_formula_toggle);
	proyecto_de_logica_formula_toggle = _tmp50_;
	_tmp51_ = proyecto_de_logica_formula_toggle;
	gtk_widget_set_tooltip_text ((GtkWidget*) _tmp51_, "Advanced mode");
	_tmp52_ = proyecto_de_logica_headerbar;
	_tmp53_ = proyecto_de_logica_formula_toggle;
	gtk_header_bar_pack_end (_tmp52_, (GtkWidget*) _tmp53_);
	_tmp54_ = proyecto_de_logica_formula_toggle;
	g_signal_connect_data (_tmp54_, "state-set", (GCallback) ___lambda10__gtk_switch_state_set, block1_data_ref (_data1_), (GClosureNotify) block1_data_unref, 0);
	_tmp55_ = proyecto_de_logica_formula;
	g_signal_connect_object ((GtkWidget*) _tmp55_, "focus-in-event", (GCallback) ___lambda11__gtk_widget_focus_in_event, self, 0);
	gtk_css_provider_load_from_path (_data1_->error_css, css_file, &_inner_error_);
	if (G_UNLIKELY (_inner_error_ != NULL)) {
		_g_object_unref0 (button_nor);
		_g_object_unref0 (button_nand);
		_g_object_unref0 (button_if);
		_g_object_unref0 (button_ifif);
		_g_object_unref0 (button_pars);
		_g_object_unref0 (button_not);
		_g_object_unref0 (button_or);
		_g_object_unref0 (button_and);
		_g_object_unref0 (clear);
		_g_free0 (css_file);
		block1_data_unref (_data1_);
		_data1_ = NULL;
		g_critical ("file %s: line %d: uncaught error: %s (%s, %d)", __FILE__, __LINE__, _inner_error_->message, g_quark_to_string (_inner_error_->domain), _inner_error_->code);
		g_clear_error (&_inner_error_);
		return NULL;
	}
	_tmp56_ = proyecto_de_logica_mainbox;
	_tmp57_ = proyecto_de_logica_grid;
	gtk_container_add ((GtkContainer*) _tmp56_, (GtkWidget*) _tmp57_);
	_tmp58_ = proyecto_de_logica_mainbox;
	gtk_box_set_spacing (_tmp58_, 12);
	g_signal_connect_object (button_and, "clicked", (GCallback) ___lambda12__gtk_button_clicked, self, 0);
	g_signal_connect_object (button_or, "clicked", (GCallback) ___lambda13__gtk_button_clicked, self, 0);
	g_signal_connect_object (button_not, "clicked", (GCallback) ___lambda14__gtk_button_clicked, self, 0);
	g_signal_connect_object (button_pars, "clicked", (GCallback) ___lambda15__gtk_button_clicked, self, 0);
	g_signal_connect_object (button_if, "clicked", (GCallback) ___lambda16__gtk_button_clicked, self, 0);
	g_signal_connect_object (button_ifif, "clicked", (GCallback) ___lambda17__gtk_button_clicked, self, 0);
	g_signal_connect_object (button_nand, "clicked", (GCallback) ___lambda18__gtk_button_clicked, self, 0);
	g_signal_connect_object (button_nor, "clicked", (GCallback) ___lambda19__gtk_button_clicked, self, 0);
	_tmp59_ = proyecto_de_logica_formula;
	g_signal_connect_data ((GtkEditable*) _tmp59_, "changed", (GCallback) ___lambda20__gtk_editable_changed, block1_data_ref (_data1_), (GClosureNotify) block1_data_unref, 0);
	_tmp60_ = proyecto_de_logica_formula2;
	g_signal_connect_data ((GtkEditable*) _tmp60_, "changed", (GCallback) ___lambda21__gtk_editable_changed, block1_data_ref (_data1_), (GClosureNotify) block1_data_unref, 0);
	g_signal_connect_data (self, "check", (GCallback) ___lambda22__proyecto_de_logica_logic_check, block1_data_ref (_data1_), (GClosureNotify) block1_data_unref, 0);
	_tmp61_ = proyecto_de_logica_formula;
	g_signal_connect_data (_tmp61_, "activate", (GCallback) ___lambda23__gtk_entry_activate, block1_data_ref (_data1_), (GClosureNotify) block1_data_unref, 0);
	_tmp62_ = proyecto_de_logica_formula2;
	g_signal_connect_object (_tmp62_, "activate", (GCallback) ___lambda24__gtk_entry_activate, self, 0);
	g_signal_connect_data (self, "good-formula", (GCallback) ___lambda25__proyecto_de_logica_logic_good_formula, block1_data_ref (_data1_), (GClosureNotify) block1_data_unref, 0);
	g_signal_connect_data (_data1_->Calculate, "clicked", (GCallback) ___lambda26__gtk_button_clicked, block1_data_ref (_data1_), (GClosureNotify) block1_data_unref, 0);
	g_signal_connect_object (clear, "clicked", (GCallback) ___lambda27__gtk_button_clicked, self, 0);
	_tmp63_ = proyecto_de_logica_settings;
	_tmp64_ = g_settings_get_string (_tmp63_, "formula0");
	_tmp65_ = _tmp64_;
	_tmp66_ = g_strcmp0 (_tmp65_, "") != 0;
	_g_free0 (_tmp65_);
	if (_tmp66_) {
		GtkEntry* _tmp67_ = NULL;
		GSettings* _tmp68_ = NULL;
		gchar* _tmp69_ = NULL;
		gchar* _tmp70_ = NULL;
		_tmp67_ = proyecto_de_logica_formula;
		_tmp68_ = proyecto_de_logica_settings;
		_tmp69_ = g_settings_get_string (_tmp68_, "formula0");
		_tmp70_ = _tmp69_;
		gtk_entry_set_text (_tmp67_, _tmp70_);
		_g_free0 (_tmp70_);
	}
	_tmp71_ = proyecto_de_logica_settings;
	_tmp72_ = g_settings_get_string (_tmp71_, "formula1");
	_tmp73_ = _tmp72_;
	_tmp74_ = g_strcmp0 (_tmp73_, "") != 0;
	_g_free0 (_tmp73_);
	if (_tmp74_) {
		GtkEntry* _tmp75_ = NULL;
		GSettings* _tmp76_ = NULL;
		gchar* _tmp77_ = NULL;
		gchar* _tmp78_ = NULL;
		_tmp75_ = proyecto_de_logica_formula2;
		_tmp76_ = proyecto_de_logica_settings;
		_tmp77_ = g_settings_get_string (_tmp76_, "formula1");
		_tmp78_ = _tmp77_;
		gtk_entry_set_text (_tmp75_, _tmp78_);
		_g_free0 (_tmp78_);
	}
	_g_object_unref0 (button_nor);
	_g_object_unref0 (button_nand);
	_g_object_unref0 (button_if);
	_g_object_unref0 (button_ifif);
	_g_object_unref0 (button_pars);
	_g_object_unref0 (button_not);
	_g_object_unref0 (button_or);
	_g_object_unref0 (button_and);
	_g_object_unref0 (clear);
	_g_free0 (css_file);
	block1_data_unref (_data1_);
	_data1_ = NULL;
	return self;
}


ProyectoDeLogicaLogic* proyecto_de_logica_logic_new (void) {
	return proyecto_de_logica_logic_construct (PROYECTO_DE_LOGICA_TYPE_LOGIC);
}


static void proyecto_de_logica_logic_class_init (ProyectoDeLogicaLogicClass * klass) {
	proyecto_de_logica_logic_parent_class = g_type_class_peek_parent (klass);
	((GtkWidgetClass *) klass)->delete_event = proyecto_de_logica_logic_real_delete_event;
	G_OBJECT_CLASS (klass)->finalize = proyecto_de_logica_logic_finalize;
	g_signal_new ("check", PROYECTO_DE_LOGICA_TYPE_LOGIC, G_SIGNAL_RUN_LAST, 0, NULL, NULL, g_cclosure_marshal_VOID__VOID, G_TYPE_NONE, 0);
	g_signal_new ("good_formula", PROYECTO_DE_LOGICA_TYPE_LOGIC, G_SIGNAL_RUN_LAST, 0, NULL, NULL, g_cclosure_marshal_VOID__VOID, G_TYPE_NONE, 0);
}


static void proyecto_de_logica_logic_instance_init (ProyectoDeLogicaLogic * self) {
	self->formula_focus = FALSE;
	self->formula_valid = 0;
	self->simplify_type = FALSE;
	self->dont_exit = TRUE;
}


static void proyecto_de_logica_logic_finalize (GObject* obj) {
	ProyectoDeLogicaLogic * self;
	self = G_TYPE_CHECK_INSTANCE_CAST (obj, PROYECTO_DE_LOGICA_TYPE_LOGIC, ProyectoDeLogicaLogic);
	G_OBJECT_CLASS (proyecto_de_logica_logic_parent_class)->finalize (obj);
}


GType proyecto_de_logica_logic_get_type (void) {
	static volatile gsize proyecto_de_logica_logic_type_id__volatile = 0;
	if (g_once_init_enter (&proyecto_de_logica_logic_type_id__volatile)) {
		static const GTypeInfo g_define_type_info = { sizeof (ProyectoDeLogicaLogicClass), (GBaseInitFunc) NULL, (GBaseFinalizeFunc) NULL, (GClassInitFunc) proyecto_de_logica_logic_class_init, (GClassFinalizeFunc) NULL, NULL, sizeof (ProyectoDeLogicaLogic), 0, (GInstanceInitFunc) proyecto_de_logica_logic_instance_init, NULL };
		GType proyecto_de_logica_logic_type_id;
		proyecto_de_logica_logic_type_id = g_type_register_static (gtk_window_get_type (), "ProyectoDeLogicaLogic", &g_define_type_info, 0);
		g_once_init_leave (&proyecto_de_logica_logic_type_id__volatile, proyecto_de_logica_logic_type_id);
	}
	return proyecto_de_logica_logic_type_id__volatile;
}


gint proyecto_de_logica_main (gchar** args, int args_length1) {
	gint result = 0;
	GSettings* _tmp0_ = NULL;
	ProyectoDeLogicaLogic* _tmp1_ = NULL;
	GtkWindow* _tmp2_ = NULL;
	gtk_init (&args_length1, &args);
	_tmp0_ = g_settings_new ("org.felipe.logic");
	_g_object_unref0 (proyecto_de_logica_settings);
	proyecto_de_logica_settings = _tmp0_;
	_tmp1_ = proyecto_de_logica_logic_new ();
	g_object_ref_sink (_tmp1_);
	_g_object_unref0 (proyecto_de_logica_app);
	proyecto_de_logica_app = (GtkWindow*) _tmp1_;
	_tmp2_ = proyecto_de_logica_app;
	gtk_widget_show_all ((GtkWidget*) _tmp2_);
	gtk_main ();
	result = 0;
	return result;
}


int main (int argc, char ** argv) {
#if !GLIB_CHECK_VERSION (2,35,0)
	g_type_init ();
#endif
	return proyecto_de_logica_main (argv, argc);
}



